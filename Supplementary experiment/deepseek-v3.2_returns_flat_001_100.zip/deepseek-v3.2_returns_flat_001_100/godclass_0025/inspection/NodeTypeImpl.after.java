public class NodeTypeImpl extends AbstractNodeType implements NodeTypeDefinition {

    private static Logger log = LoggerFactory.getLogger(NodeTypeImpl.class);

    private final QNodeTypeDefinition ntd;
    private final EffectiveNodeType ent;
    private final NodeTypeManagerImpl ntMgr;
    private final ManagerProvider mgrProvider;

    /**
     * Package private constructor
     * <p/>
     * Creates a valid node type instance.
     * We assume that the node type definition is valid and all referenced
     * node types (supertypes, required node types etc.) do exist and are valid.
     *
     * @param ent        the effective (i.e. merged and resolved) node type representation
     * @param ntd        the definition of this node type
     * @param ntMgr      the node type manager associated with this node type
     * @param mgrProvider the manager provider
     */
    NodeTypeImpl(EffectiveNodeType ent, QNodeTypeDefinition ntd,
                 NodeTypeManagerImpl ntMgr, ManagerProvider mgrProvider) {
        super(ntMgr);
        this.ent = ent;
        this.ntMgr = ntMgr;
        this.mgrProvider = mgrProvider;
        this.ntd = ntd;
    }

    private NamespaceResolver nsResolver() {
        return mgrProvider.getNamespaceResolver();
    }

    private NamePathResolver resolver() {
        return mgrProvider.getNamePathResolver();
    }

    private ItemDefinitionProvider definitionProvider() {
        return mgrProvider.getItemDefinitionProvider();
    }

    /**
     * ValueFactory used to convert JCR values from one type to another in order
     * to determine whether a property specified by name and value(s) would be
     * allowed.
     *
     * @see NodeType#canSetProperty(String, Value)
     * @see NodeType#canSetProperty(String, Value[])
     * @return ValueFactory used to convert JCR values.
     * @throws javax.jcr.RepositoryException If an error occurs.
     */
    private ValueFactory valueFactory() throws RepositoryException {
        return mgrProvider.getJcrValueFactory();
    }

    /**
     * ValueFactory used to convert JCR values to qualified ones in order to
     * determine value constraints within the NodeType interface.
     *
     * @return ValueFactory used to convert JCR values to qualified ones.
     * @throws javax.jcr.RepositoryException If an error occurs.
     */
    private QValueFactory qValueFactory() throws RepositoryException {
        return mgrProvider.getQValueFactory();
    }

    /**
     * Returns the applicable property definition for a property with the
     * specified name and type.
     *
     * @param propertyName
     * @param type
     * @param multiValued
     * @return
     * @throws RepositoryException if no applicable property definition
     *                             could be found
     */
    private QPropertyDefinition getApplicablePropDef(Name propertyName, int type, boolean multiValued)
            throws RepositoryException {
        return definitionProvider().getQPropertyDefinition(ntd.getName(), propertyName, type, multiValued);
    }

    /**
     * Test if this nodetype equals or is directly or indirectly derived from
     * the node type with the specified <code>nodeTypeName</code>, without
     * checking of a node type of that name really exists.
     *
     * @param nodeTypeName A node type name.
     * @return true if this node type represents the type with the given
     * <code>nodeTypeName</code> or if it is directly or indirectly derived
     * from it; otherwise <code>false</code>. If no node type exists with the
     * specified name this method will also return <code>false</code>.
     */
    public boolean isNodeType(Name nodeTypeName) {
        return ent.includesNodeType(nodeTypeName);
    }

    /**
     * Returns the node type definition.
     *
     * @return the qualified definition
     */
    QNodeTypeDefinition getDefinition() {
        return ntd;
    }

    /**
     * Tests if the value constraints defined in the property definition
     * <code>def</code> are satisfied by the the specified <code>values</code>.
     * <p/>
     * Note that the <i>protected</i> flag is not checked. Also note that no
     * type conversions are attempted if the type of the given values does not
     * match the required type as specified in the given definition.
     *
     * @param def    The definiton of the property
     * @param values An array of <code>QValue</code> objects.
     * @throws ConstraintViolationException If a constraint is violated.
     * @throws RepositoryException If another error occurs.
     */
    private static void checkSetPropertyValueConstraints(QPropertyDefinition def,
                                                        QValue[] values)
            throws ConstraintViolationException, RepositoryException {
        ValueConstraint.checkValueConstraints(def, values);
    }
    
    //-------------------------------------------------< NodeTypeDefinition >---
    /**
     * @see javax.jcr.nodetype.NodeTypeDefinition#getName()
     */
    public String getName() {
        try {
            return resolver().getJCRName(ntd.getName());
        } catch (NamespaceException e) {
            // should never get here
            log.error("encountered unregistered namespace in node type name", e);
            return ntd.getName().toString();
        }
    }

    /**
     * @see javax.jcr.nodetype.NodeTypeDefinition#getPrimaryItemName()
     */
    public String getPrimaryItemName() {
        try {
            Name piName = ntd.getPrimaryItemName();
            if (piName != null) {
                return resolver().getJCRName(piName);
            } else {
                return null;
            }
        } catch (NamespaceException e) {
            // should never get here
            log.error("encountered unregistered namespace in name of primary item", e);
            return ntd.getName().toString();
        }
    }

    /**
     * @see javax.jcr.nodetype.NodeTypeDefinition#isMixin()
     */
    public boolean isMixin() {
        return ntd.isMixin();
    }

    /**
     * @see javax.jcr.nodetype.NodeTypeDefinition#hasOrderableChildNodes()
     */
    public boolean hasOrderableChildNodes() {
        return ntd.hasOrderableChildNodes();
    }

    /**
     * @see javax.jcr.nodetype.NodeTypeDefinition#isAbstract()
     */
    public boolean isAbstract() {
        return ntd.isAbstract();
    }

    /**
     * @see javax.jcr.nodetype.NodeTypeDefinition#isQueryable()
     */
    public boolean isQueryable() {
        return ntd.isQueryable();
    }

    /**
     * @see javax.jcr.nodetype.NodeTypeDefinition#getDeclaredPropertyDefinitions()
     */
    public PropertyDefinition[] getDeclaredPropertyDefinitions() {
        QPropertyDefinition[] pda = ntd.getPropertyDefs();
        PropertyDefinition[] propDefs = new PropertyDefinition[pda.length];
        for (int i = 0; i < pda.length; i++) {
            propDefs[i] = ntMgr.getPropertyDefinition(pda[i]);
        }
        return propDefs;
    }


    /**
     * @see javax.jcr.nodetype.NodeTypeDefinition#getDeclaredChildNodeDefinitions()
     */
    public NodeDefinition[] getDeclaredChildNodeDefinitions() {
        QNodeDefinition[] cnda = ntd.getChildNodeDefs();
        NodeDefinition[] nodeDefs = new NodeDefinition[cnda.length];
        for (int i = 0; i < cnda.length; i++) {
            nodeDefs[i] = ntMgr.getNodeDefinition(cnda[i]);
        }
        return nodeDefs;
    }

    /**
     * @see javax.jcr.nodetype.NodeTypeDefinition#getDeclaredSupertypeNames()
     */
    public String[] getDeclaredSupertypeNames() {
        Name[] stNames = ntd.getSupertypes();
        String[] dstn = new String[stNames.length];
        for (int i = 0; i < stNames.length; i++) {
            try {
                dstn[i] = resolver().getJCRName(stNames[i]);
            } catch (NamespaceException e) {
                // should never get here
                log.error("invalid node type name: " + stNames[i], e);
                dstn[i] = stNames.toString();
            }
        }
        return dstn;
    }

    //-----------------------------------------------------------< NodeType >---
    /**
     * @see javax.jcr.nodetype.NodeType#isNodeType(String)
     */
    public boolean isNodeType(String nodeTypeName) {
        Name ntName;
        try {
            ntName = resolver().getQName(nodeTypeName);
        } catch (NamespaceException e) {
            log.warn("invalid node type name: " + nodeTypeName, e);
            return false;
        } catch (NameException e) {
            log.warn("invalid node type name: " + nodeTypeName, e);
            return false;
        }
        return isNodeType(ntName);
    }

    /**
     * @see javax.jcr.nodetype.NodeType#getSupertypes()
     */
    public NodeType[] getSupertypes() {
        Name[] ntNames = ent.getInheritedNodeTypes();
        NodeType[] supertypes = new NodeType[ntNames.length];
        for (int i = 0; i < ntNames.length; i++) {
            try {
                supertypes[i] = ntMgr.getNodeType(ntNames[i]);
            } catch (NoSuchNodeTypeException e) {
                // should never get here
                log.error("undefined supertype", e);
                return new NodeType[0];
            }
        }
        return supertypes;
    }

    /**
     * @see javax.jcr.nodetype.NodeType#getChildNodeDefinitions()
     */
    public NodeDefinition[] getChildNodeDefinitions() {
        QNodeDefinition[] cnda = ent.getAllQNodeDefinitions();
        NodeDefinition[] nodeDefs = new NodeDefinition[cnda.length];
        for (int i = 0; i < cnda.length; i++) {
            nodeDefs[i] = ntMgr.getNodeDefinition(cnda[i]);
        }
        return nodeDefs;
    }

    /**
     * @see javax.jcr.nodetype.NodeType#getPropertyDefinitions()
     */
    public PropertyDefinition[] getPropertyDefinitions() {
        QPropertyDefinition[] pda = ent.getAllQPropertyDefinitions();
        PropertyDefinition[] propDefs = new PropertyDefinition[pda.length];
        for (int i = 0; i < pda.length; i++) {
            propDefs[i] = ntMgr.getPropertyDefinition(pda[i]);
        }
        return propDefs;
    }

    /**
     * @see javax.jcr.nodetype.NodeType#getDeclaredSupertypes()
     */
    public NodeType[] getDeclaredSupertypes() {
        Name[] ntNames = ntd.getSupertypes();
        NodeType[] supertypes = new NodeType[ntNames.length];
        for (int i = 0; i < ntNames.length; i++) {
            try {
                supertypes[i] = ntMgr.getNodeType(ntNames[i]);
            } catch (NoSuchNodeTypeException e) {
                // should never get here
                log.error("undefined supertype", e);
                return new NodeType[0];
            }
        }
        return supertypes;
    }

    /**
     * @see javax.jcr.nodetype.NodeType#canSetProperty(String, Value)
     */
public boolean canSetProperty(String propertyName, Value value) {
    if (value == null) {
        // setting a property to null is equivalent of removing it
        return canRemoveItem(propertyName);
    }
    try {
        Name name = resolver().getQName(propertyName);
        QPropertyDefinition def;
        try {
            // try to get definition that matches the given value type
            def = getApplicablePropDef(name, value.getType(), false);
        } catch (ConstraintViolationException cve) {
            // fallback: ignore type
            def = getApplicablePropDef(name, PropertyType.UNDEFINED, false);
        }
        if (def.isProtected()) {
            return false;
        }
        if (def.isMultiple()) {
            return false;
        }
        Value v;
        if (def.getRequiredType() != PropertyType.UNDEFINED
                && def.getRequiredType() != value.getType()) {
            // type conversion required
            v =  ValueHelper.convert(value, def.getRequiredType(), valueFactory());
        } else {
            // no type conversion required
            v = value;
        }
        // create QValue from Value
        QValue qValue = ValueFormat.getQValue(v, resolver(), qValueFactory());
        checkSetPropertyValueConstraints(def, new QValue[]{qValue});
        return true;
    } catch (NameException re) {
        // fall through
    } catch (RepositoryException e) {
        // fall through
    }
    return false;
}
    /**
     * @see javax.jcr.nodetype.NodeType#canSetProperty(String, Value[])
     */
public boolean canSetProperty(String propertyName, Value[] values) {
    if (values == null) {
        // setting a property to null is equivalent of removing it
        return canRemoveItem(propertyName);
    }
    try {
        Name name = resolver().getQName(propertyName);
        // determine type of values
        int type = PropertyType.UNDEFINED;
        for (int i = 0; i < values.length; i++) {
            if (values[i] == null) {
                // skip null values as those would be purged
                continue;
            }
            if (type == PropertyType.UNDEFINED) {
                type = values[i].getType();
            } else if (type != values[i].getType()) {
                // inhomogeneous types
                return false;
            }
        }
        QPropertyDefinition def;
        try {
            // try to get definition that matches the given value type
            def = getApplicablePropDef(name, type, true);
        } catch (ConstraintViolationException cve) {
            // fallback: ignore type
            def = getApplicablePropDef(name, PropertyType.UNDEFINED, true);
        }

        if (def.isProtected()) {
            return false;
        }
        if (!def.isMultiple()) {
            return false;
        }
        // determine target type
        int targetType;
        if (def.getRequiredType() != PropertyType.UNDEFINED
                && def.getRequiredType() != type) {
            // type conversion required
            targetType = def.getRequiredType();
        } else {
            // no type conversion required
            targetType = type;
        }

        ArrayList list = new ArrayList();
        // convert values and compact array (purge null entries)
        for (int i = 0; i < values.length; i++) {
            if (values[i] != null) {
                // create QValue from Value and perform
                // type conversion as necessary
                Value v = ValueHelper.convert(values[i], targetType, valueFactory());
                QValue qValue = ValueFormat.getQValue(v, resolver(), qValueFactory());
                list.add(qValue);
            }
        }
        QValue[] internalValues = (QValue[]) list.toArray(new QValue[list.size()]);
        checkSetPropertyValueConstraints(def, internalValues);
        return true;
    } catch (NameException be) {
        // implementation specific exception, fall through
    } catch (RepositoryException re) {
        // fall through
    }
    return false;
}
    /**
     * @see javax.jcr.nodetype.NodeType#canAddChildNode(String)
     */
    public boolean canAddChildNode(String childNodeName) {
        try {
            ent.checkAddNodeConstraints(resolver().getQName(childNodeName), definitionProvider());
            return true;
        } catch (NameException be) {
            // implementation specific exception, fall through
        } catch (RepositoryException re) {
            // fall through
        }
        return false;
    }

    /**
     * @see javax.jcr.nodetype.NodeType#canAddChildNode(String, String) 
     */
    public boolean canAddChildNode(String childNodeName, String nodeTypeName) {
        try {
            Name ntName = resolver().getQName(nodeTypeName);
            QNodeTypeDefinition def = ntMgr.getNodeTypeDefinition(ntName);
            ent.checkAddNodeConstraints(resolver().getQName(childNodeName), def, definitionProvider());
            return true;
        } catch (NameException be) {
            // implementation specific exception, fall through
        } catch (RepositoryException re) {
            // fall through
        }
        return false;
    }

    /**
     * @see javax.jcr.nodetype.NodeType#canRemoveItem(String) 
     */
    public boolean canRemoveItem(String itemName) {
        try {
            ent.checkRemoveItemConstraints(resolver().getQName(itemName));
            return true;
        } catch (NameException be) {
            // implementation specific exception, fall through
        } catch (RepositoryException re) {
            // fall through
        }
        return false;
    }

    /**
     * @see javax.jcr.nodetype.NodeType#canRemoveNode(String)
     */
    public boolean canRemoveNode(String nodeName) {
        Name name;
        try {
            name = resolver().getQName(nodeName);
        } catch (RepositoryException e) {
            // should never get here
            log.warn("Unable to determine if there are any remove constraints for a node with name " + nodeName);
            return false;
        }
        return !ent.hasRemoveNodeConstraint(name);

    }

    /**
     * @see javax.jcr.nodetype.NodeType#canRemoveProperty(String)
     */
    public boolean canRemoveProperty(String propertyName) {
        Name name;
        try {
            name = resolver().getQName(propertyName);
        } catch (RepositoryException e) {
            // should never get here
            log.warn("Unable to determine if there are any remove constraints for a property with name " + propertyName);
            return false;
        }
        return !ent.hasRemovePropertyConstraint(name);
    }
}