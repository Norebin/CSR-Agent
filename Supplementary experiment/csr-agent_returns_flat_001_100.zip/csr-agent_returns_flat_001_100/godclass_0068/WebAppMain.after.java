public class WebAppMain implements ServletContextListener {

    /**
     * System property name to force the session tracking by cookie.
     * This prevents Tomcat to use the URL tracking in addition to the cookie by default.
     * This could be useful for instances that requires to have
     * the {@link jenkins.security.SuspiciousRequestFilter#allowSemicolonsInPath} turned off.
     * <p>
     * If you allow semicolon in URL and the session to be tracked by URL and you have
     * a SecurityRealm that does not invalidate session after authentication,
     * your instance is vulnerable to session hijacking.
     * <p>
     * The SecurityRealm should be corrected but this is a hardening in Jenkins core.
     * <p>
     * As this property is read during startup, you will not be able to change it at runtime
     * depending on your application server (not possible with Jetty nor Tomcat)
     * <p>
     * When running hpi:run, the default tracking is COOKIE+URL.
     * When running java -jar with Winstone/Jetty, the default setting is set to COOKIE only.
     * When running inside Tomcat, the default setting is COOKIE+URL.
     */
    @Restricted(NoExternalUse.class)
    public static final String FORCE_SESSION_TRACKING_BY_COOKIE_PROP = WebAppMain.class.getName() + ".forceSessionTrackingByCookie";

    private final RingBufferLogHandler handler = new RingBufferLogHandler(WebAppMain.getDefaultRingBufferSize()) {

        @Override public synchronized void publish(LogRecord record) {
            if (record.getLevel().intValue() >= Level.INFO.intValue()) {
                super.publish(record);
            }
        }
    };

    /**
     * This getter returns the int DEFAULT_RING_BUFFER_SIZE from the class RingBufferLogHandler from a static context.
     * Exposes access from RingBufferLogHandler.DEFAULT_RING_BUFFER_SIZE to WebAppMain.
     * Written for the requirements of JENKINS-50669
     * @return int This returns DEFAULT_RING_BUFFER_SIZE
     * @see <a href="https://issues.jenkins.io/browse/JENKINS-50669">JENKINS-50669</a>
     * @since 2.259
     */
    public static int getDefaultRingBufferSize() {
        return RingBufferLogHandler.getDefaultRingBufferSize();
    }

    private static final String APP = "app";
    private boolean terminated;
    private Thread initThread;

    /**
     * Creates the sole instance of {@link jenkins.model.Jenkins} and register it to the {@link ServletContext}.
     */
    @Override
@Override
public void contextInitialized(ServletContextEvent event) {
    ServletContextLifecycleManager lifecycleManager = new ServletContextLifecycleManager(this, event);
    lifecycleManager.contextInitialized();
}
    public void joinInit() throws InterruptedException {
        initThread.join();
    }

    /**
     * To assist boot failure script, record the number of boot attempts.
     * This file gets deleted in case of successful boot.
     *
     * @see BootFailure
     */
    private void recordBootAttempt(File home) {
        try (OutputStream o = Files.newOutputStream(BootFailure.getBootFailureFile(home).toPath(), StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            o.write((new Date() + System.getProperty("line.separator", "\n")).getBytes(Charset.defaultCharset()));
        } catch (IOException | InvalidPathException e) {
            LOGGER.log(WARNING, "Failed to record boot attempts", e);
        }
    }

    /**
     * @since 2.475
     */
    public static void installExpressionFactory(ServletContextEvent event) {
        JellyFacet.setExpressionFactory(event, new ExpressionFactory2());
    }

    /**
     * @deprecated use {@link #installExpressionFactory(ServletContextEvent)}
     */
    @Deprecated
    public static void installExpressionFactory(javax.servlet.ServletContextEvent event) {
        installExpressionFactory(ServletContextEventWrapper.toJakartaServletContextEvent(event));
    }

    /**
     * Installs log handler to monitor all Hudson logs.
     */
    private void installLogger() {
        Jenkins.logRecords = handler.getView();
        Logger.getLogger("").addHandler(handler);
    }

    /** Add some metadata to a File, allowing to trace setup issues */
    public static class FileAndDescription {
        public final File file;
        public final String description;

        public FileAndDescription(File file, String description) {
            this.file = file;
            this.description = description;
        }
    }

    /**
     * Determines the home directory for Jenkins.
     *
     * <p>We look for a setting that affects the smallest scope first, then bigger ones later.
     *
     * <p>People make configuration mistakes, so we are trying to be nice
     * with those by doing {@link String#trim()}.
     *
     * @return the File alongside with some description to help the user troubleshoot issues
     */
    public FileAndDescription getHomeDir(ServletContextEvent event) {
        // check the system property for the home directory first
        for (String name : HOME_NAMES) {
            String sysProp = SystemProperties.getString(name);
            if (sysProp != null)
                return new FileAndDescription(new File(sysProp.trim()), "SystemProperties.getProperty(\"" + name + "\")");
        }

        // look at the env var next
        for (String name : HOME_NAMES) {
            String env = EnvVars.masterEnvVars.get(name);
            if (env != null)
                return new FileAndDescription(new File(env.trim()).getAbsoluteFile(), "EnvVars.masterEnvVars.get(\"" + name + "\")");
        }

        // otherwise pick a place by ourselves

        String root = event.getServletContext().getRealPath("/WEB-INF/workspace");
        if (root != null) {
            File ws = new File(root.trim());
            if (ws.exists())
                // Hudson <1.42 used to prefer this before ~/.hudson, so
                // check the existence and if it's there, use it.
                // otherwise if this is a new installation, prefer ~/.hudson
                return new FileAndDescription(ws, "getServletContext().getRealPath(\"/WEB-INF/workspace\")");
        }

        File legacyHome = new File(new File(System.getProperty("user.home")), ".hudson");
        if (legacyHome.exists()) {
            return new FileAndDescription(legacyHome, "$user.home/.hudson"); // before rename, this is where it was stored
        }

        File newHome = new File(new File(System.getProperty("user.home")), ".jenkins");
        return new FileAndDescription(newHome, "$user.home/.jenkins");
    }

    @Override
@Override
public void contextDestroyed(ServletContextEvent event) {
    ServletContextLifecycleManager lifecycleManager = new ServletContextLifecycleManager(this, event);
    lifecycleManager.contextDestroyed();
}
    private static final Logger LOGGER = Logger.getLogger(WebAppMain.class.getName());

    private static final class JenkinsJVMAccess extends JenkinsJVM {
        private static void _setJenkinsJVM(boolean jenkinsJVM) {
            JenkinsJVM.setJenkinsJVM(jenkinsJVM);
        }
    }

    private static final String[] HOME_NAMES = {"JENKINS_HOME", "HUDSON_HOME"};
}