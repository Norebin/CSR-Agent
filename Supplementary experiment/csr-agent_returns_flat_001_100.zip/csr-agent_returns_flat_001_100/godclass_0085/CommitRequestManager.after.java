public class CommitRequestManager implements RequestManager, MemberStateListener {
    private final Time time;
    private final SubscriptionState subscriptions;
    private final ConsumerMetadata metadata;
    private final LogContext logContext;
    private final Logger log;
    private final Optional<AutoCommitState> autoCommitState;
    private final CoordinatorRequestManager coordinatorRequestManager;
    private final OffsetCommitCallbackInvoker offsetCommitCallbackInvoker;
    private final OffsetCommitMetricsManager metricsManager;
    private final long retryBackoffMs;
    private final String groupId;
    private final Optional<String> groupInstanceId;
    private final long retryBackoffMaxMs;
    // For testing only
    private final OptionalDouble jitter;
    private final boolean throwOnFetchStableOffsetUnsupported;
    final PendingRequests pendingRequests;
    private boolean closing = false;

    /**
     * Last member epoch sent in a commit request. Empty if no epoch was included in the last
     * request. Used for logging.
     */
    private Optional<Integer> lastEpochSentOnCommit;

    /**
     *  The member ID and latest member epoch received via the {@link MemberStateListener#onMemberEpochUpdated(Optional, String)},
     *  to be included in the OffsetFetch and OffsetCommit requests. This will have
     *  the latest memberEpoch received from the broker.
     */
    private final MemberInfo memberInfo;

    public CommitRequestManager(
        final Time time,
        final LogContext logContext,
        final SubscriptionState subscriptions,
        final ConsumerConfig config,
        final CoordinatorRequestManager coordinatorRequestManager,
        final OffsetCommitCallbackInvoker offsetCommitCallbackInvoker,
        final String groupId,
        final Optional<String> groupInstanceId,
        final Metrics metrics,
        final ConsumerMetadata metadata) {
        this(time,
            logContext,
            subscriptions,
            config,
            coordinatorRequestManager,
            offsetCommitCallbackInvoker,
            groupId,
            groupInstanceId,
            config.getLong(ConsumerConfig.RETRY_BACKOFF_MS_CONFIG),
            config.getLong(ConsumerConfig.RETRY_BACKOFF_MAX_MS_CONFIG),
            OptionalDouble.empty(),
            metrics,
            metadata);
    }

    // Visible for testing
    CommitRequestManager(
        final Time time,
        final LogContext logContext,
        final SubscriptionState subscriptions,
        final ConsumerConfig config,
        final CoordinatorRequestManager coordinatorRequestManager,
        final OffsetCommitCallbackInvoker offsetCommitCallbackInvoker,
        final String groupId,
        final Optional<String> groupInstanceId,
        final long retryBackoffMs,
        final long retryBackoffMaxMs,
        final OptionalDouble jitter,
        final Metrics metrics,
        final ConsumerMetadata metadata) {
        Objects.requireNonNull(coordinatorRequestManager, "Coordinator is needed upon committing offsets");
        this.time = time;
        this.logContext = logContext;
        this.log = logContext.logger(getClass());
        this.pendingRequests = new PendingRequests();
        if (config.getBoolean(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG)) {
            final long autoCommitInterval =
                Integer.toUnsignedLong(config.getInt(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG));
            this.autoCommitState = Optional.of(new AutoCommitState(time, autoCommitInterval, logContext));
        } else {
            this.autoCommitState = Optional.empty();
        }
        this.coordinatorRequestManager = coordinatorRequestManager;
        this.groupId = groupId;
        this.groupInstanceId = groupInstanceId;
        this.subscriptions = subscriptions;
        this.metadata = metadata;
        this.retryBackoffMs = retryBackoffMs;
        this.retryBackoffMaxMs = retryBackoffMaxMs;
        this.jitter = jitter;
        this.throwOnFetchStableOffsetUnsupported = config.getBoolean(THROW_ON_FETCH_STABLE_OFFSET_UNSUPPORTED);
        this.memberInfo = new MemberInfo();
        this.metricsManager = new OffsetCommitMetricsManager(metrics);
        this.offsetCommitCallbackInvoker = offsetCommitCallbackInvoker;
        this.lastEpochSentOnCommit = Optional.empty();
    }

    /**
     * Poll for the {@link OffsetFetchRequest} and {@link OffsetCommitRequest} request if there's any.
     */
    @Override
@Override
public NetworkClientDelegate.PollResult poll(final long currentTimeMs) {
    // poll when the coordinator node is known and fatal error is not present
    if (coordinatorRequestManager.coordinator().isEmpty()) {
        pendingRequests.maybeFailOnCoordinatorFatalError();

        if (closing && pendingRequests.hasUnsentRequests()) {
            CommitFailedException exception = new CommitFailedException(
                    "Failed to commit offsets: Coordinator unknown and consumer is closing");
            pendingRequests.drainPendingCommits()
                    .forEach(request -> request.future().completeExceptionally(exception));
        }

        return EMPTY;
    }

    if (closing) {
        return drainPendingOffsetCommitRequests();
    }

    if (!pendingRequests.hasUnsentRequests())
        return EMPTY;

    List<NetworkClientDelegate.UnsentRequest> requests = pendingRequests.drain(currentTimeMs);
    // min of the remainingBackoffMs of all the request that are still backing off
    final long timeUntilNextPoll = Math.min(
        findMinTime(unsentOffsetCommitRequests(), currentTimeMs),
        findMinTime(unsentOffsetFetchRequests(), currentTimeMs));
    return new NetworkClientDelegate.PollResult(timeUntilNextPoll, requests);
}
    @Override
    public void signalClose() {
        closing = true;
    }

    /**
     * Returns the delay for which the application thread can safely wait before it should be responsive
     * to results from the request managers. For example, the subscription state can change when heartbeats
     * are sent, so blocking for longer than the heartbeat interval might mean the application thread is not
     * responsive to changes.
     */
    @Override
    public long maximumTimeToWait(long currentTimeMs) {
        if (autoCommitState.isEmpty()) {
            return Long.MAX_VALUE;
        }
        AutoCommitState autoCommit = autoCommitState.get();
        // An auto-commit is only sent when the coordinator is known; poll() returns EMPTY otherwise.
        // If the coordinator is unavailable (e.g. bootstrap DNS resolution is still in progress),
        // falling through to the timer-based remainingMs() would return 0 once the auto-commit interval
        // elapses, since the auto-commit timer remains permanently expired. This would cause both the
        // application and network threads to busy-spin. Wait a retry backoff instead of the auto-commit
        // interval, which may be configured to zero and is consistent with the other request managers.
        if (coordinatorRequestManager.coordinator().isEmpty()) {
            return retryBackoffMs;
        }
        return autoCommit.remainingMs(currentTimeMs);
    }

    private static long findMinTime(final Collection<? extends RequestState> requests, final long currentTimeMs) {
        return requests.stream()
            .mapToLong(request -> request.remainingBackoffMs(currentTimeMs))
            .min()
            .orElse(Long.MAX_VALUE);
    }

    private KafkaException maybeWrapAsTimeoutException(Throwable t) {
        if (t instanceof TimeoutException)
            return (TimeoutException) t;
        else
            return new TimeoutException(t);
    }

    /**
     * Generate a request to commit consumed offsets. Add the request to the queue of pending
     * requests to be sent out on the next call to {@link #poll(long)}. If there are empty
     * offsets to commit, no request will be generated and a completed future will be returned.
     *
     * @param requestState Commit request
     * @return Future containing the offsets that were committed, or an error if the request
     * failed.
     */
    private CompletableFuture<Map<TopicPartition, OffsetAndMetadata>> requestAutoCommit(final OffsetCommitRequestState requestState) {
        AutoCommitState autocommit = autoCommitState.get();
        CompletableFuture<Map<TopicPartition, OffsetAndMetadata>> result;
        if (requestState.offsets.isEmpty()) {
            result = CompletableFuture.completedFuture(Collections.emptyMap());
        } else {
            autocommit.setInflightCommitStatus(true);
            OffsetCommitRequestState request = pendingRequests.addOffsetCommitRequest(requestState);
            result = request.future;
            result.whenComplete(autoCommitCallback(request.offsets));
        }
        return result;
    }

    /**
     * If auto-commit is enabled, and the auto-commit interval has expired, this will generate and
     * enqueue a request to commit all consumed offsets, and will reset the auto-commit timer to the
     * interval. The request will be sent on the next call to {@link #poll(long)}.
     * <p/>
     * If the request completes with a retriable error, this will reset the auto-commit timer with
     * the exponential backoff. If it fails with a non-retriable error, no action is taken, so
     * the next commit will be generated when the interval expires.
     * <p/>
     * This will not generate a new commit request if a previous one hasn't received a response.
     * In that case, the next auto-commit request will be sent on the next call to poll, after a
     * response for the in-flight is received.
     */
private void maybeAutoCommitAsync() {
    if (autoCommitEnabled() && autoCommitState.get().shouldAutoCommit()) {
        OffsetCommitRequestState requestState = createOffsetCommitRequest(
            subscriptions.allConsumed(),
            Long.MAX_VALUE);
        CompletableFuture<Map<TopicPartition, OffsetAndMetadata>> result = requestAutoCommit(requestState);
        // Reset timer to the interval (even if no request was generated), but ensure that if
        // the request completes with a retriable error, the timer is reset to send the next
        // auto-commit after the backoff expires.
        resetAutoCommitTimer();
        maybeResetTimerWithBackoff(result);
    }
}
    /**
     * Reset auto-commit timer to retry with backoff if the future failed with a RetriableCommitFailedException.
     */
    private void maybeResetTimerWithBackoff(final CompletableFuture<Map<TopicPartition, OffsetAndMetadata>> result) {
        result.whenComplete((offsets, error) -> {
            if (error != null) {
                if (error instanceof RetriableCommitFailedException) {
                    log.debug("Asynchronous auto-commit of offsets {} failed due to retriable error.", offsets, error);
                    resetAutoCommitTimer(retryBackoffMs);
                } else {
                    log.debug("Asynchronous auto-commit of offsets {} failed: {}", offsets, error.getMessage());
                }
            } else {
                log.debug("Completed asynchronous auto-commit of offsets {}", offsets);
            }
        });
    }

    /**
     * Commit consumed offsets if auto-commit is enabled, regardless of the auto-commit interval.
     * This is used for committing offsets before rebalance. This will retry committing
     * the latest offsets until the request succeeds, fails with a fatal error, or the timeout
     * expires. Note that:
     * <ul>
     *     <li>Considers {@link Errors#STALE_MEMBER_EPOCH} as a retriable error, and will retry it
     *     including the member ID and latest member epoch received from the broker.</li>
     *     <li>Considers {@link Errors#UNKNOWN_TOPIC_OR_PARTITION} as a fatal error, and will not
     *     retry it although the error extends RetriableException. The reason is that if a topic
     *     or partition is deleted, rebalance would not finish in time since the auto commit would keep retrying.</li>
     * </ul>
     *
     * Also note that this will generate a commit request even if there is another one in-flight,
     * generated by the auto-commit on the interval logic, to ensure that the latest offsets are
     * committed before rebalance.
     *
     * @return Future that will complete when the offsets are successfully committed. It will
     * complete exceptionally if the commit fails with a non-retriable error, or if the retry
     * timeout expires.
     */
    public CompletableFuture<Void> maybeAutoCommitSyncBeforeRebalance(final long deadlineMs) {
        if (!autoCommitEnabled()) {
            return CompletableFuture.completedFuture(null);
        }

        CompletableFuture<Void> result = new CompletableFuture<>();
        OffsetCommitRequestState requestState =
            createOffsetCommitRequest(subscriptions.allConsumed(), deadlineMs);
        autoCommitSyncBeforeRebalanceWithRetries(requestState, result);
        return result;
    }

    private void autoCommitSyncBeforeRebalanceWithRetries(OffsetCommitRequestState requestAttempt,
                                                          CompletableFuture<Void> result) {
        CompletableFuture<Map<TopicPartition, OffsetAndMetadata>> commitAttempt = requestAutoCommit(requestAttempt);
        commitAttempt.whenComplete((committedOffsets, error) -> {
            if (error == null) {
                result.complete(null);
            } else {
                if (error instanceof RetriableException || isStaleEpochErrorAndValidEpochAvailable(error)) {
                    if (requestAttempt.isExpired()) {
                        log.debug("Auto-commit sync before rebalance timed out and won't be retried anymore");
                        result.completeExceptionally(maybeWrapAsTimeoutException(error));
                    } else if (error instanceof UnknownTopicOrPartitionException) {
                        log.debug("Auto-commit sync before rebalance failed because topic or partition were deleted");
                        result.completeExceptionally(error);
                    } else {
                        // Make sure the auto-commit is retried with the latest offsets
                        log.debug("Member {} will retry auto-commit of latest offsets after receiving retriable error {}",
                            memberInfo.memberId,
                            error.getMessage());
                        requestAttempt.offsets = subscriptions.allConsumed();
                        requestAttempt.resetFuture();
                        autoCommitSyncBeforeRebalanceWithRetries(requestAttempt, result);
                    }
                } else {
                    log.debug("Auto-commit sync before rebalance failed with non-retriable error", error);
                    result.completeExceptionally(error);
                }
            }
        });
    }

    /**
     * Clear the inflight auto-commit flag and log auto-commit completion status.
     */
    private BiConsumer<? super Map<TopicPartition, OffsetAndMetadata>, ? super Throwable> autoCommitCallback(final Map<TopicPartition, OffsetAndMetadata> allConsumedOffsets) {
        return (response, throwable) -> {
            autoCommitState.ifPresent(autoCommitState -> autoCommitState.setInflightCommitStatus(false));
            if (throwable == null) {
                offsetCommitCallbackInvoker.enqueueInterceptorInvocation(allConsumedOffsets);
                log.debug("Completed auto-commit of offsets {}", allConsumedOffsets);
            } else if (throwable instanceof RetriableCommitFailedException) {
                log.debug("Auto-commit of offsets {} failed due to retriable error: {}",
                        allConsumedOffsets, throwable.getMessage());
            } else {
                log.warn("Auto-commit of offsets {} failed", allConsumedOffsets, throwable);
            }
        };
    }

    /**
     * Generate a request to commit offsets without retrying, even if it fails with a retriable
     * error. The generated request will be added to the queue to be sent on the next call to
     * {@link #poll(long)}.
     *
     * @param offsets Offsets to commit per partition.
     * @return Future that will complete when a response is received, successfully or
     * exceptionally depending on the response. If the request fails with a retriable error, the
     * future will be completed with a {@link RetriableCommitFailedException}.
     */
    public CompletableFuture<Map<TopicPartition, OffsetAndMetadata>> commitAsync(final Map<TopicPartition, OffsetAndMetadata> offsets) {
        if (offsets.isEmpty()) {
            log.debug("Skipping commit of empty offsets");
            return CompletableFuture.completedFuture(Map.of());
        }
        maybeUpdateLastSeenEpochIfNewer(offsets);
        OffsetCommitRequestState commitRequest = createOffsetCommitRequest(offsets, Long.MAX_VALUE);
        pendingRequests.addOffsetCommitRequest(commitRequest);

        CompletableFuture<Map<TopicPartition, OffsetAndMetadata>> asyncCommitResult = new CompletableFuture<>();
        commitRequest.future.whenComplete((committedOffsets, error) -> {
            if (error != null) {
                asyncCommitResult.completeExceptionally(commitAsyncExceptionForError(error));
            } else {
                asyncCommitResult.complete(offsets);
            }
        });
        return asyncCommitResult;
    }

    /**
     * Commit offsets, retrying on expected retriable errors while the retry timeout hasn't expired.
     *
     * @param offsets    Offsets to commit
     * @param deadlineMs Time until which the request will be retried if it fails with
     *                   an expected retriable error.
     * @return Future that will complete when a successful response
     */
    public CompletableFuture<Map<TopicPartition, OffsetAndMetadata>> commitSync(final Map<TopicPartition, OffsetAndMetadata> offsets,
                                                                                final long deadlineMs) {
        if (offsets.isEmpty()) {
            return CompletableFuture.completedFuture(Map.of());
        }
        maybeUpdateLastSeenEpochIfNewer(offsets);
        CompletableFuture<Map<TopicPartition, OffsetAndMetadata>> result = new CompletableFuture<>();
        OffsetCommitRequestState requestState = createOffsetCommitRequest(offsets, deadlineMs);
        commitSyncWithRetries(requestState, result);
        return result;
    }

    private OffsetCommitRequestState createOffsetCommitRequest(final Map<TopicPartition, OffsetAndMetadata> offsets,
                                                               final long deadlineMs) {
        return jitter.isPresent() ?
            new OffsetCommitRequestState(
                offsets,
                groupId,
                groupInstanceId,
                deadlineMs,
                retryBackoffMs,
                retryBackoffMaxMs,
                jitter.getAsDouble(),
                memberInfo) :
            new OffsetCommitRequestState(
                offsets,
                groupId,
                groupInstanceId,
                deadlineMs,
                retryBackoffMs,
                retryBackoffMaxMs,
                memberInfo);
    }

    private void commitSyncWithRetries(OffsetCommitRequestState requestAttempt,
                                       CompletableFuture<Map<TopicPartition, OffsetAndMetadata>> result) {
        pendingRequests.addOffsetCommitRequest(requestAttempt);

        // Retry the same commit request while it fails with RetriableException and the retry
        // timeout hasn't expired.
        requestAttempt.future.whenComplete((res, error) -> {
            if (error == null) {
                result.complete(requestAttempt.offsets);
            } else {
                if (error instanceof RetriableException) {
                    if (requestAttempt.isExpired()) {
                        log.info("OffsetCommit timeout expired so it won't be retried anymore");
                        result.completeExceptionally(maybeWrapAsTimeoutException(error));
                    } else {
                        requestAttempt.resetFuture();
                        commitSyncWithRetries(requestAttempt, result);
                    }
                } else {
                    result.completeExceptionally(commitSyncExceptionForError(error));
                }
            }
        });
    }

    private Throwable commitSyncExceptionForError(Throwable error) {
        if (error instanceof StaleMemberEpochException) {
            return new CommitFailedException("OffsetCommit failed with stale member epoch. "
                + Errors.STALE_MEMBER_EPOCH.message());
        }
        return error;
    }

    private Throwable commitAsyncExceptionForError(Throwable error) {
        if (error instanceof RetriableException) {
            return new RetriableCommitFailedException(error);
        }
        return error;
    }

    /**
     * Enqueue a request to fetch committed offsets, that will be sent on the next call to {@link #poll(long)}.
     * This is used when initializing positions on poll,
     * and for fetching committed offsets from API calls to consumer.committed.
     * This function will retry upon expected retriable errors while the timeout hasn't expired.
     * It will fail fatally with KafkaException for all unexpected errors.
     *
     * @param partitions Partitions to fetch offsets for.
     * @param deadlineMs Time until which the request should be retried if it fails
     *                   with expected retriable errors.
     * @return Future that will complete when a successful response is received, or the request
     * fails and cannot be retried. The result contains both successful offsets and any retriable
     * partition errors (like UNKNOWN_TOPIC_ID) that occurred. Note that the request is retried
     * whenever it fails with expected retriable errors and the retry timeout hasn't expired.
     */
    public CompletableFuture<OffsetFetchResult> fetchOffsets(
        final Set<TopicPartition> partitions,
        final long deadlineMs) {
        if (partitions.isEmpty()) {
            return CompletableFuture.completedFuture(new OffsetFetchResult(Collections.emptyMap(), Collections.emptyMap()));
        }
        CompletableFuture<OffsetFetchResult> result = new CompletableFuture<>();
        OffsetFetchRequestState request = createOffsetFetchRequest(partitions, deadlineMs);
        fetchOffsetsWithRetries(request, result);
        return result;
    }

    // Visible for testing
    OffsetFetchRequestState createOffsetFetchRequest(final Set<TopicPartition> partitions,
                                                             final long deadlineMs) {
        return jitter.isPresent() ?
            new OffsetFetchRequestState(
                partitions,
                retryBackoffMs,
                retryBackoffMaxMs,
                deadlineMs,
                jitter.getAsDouble(),
                memberInfo) :
            new OffsetFetchRequestState(
                partitions,
                retryBackoffMs,
                retryBackoffMaxMs,
                deadlineMs,
                memberInfo);
    }

    private void fetchOffsetsWithRetries(final OffsetFetchRequestState fetchRequest,
private void fetchOffsetsWithRetries(final OffsetFetchRequestState fetchRequest,
                                     final CompletableFuture<OffsetFetchResult> result) {
    CompletableFuture<OffsetFetchResult> currentResult = pendingRequests.addOffsetFetchRequest(fetchRequest);

    // Retry the same fetch request while it fails with RetriableException and the retry timeout hasn't expired.
    currentResult.whenComplete((res, error) -> {
        boolean inflightRemoved = pendingRequests.inflightOffsetFetches.remove(fetchRequest);
        if (!inflightRemoved) {
            // A completed request may legitimately not be in the in-flight buffer for a few
            // reasons: it was deduplicated and chained onto an existing request (so it was never
            // added to the buffers), or it completed before it was ever sent (e.g. while there
            // was no coordinator available). In all these cases there is nothing to remove here.
            log.debug("Completed offset fetch request was not found in the in-flight buffer: {}",
                fetchRequest);
        }

        // Group-level error
        if (error != null) {
            handleGroupLevelError(fetchRequest, result, error);
            return;
        }

        // Partition-level errors
        if (res.hasRetriablePartitionErrors()) {
            handleRetriablePartitionErrors(fetchRequest, result, res);
            return;
        }

        handleSuccessfulOffsetFetch(result, res);

    });
}    }

    /**
     * Handles a successful offset fetch response with no errors.
     */
    private void handleSuccessfulOffsetFetch(final CompletableFuture<OffsetFetchResult> result,
                                             final OffsetFetchResult res) {
        maybeUpdateLastSeenEpochIfNewer(res.offsets());
        result.complete(res);
    }

    /**
     * Handles group-level errors from an offset fetch request.
     * Group-level errors indicate the entire request failed (e.g., coordinator unavailable).
     */
    private void handleGroupLevelError(final OffsetFetchRequestState fetchRequest,
                                       final CompletableFuture<OffsetFetchResult> result,
                                       final Throwable error) {
        boolean isRetriable = (error instanceof RetriableException) ||
            isStaleEpochErrorAndValidEpochAvailable(error);

        if (!isRetriable) {
            result.completeExceptionally(error);
            return;
        }

        if (fetchRequest.isExpired()) {
            log.debug("OffsetFetch request for {} timed out and won't be retried anymore",
                fetchRequest.requestedPartitions);
            result.completeExceptionally(maybeWrapAsTimeoutException(error));
            return;
        }

        retryOffsetFetchOnError(fetchRequest, result, "retriable error: " + error.getMessage());
    }

    /**
     * Handles retriable partition-level errors from an offset fetch response.
     *
     * <p>The only retriable partition errors are UNKNOWN_TOPIC_ID and UNKNOWN_TOPIC_OR_PARTITION.
     * When expired or not enough time for another retry, we return partial results with null for
     * the errored partitions. We check against {@code remainingBackoffMs} to ensure we complete
     * before the {@link org.apache.kafka.clients.consumer.internals.events.CompletableEventReaper}
     * expires the event with TimeoutException.
     */
    private void handleRetriablePartitionErrors(final OffsetFetchRequestState fetchRequest,
                                            final CompletableFuture<OffsetFetchResult> result,
                                            final OffsetFetchResult res) {
        long currentTimeMs = time.milliseconds();

        // Return partial results if there is no time for another retry.
        // We check against remainingBackoffMs to ensure we complete before the
        // CompletableEventReaper expires the event with TimeoutException.
        if (fetchRequest.isExpired() || fetchRequest.remainingMs() <= fetchRequest.remainingBackoffMs(currentTimeMs)) {
            log.debug("OffsetFetch request for partitions {} returning partial results with some partition errors {}",
                fetchRequest.requestedPartitions, res.retriablePartitionErrors().keySet());
            maybeUpdateLastSeenEpochIfNewer(res.offsets());
            result.complete(res);
            return;
        }

        retryOffsetFetchOnError(fetchRequest, result,
            "retriable partition errors: " + res.retriablePartitionErrors().keySet());
    }

    /**
     * Retries an offset fetch request after an error.
     */
    private void retryOffsetFetchOnError(final OffsetFetchRequestState fetchRequest,
                                         final CompletableFuture<OffsetFetchResult> result,
                                         final String reason) {
        log.debug("OffsetFetch request for {} retrying due to {}",
            fetchRequest.requestedPartitions, reason);
        fetchRequest.resetFuture();
        fetchOffsetsWithRetries(fetchRequest, result);
    }

    private boolean isStaleEpochErrorAndValidEpochAvailable(Throwable error) {
        return error instanceof StaleMemberEpochException && memberInfo.memberEpoch.isPresent();
    }

    private void updateAutoCommitTimer(final long currentTimeMs) {
        this.autoCommitState.ifPresent(t -> t.updateTimer(currentTimeMs));
    }

    // Visible for testing
    Queue<OffsetCommitRequestState> unsentOffsetCommitRequests() {
        return pendingRequests.unsentOffsetCommits;
    }

    private List<OffsetFetchRequestState> unsentOffsetFetchRequests() {
        return pendingRequests.unsentOffsetFetches;
    }

    /**
     * Update latest member epoch used by the member.
     *
     * @param memberEpoch New member epoch received. To be included in the new request.
     * @param memberId Current member ID. To be included in the new request.
     */
    @Override
    public void onMemberEpochUpdated(Optional<Integer> memberEpoch, String memberId) {
        if (memberEpoch.isEmpty() && memberInfo.memberEpoch.isPresent()) {
            log.info("Member {} won't include epoch in following offset " +
                "commit/fetch requests because it has left the group.", memberInfo.memberId);
        } else if (memberEpoch.isPresent()) {
            log.debug("Member {} will include new member epoch {} in following offset commit/fetch requests.", memberId, memberEpoch);
        }
        memberInfo.memberId = memberId;
        memberInfo.memberEpoch = memberEpoch;
    }

    /**
     * @return True if auto-commit is enabled as defined in the config {@link ConsumerConfig#ENABLE_AUTO_COMMIT_CONFIG}
     */
    public boolean autoCommitEnabled() {
        return autoCommitState.isPresent();
    }

    /**
     * Reset the auto-commit timer to the auto-commit interval, so that the next auto-commit is
     * sent out on the interval starting from now. If auto-commit is not enabled this will
     * perform no action.
     */
    public void resetAutoCommitTimer() {
        autoCommitState.ifPresent(AutoCommitState::resetTimer);
    }

    /**
     * Reset the auto-commit timer to the provided time (backoff), so that the next auto-commit is
     * sent out then. If auto-commit is not enabled this will perform no action.
     */
    public void resetAutoCommitTimer(long retryBackoffMs) {
        autoCommitState.ifPresent(s -> s.resetTimer(retryBackoffMs));
    }

    /**
     * Drains the inflight offsetCommits during shutdown because we want to make sure all pending commits are sent
     * before closing.
     */
    public NetworkClientDelegate.PollResult drainPendingOffsetCommitRequests() {
        if (pendingRequests.unsentOffsetCommits.isEmpty())
            return EMPTY;
        List<NetworkClientDelegate.UnsentRequest> requests = pendingRequests.drainPendingCommits();
        return new NetworkClientDelegate.PollResult(Long.MAX_VALUE, requests);
    }

    private void maybeUpdateLastSeenEpochIfNewer(final Map<TopicPartition, OffsetAndMetadata> offsets) {
        offsets.forEach((topicPartition, offsetAndMetadata) -> {
            if (offsetAndMetadata != null)
                offsetAndMetadata.leaderEpoch().ifPresent(epoch -> metadata.updateLastSeenEpochIfNewer(topicPartition, epoch));
        });
    }

    /**
     * This is a non-blocking method to update timer and trigger async auto-commit.
     * <p>
     * This method performs two main tasks:
     * <ol>
     * <li>Updates the internal timer with the current time.</li>
     * <li>Initiate an asynchronous auto-commit operation for all consumed positions if needed.</li>
     * </ol>
     *
     * @param currentTimeMs the current timestamp in millisecond
     * @see CommitRequestManager#updateAutoCommitTimer(long)
     * @see CommitRequestManager#maybeAutoCommitAsync()
     */
    public void updateTimerAndMaybeCommit(final long currentTimeMs) {
        updateAutoCommitTimer(currentTimeMs);
        maybeAutoCommitAsync();
    }

    class OffsetCommitRequestState extends RetriableRequestState {
        private Map<TopicPartition, OffsetAndMetadata> offsets;
        private final String groupId;
        private final Optional<String> groupInstanceId;

        /**
         * Future containing the offsets that were committed. It completes when a response is
         * received for the commit request.
         */
        private CompletableFuture<Map<TopicPartition, OffsetAndMetadata>> future;

        OffsetCommitRequestState(final Map<TopicPartition, OffsetAndMetadata> offsets,
                                 final String groupId,
                                 final Optional<String> groupInstanceId,
                                 final long deadlineMs,
                                 final long retryBackoffMs,
                                 final long retryBackoffMaxMs,
                                 final MemberInfo memberInfo) {
            super(logContext, CommitRequestManager.class.getSimpleName(), retryBackoffMs,
                retryBackoffMaxMs, memberInfo, deadlineTimer(time, deadlineMs));
            this.offsets = offsets;
            this.groupId = groupId;
            this.groupInstanceId = groupInstanceId;
            this.future = new CompletableFuture<>();
        }

        // Visible for testing
        OffsetCommitRequestState(final Map<TopicPartition, OffsetAndMetadata> offsets,
                                 final String groupId,
                                 final Optional<String> groupInstanceId,
                                 final long deadlineMs,
                                 final long retryBackoffMs,
                                 final long retryBackoffMaxMs,
                                 final double jitter,
                                 final MemberInfo memberInfo) {
            super(logContext, CommitRequestManager.class.getSimpleName(), retryBackoffMs, 2,
                retryBackoffMaxMs, jitter, memberInfo, deadlineTimer(time, deadlineMs));
            this.offsets = offsets;
            this.groupId = groupId;
            this.groupInstanceId = groupInstanceId;
            this.future = new CompletableFuture<>();
        }

        public NetworkClientDelegate.UnsentRequest toUnsentRequest() {
            Map<String, Uuid> topicIds = metadata.topicIds();
            boolean canUseTopicIds = true;
            Map<String, OffsetCommitRequestData.OffsetCommitRequestTopic> requestTopicDataMap = new HashMap<>();
            for (Map.Entry<TopicPartition, OffsetAndMetadata> entry : offsets.entrySet()) {
                TopicPartition topicPartition = entry.getKey();
                OffsetAndMetadata offsetAndMetadata = entry.getValue();
                Uuid topicId = topicIds.getOrDefault(topicPartition.topic(), Uuid.ZERO_UUID);
                if (topicId.equals(Uuid.ZERO_UUID)) {
                    canUseTopicIds = false;
                }

                OffsetCommitRequestData.OffsetCommitRequestTopic topic = requestTopicDataMap
                    .getOrDefault(topicPartition.topic(),
                        new OffsetCommitRequestData.OffsetCommitRequestTopic()
                            .setName(topicPartition.topic())
                            .setTopicId(topicId)
                    );

                topic.partitions().add(new OffsetCommitRequestData.OffsetCommitRequestPartition()
                    .setPartitionIndex(topicPartition.partition())
                    .setCommittedOffset(offsetAndMetadata.offset())
                    .setCommittedLeaderEpoch(offsetAndMetadata.leaderEpoch().orElse(RecordBatch.NO_PARTITION_LEADER_EPOCH))
                    .setCommittedMetadata(offsetAndMetadata.metadata())
                );
                requestTopicDataMap.put(topicPartition.topic(), topic);
            }

            OffsetCommitRequestData data = new OffsetCommitRequestData()
                    .setGroupId(this.groupId)
                    .setGroupInstanceId(groupInstanceId.orElse(null))
                    .setTopics(new ArrayList<>(requestTopicDataMap.values()));
            data = data.setMemberId(memberInfo.memberId);
            if (memberInfo.memberEpoch.isPresent()) {
                data = data.setGenerationIdOrMemberEpoch(memberInfo.memberEpoch.get());
                lastEpochSentOnCommit = memberInfo.memberEpoch;
            } else {
                lastEpochSentOnCommit = Optional.empty();
            }

            OffsetCommitRequest.Builder builder = canUseTopicIds
                    ? OffsetCommitRequest.Builder.forTopicIdsOrNames(data)
                    : OffsetCommitRequest.Builder.forTopicNames(data);

            return buildRequestWithResponseHandling(builder);
        }

        /**
         * Handle OffsetCommitResponse. This will complete the request future successfully if no
         * errors are found in the response. If the response contains errors, this will:
         *   - handle expected errors and fail the future with specific exceptions depending on the error
         *   - fail the future with a non-recoverable KafkaException for all unexpected errors (even if retriable)
         */
        @Override
        @SuppressWarnings("NPathComplexity")
        public void onResponse(final ClientResponse response) {
            metricsManager.recordRequestLatency(response.requestLatencyMs());
            long currentTimeMs = response.receivedTimeMs();
            OffsetCommitResponse commitResponse = (OffsetCommitResponse) response.responseBody();
            Set<String> unauthorizedTopics = new HashSet<>();
            boolean failedRequestRegistered = false;
            for (OffsetCommitResponseData.OffsetCommitResponseTopic topic : commitResponse.data().topics()) {
                for (OffsetCommitResponseData.OffsetCommitResponsePartition partition : topic.partitions()) {
                    // Version 10 drops topic name, and supports topic id.
                    // We need to find offsetAndMetadata based on topic id and partition index only as
                    // topic name in the response will be emtpy.
                    // For older versions, topic id is zero, and we will find the offsetAndMetadata based on the topic name.
                    TopicPartition tp = (!Uuid.ZERO_UUID.equals(topic.topicId()) && metadata.topicNames().containsKey(topic.topicId())) ?
                        new TopicPartition(metadata.topicNames().get(topic.topicId()), partition.partitionIndex()) :
                        new TopicPartition(topic.name(), partition.partitionIndex());

                    Errors error = Errors.forCode(partition.errorCode());
                    if (error == Errors.NONE) {
                        OffsetAndMetadata offsetAndMetadata = offsets.get(tp);
                        if (offsetAndMetadata == null) {
                            log.debug("Can't find metadata for partition {}", tp);
                        } else {
                            log.debug("OffsetCommit completed successfully for offset {} partition {}", offsetAndMetadata.offset(), tp);
                        }
                        continue;
                    }

                    if (!failedRequestRegistered) {
                        onFailedAttempt(currentTimeMs);
                        failedRequestRegistered = true;
                    }

                    if (error == Errors.GROUP_AUTHORIZATION_FAILED) {
                        future.completeExceptionally(GroupAuthorizationException.forGroupId(groupId));
                        return;
                    } else if (error == Errors.COORDINATOR_NOT_AVAILABLE ||
                        error == Errors.NOT_COORDINATOR ||
                        error == Errors.REQUEST_TIMED_OUT) {
                        coordinatorRequestManager.markCoordinatorUnknown(error.message(), currentTimeMs);
                        future.completeExceptionally(error.exception());
                        return;
                    } else if (error == Errors.OFFSET_METADATA_TOO_LARGE ||
                        error == Errors.INVALID_COMMIT_OFFSET_SIZE) {
                        future.completeExceptionally(error.exception());
                        return;
                    } else if (error == Errors.COORDINATOR_LOAD_IN_PROGRESS ||
                        error == Errors.UNKNOWN_TOPIC_OR_PARTITION ||
                        error == Errors.UNKNOWN_TOPIC_ID) {
                        // just retry
                        future.completeExceptionally(error.exception());
                        return;
                    } else if (error == Errors.UNKNOWN_MEMBER_ID) {
                        log.error("OffsetCommit failed with {}", error);
                        future.completeExceptionally(new CommitFailedException("OffsetCommit " +
                            "failed with unknown member ID. " + error.message()));
                        return;
                    } else if (error == Errors.STALE_MEMBER_EPOCH) {
                        log.error("OffsetCommit failed for member {} with stale member epoch error. Last epoch sent: {}",
                            memberInfo.memberId,
                            lastEpochSentOnCommit.isPresent() ? lastEpochSentOnCommit.get() : "undefined");
                        future.completeExceptionally(error.exception());
                        return;
                    } else if (error == Errors.TOPIC_AUTHORIZATION_FAILED) {
                        // Collect all unauthorized topics before failing
                        unauthorizedTopics.add(tp.topic());
                    } else {
                        // Fail with a non-retriable KafkaException for all unexpected errors
                        // (even if they are retriable)
                        future.completeExceptionally(new KafkaException("Unexpected error in commit: " + error.message()));
                        return;
                    }
                }
            }

            if (!unauthorizedTopics.isEmpty()) {
                log.error("OffsetCommit failed due to not authorized to commit to topics {}", unauthorizedTopics);
                future.completeExceptionally(new TopicAuthorizationException(unauthorizedTopics));
            } else {
                future.complete(null);
            }
        }

        @Override
        String requestDescription() {
            return "OffsetCommit request for offsets " + offsets;
        }

        @Override
        CompletableFuture<?> future() {
            return future;
        }

        void resetFuture() {
            future = new CompletableFuture<>();
        }

        @Override
        void removeRequest() {
            if (!unsentOffsetCommitRequests().remove(this)) {
                log.warn("OffsetCommit request to remove not found in the outbound buffer: {}", this);
            }
        }
    }

    // Visible for testing
    Optional<Integer> lastEpochSentOnCommit() {
        return lastEpochSentOnCommit;
    }

    /**
     * Represents a request that can be retried or aborted, based on member ID and epoch
     * information.
     */
    abstract class RetriableRequestState extends TimedRequestState {

        /**
         * Member info (ID and epoch) to be included in the request if present.
         */
        final MemberInfo memberInfo;

        RetriableRequestState(LogContext logContext, String owner, long retryBackoffMs,
                              long retryBackoffMaxMs, MemberInfo memberInfo, Timer timer) {
            super(logContext, owner, retryBackoffMs, retryBackoffMaxMs, timer);
            this.memberInfo = memberInfo;
        }

        // Visible for testing
        RetriableRequestState(LogContext logContext, String owner, long retryBackoffMs, int retryBackoffExpBase,
                              long retryBackoffMaxMs, double jitter, MemberInfo memberInfo, Timer timer) {
            super(logContext, owner, retryBackoffMs, retryBackoffExpBase, retryBackoffMaxMs, jitter, timer);
            this.memberInfo = memberInfo;
        }

        /**
         * @return String containing the request name and arguments, to be used for logging
         * purposes.
         */
        abstract String requestDescription();

        /**
         * @return Future that will complete with the request response or failure.
         */
        abstract CompletableFuture<?> future();

        /**
         * Complete the request future with a TimeoutException if the request has been sent out
         * at least once and the timeout has been reached.
         */
        void maybeExpire() {
            if (numAttempts > 0 && isExpired()) {
                removeRequest();
                future().completeExceptionally(new TimeoutException(requestDescription() +
                    " could not complete before timeout expired."));
            }
        }

        /**
         * Build request with the given builder, including response handling logic.
         */
        NetworkClientDelegate.UnsentRequest buildRequestWithResponseHandling(final AbstractRequest.Builder<?> builder) {
            NetworkClientDelegate.UnsentRequest request = new NetworkClientDelegate.UnsentRequest(
                builder,
                coordinatorRequestManager.coordinator()
            );
            request.whenComplete(
                (response, throwable) -> {
                    long completionTimeMs = request.handler().completionTimeMs();
                    handleClientResponse(response, throwable, completionTimeMs);
                });
            return request;
        }

        private void handleClientResponse(final ClientResponse response,
                                          final Throwable error,
                                          final long requestCompletionTimeMs) {
            try {
                if (error == null) {
                    onResponse(response);
                } else {
                    log.debug("{} completed with error", requestDescription(), error);
                    onFailedAttempt(requestCompletionTimeMs);
                    coordinatorRequestManager.handleCoordinatorDisconnect(error, requestCompletionTimeMs);
                    future().completeExceptionally(error);
                }
            } catch (Throwable t) {
                log.error("Unexpected error handling response for {}", requestDescription(), t);
                future().completeExceptionally(t);
            }
        }

        @Override
        public String toStringBase() {
            return super.toStringBase() + ", " + memberInfo;
        }

        abstract void onResponse(final ClientResponse response);

        abstract void removeRequest();
    }

    /**
     * Result of an offset fetch request.
     * Contains the successfully fetched offsets and any
     * retriable partition errors (e.g., UNKNOWN_TOPIC_ID).
     * This allows returning partial results, including offsets and partition errors.
     */
    public static class OffsetFetchResult {
        /**
         * Partitions with offsets successfully retrieved
         */
        private final Map<TopicPartition, OffsetAndMetadata> offsets;

        /**
         * Partitions with retriable errors
         */
        private final Map<TopicPartition, Errors> retriablePartitionErrors;

        public OffsetFetchResult(Map<TopicPartition, OffsetAndMetadata> offsets,
                                  Map<TopicPartition, Errors> retriablePartitionErrors) {
            this.offsets = offsets;
            this.retriablePartitionErrors = retriablePartitionErrors;
        }

        public Map<TopicPartition, OffsetAndMetadata> offsets() {
            return offsets;
        }

        public Map<TopicPartition, Errors> retriablePartitionErrors() {
            return retriablePartitionErrors;
        }

        public boolean hasRetriablePartitionErrors() {
            return !retriablePartitionErrors.isEmpty();
        }

        /**
         * Converts this result to a map of offsets, using null for partitions that had retriable errors.
         * This is expected to be used when the caller wants to return partial results to the user, where null indicates
         * that the offset for that partition could not be fetched.
         *
         * @return A new map containing all successfully fetched offsets, plus null entries for partitions
         *         that had retriable errors.
         */
        public Map<TopicPartition, OffsetAndMetadata> toOffsetMapWithNulls() {
            Map<TopicPartition, OffsetAndMetadata> result = new HashMap<>(offsets);
            for (TopicPartition tp : retriablePartitionErrors.keySet()) {
                result.put(tp, null);
            }
            return result;
        }

        @Override
        public String toString() {
            return "OffsetFetchResult{" +
                "offsets=" + offsets +
                ", retriablePartitionErrors=" + retriablePartitionErrors +
                '}';
        }
    }