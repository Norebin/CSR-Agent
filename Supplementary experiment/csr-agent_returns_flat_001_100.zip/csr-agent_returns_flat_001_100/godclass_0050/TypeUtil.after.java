public class TypeUtil {

    private static List<String> DATE_FORMAT_LIST = new ArrayList<String>(4);

    static {
        DATE_FORMAT_LIST.add("yyyy/MM/dd HH:mm:ss");
        DATE_FORMAT_LIST.add("yyyy-MM-dd HH:mm:ss");
        DATE_FORMAT_LIST.add("yyyyMMdd HH:mm:ss");
    }

    private static int getCountOfChar(String value, char c) {
        int n = 0;
        if (value == null) {
            return 0;
        }
        char[] chars = value.toCharArray();
        for (char cc : chars) {
            if (cc == c) {
                n++;
            }
        }
        return n;
    }

public static Object convert(String value, Field field, String format, boolean us) {
    if (!StringUtils.isEmpty(value)) {
        Class<?> fieldType = field.getType();
        if (Float.class.equals(fieldType)) {
            return Float.parseFloat(value);
        }
        if (Integer.class.equals(fieldType) || int.class.equals(fieldType)) {
            return Integer.parseInt(value);
        }
        if (Double.class.equals(fieldType) || double.class.equals(fieldType)) {
            if (null != format && !"".equals(format)) {
                int n = getCountOfChar(value, '0');
                return Double.parseDouble(FloatFormatUtil.formatFloat0(value, n));
            } else {
                return Double.parseDouble(FloatFormatUtil.formatFloat(value));
            }
        }
        if (Boolean.class.equals(fieldType) || boolean.class.equals(fieldType)) {
            String valueLower = value.toLowerCase();
            if (valueLower.equals("true") || valueLower.equals("false")) {
                return Boolean.parseBoolean(valueLower);
            }
            Integer integer = Integer.parseInt(value);
            return integer != 0;
        }
        if (Long.class.equals(fieldType) || long.class.equals(fieldType)) {
            return Long.parseLong(value);
        }
        if (Date.class.equals(fieldType)) {
            if (value.contains("-") || value.contains("/") || value.contains(":")) {
                return DateUtil.getSimpleDateFormatDate(value, format);
            } else {
                Double d = Double.parseDouble(value);
                return HSSFDateUtil.getJavaDate(d, us);
            }
        }
        if (BigDecimal.class.equals(fieldType)) {
            return new BigDecimal(value);
        }
        if (String.class.equals(fieldType)) {
            return FloatFormatUtil.formatFloat(value);
        }
    }
    return null;
}
public static Boolean isNum(Field field) {
    if (field == null) {
        return false;
    }
    Class<?> fieldType = field.getType();
    if (NumericUtil.isNumericType(fieldType)) {
        return true;
    }
    return false;
}
public static Boolean isNum(Object cellValue) {
    return NumericUtil.isNumericInstance(cellValue);
}
    public static String getDefaultDateString(Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return simpleDateFormat.format(date);

    }

    public static Date getSimpleDateFormatDate(String value, String format) {
        if (!StringUtils.isEmpty(value)) {
            Date date = null;
            if (!StringUtils.isEmpty(format)) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
                try {
                    date = simpleDateFormat.parse(value);
                    return date;
                } catch (ParseException e) {
                }
            }
            for (String dateFormat : DATE_FORMAT_LIST) {
                try {
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
                    date = simpleDateFormat.parse(value);
                } catch (ParseException e) {
                }
                if (date != null) {
                    break;
                }
            }

            return date;

        }
        return null;

    }


    public static String formatFloat(String value) {
        if (null != value && value.contains(".")) {
            if (isNumeric(value)) {
                try {
                    BigDecimal decimal = new BigDecimal(value);
                    BigDecimal setScale = decimal.setScale(10, BigDecimal.ROUND_HALF_DOWN).stripTrailingZeros();
                    return setScale.toPlainString();
                } catch (Exception e) {
                }
            }
        }
        return value;
    }

    public static String formatFloat0(String value, int n) {
        if (null != value && value.contains(".")) {
            if (isNumeric(value)) {
                try {
                    BigDecimal decimal = new BigDecimal(value);
                    BigDecimal setScale = decimal.setScale(n, BigDecimal.ROUND_HALF_DOWN);
                    return setScale.toPlainString();
                } catch (Exception e) {
                }
            }
        }
        return value;
    }

    public static final Pattern pattern = Pattern.compile("[\\+\\-]?[\\d]+([\\.][\\d]*)?([Ee][+-]?[\\d]+)?$");

    private static boolean isNumeric(String str) {
        Matcher isNum = pattern.matcher(str);
        if (!isNum.matches()) {
            return false;
        }
        return true;
    }

    public static String formatDate(Date cellValue, String format) {
        SimpleDateFormat simpleDateFormat;
        if(!StringUtils.isEmpty(format)) {
             simpleDateFormat = new SimpleDateFormat(format);
        }else {
            simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        }
        return simpleDateFormat.format(cellValue);
    }

    public static String getFieldStringValue(BeanMap beanMap, String fieldName, String format) {
        String cellValue = null;
        Object value = beanMap.get(fieldName);
        if (value != null) {
            if (value instanceof Date) {
                cellValue = TypeUtil.formatDate((Date)value, format);
            } else {
                cellValue = value.toString();
            }
        }
        return cellValue;
    }

    public static Map getFieldValues(List<String> stringList, ExcelHeadProperty excelHeadProperty, Boolean use1904WindowDate) {
        Map map = new HashMap();
        for (int i = 0; i < stringList.size(); i++) {
            ExcelColumnProperty columnProperty = excelHeadProperty.getExcelColumnProperty(i);
            if (columnProperty != null) {
                Object value = TypeUtil.convert(stringList.get(i), columnProperty.getField(),
                    columnProperty.getFormat(), use1904WindowDate);
                if (value != null) {
                    map.put(columnProperty.getField().getName(),value);
                }
            }
        }
        return map;
    }
}