public class RequestAssertionConsumerService extends AbstractSSOSpHandler {
    private static final Logger LOG = 
        LogUtils.getL7dLogger(RequestAssertionConsumerService.class);
    private static final ResourceBundle BUNDLE = 
        BundleUtils.getBundle(RequestAssertionConsumerService.class);
    
    private boolean supportDeflateEncoding = true;
    private boolean supportBase64Encoding = true;
    private boolean enforceAssertionsSigned = true;
    private boolean enforceKnownIssuer = true;
    private boolean keyInfoMustBeAvailable = true;
    private TokenReplayCache<String> replayCache;

    private MessageContext messageContext;
    
    @Context 
    public void setMessageContext(MessageContext mc) {
        this.messageContext = mc;
    }
    
    public void setSupportDeflateEncoding(boolean deflate) {
        supportDeflateEncoding = deflate;
    }
    public boolean isSupportDeflateEncoding() {
        return supportDeflateEncoding;
    }
    
    public void setReplayCache(TokenReplayCache<String> replayCache) {
        this.replayCache = replayCache;
    }
    
    public TokenReplayCache<String> getReplayCache() {
        if (replayCache == null) {
            Bus bus = (Bus)messageContext.getContextualProperty(Bus.class.getName());
            replayCache = new EHCacheTokenReplayCache(bus);
        }
        return replayCache;
    }
    
    /**
     * Enforce that Assertions must be signed if the POST binding was used. The default is true.
     */
    public void setEnforceAssertionsSigned(boolean enforceAssertionsSigned) {
        this.enforceAssertionsSigned = enforceAssertionsSigned;
    }
    
    /**
     * Enforce that the Issuer of the received Response/Assertion is known to this RACS. The
     * default is true.
     */
    public void setEnforceKnownIssuer(boolean enforceKnownIssuer) {
        this.enforceKnownIssuer = enforceKnownIssuer;
    }
    
    public void setSupportBase64Encoding(boolean supportBase64Encoding) {
        this.supportBase64Encoding = supportBase64Encoding;
    }
    public boolean isSupportBase64Encoding() {
        return supportBase64Encoding;
    }
    
    @POST
    @Produces(MediaType.APPLICATION_FORM_URLENCODED)
    public Response processSamlResponse(@FormParam(SSOConstants.SAML_RESPONSE) String encodedSamlResponse,
                                        @FormParam(SSOConstants.RELAY_STATE) String relayState) {
        return doProcessSamlResponse(encodedSamlResponse, relayState, true);
        
    }
    
    @GET
    public Response getSamlResponse(@QueryParam(SSOConstants.SAML_RESPONSE) String encodedSamlResponse,
                                    @QueryParam(SSOConstants.RELAY_STATE) String relayState) {
        return doProcessSamlResponse(encodedSamlResponse, relayState, false);
    }
    
    @PreDestroy
    @Override
    public void close() {
        if (replayCache != null) {
            try {
                replayCache.close();
            } catch (IOException ex) {
                LOG.warning("Replay cache can not be closed: " + ex.getMessage());
            }
        }
        super.close();
    }
    
protected Response doProcessSamlResponse(String encodedSamlResponse,
                                      String relayState,
                                      boolean postBinding) {
    RequestStateHandler stateHandler = new RequestStateHandler(getStateProvider());
    RequestState requestState = stateHandler.processRelayState(relayState);
    URI targetURI = stateHandler.getTargetURI(requestState.getTargetAddress());

    SAMLResponseParser parser = new SAMLResponseParser(supportDeflateEncoding, supportBase64Encoding);
    org.opensaml.saml2.core.Response samlResponse = parser.readSAMLResponse(postBinding, encodedSamlResponse);

    SAMLProtocolResponseValidator protocolValidator = new SAMLProtocolResponseValidator();
    protocolValidator.setKeyInfoMustBeAvailable(keyInfoMustBeAvailable);
    protocolValidator.validateSamlResponse(samlResponse, getSignatureCrypto(), getCallbackHandler());

    SAMLSSOResponseValidator ssoValidator = new SAMLSSOResponseValidator();
    ssoValidator.setAssertionConsumerURL(messageContext.getUriInfo().getAbsolutePath().toString());
    ssoValidator.setClientAddress(messageContext.getHttpServletRequest().getRemoteAddr());

    ssoValidator.setIssuerIDP(requestState.getIdpServiceAddress());
    ssoValidator.setRequestId(requestState.getSamlRequestId());
    ssoValidator.setSpIdentifier(requestState.getIssuerId());
    ssoValidator.setEnforceAssertionsSigned(enforceAssertionsSigned);
    ssoValidator.setEnforceKnownIssuer(enforceKnownIssuer);
    ssoValidator.setReplayCache(getReplayCache());

    SSOValidatorResponse validatorResponse;
    try {
        validatorResponse = ssoValidator.validateSamlResponse(samlResponse, postBinding);
    } catch (WSSecurityException ex) {
        reportError("INVALID_SAML_RESPONSE");
        throw ExceptionUtils.toBadRequestException(ex, null);
    }

    String securityContextKey = UUID.randomUUID().toString();

    long currentTime = System.currentTimeMillis();
    Date notOnOrAfter = validatorResponse.getSessionNotOnOrAfter();
    long expiresAt = 0;
    if (notOnOrAfter != null) {
        expiresAt = notOnOrAfter.getTime();
    } else {
        expiresAt = currentTime + getStateTimeToLive();
    }

    ResponseState responseState =
        new ResponseState(validatorResponse.getAssertion(),
                          relayState,
                          requestState.getWebAppContext(),
                          requestState.getWebAppDomain(),
                          currentTime,
                          expiresAt);
    getStateProvider().setResponseState(securityContextKey, responseState);

    String contextCookie = createCookie(SSOConstants.SECURITY_CONTEXT_TOKEN,
                                        securityContextKey,
                                        requestState.getWebAppContext(),
                                        requestState.getWebAppDomain());

    return Response.seeOther(targetURI).header("Set-Cookie", contextCookie).build();
}    
private RequestState processRelayState(String relayState) {
    RequestStateHandler stateHandler = new RequestStateHandler(getStateProvider());
    return stateHandler.processRelayState(relayState);
}    
private org.opensaml.saml2.core.Response readSAMLResponse(
    boolean postBinding,
    String samlResponse
) {
    SAMLResponseParser parser = new SAMLResponseParser(supportDeflateEncoding, supportBase64Encoding);
    return parser.readSAMLResponse(postBinding, samlResponse);
}    
    /**
     * Validate the received SAML Response as per the protocol
     */
    protected void validateSamlResponseProtocol(
        org.opensaml.saml2.core.Response samlResponse
    ) {
        try {
            SAMLProtocolResponseValidator protocolValidator = new SAMLProtocolResponseValidator();
            protocolValidator.setKeyInfoMustBeAvailable(keyInfoMustBeAvailable);
            protocolValidator.validateSamlResponse(samlResponse, getSignatureCrypto(), getCallbackHandler());
        } catch (WSSecurityException ex) {
            LOG.log(Level.FINE, ex.getMessage(), ex);
            reportError("INVALID_SAML_RESPONSE");
            throw ExceptionUtils.toBadRequestException(null, null);
        }
    }
    
    /**
     * Validate the received SAML Response as per the Web SSO profile
     */
    protected SSOValidatorResponse validateSamlSSOResponse(
        boolean postBinding,
        org.opensaml.saml2.core.Response samlResponse,
        RequestState requestState
    ) {
        try {
            SAMLSSOResponseValidator ssoResponseValidator = new SAMLSSOResponseValidator();
            ssoResponseValidator.setAssertionConsumerURL(
                messageContext.getUriInfo().getAbsolutePath().toString());

            ssoResponseValidator.setClientAddress(
                 messageContext.getHttpServletRequest().getRemoteAddr());

            ssoResponseValidator.setIssuerIDP(requestState.getIdpServiceAddress());
            ssoResponseValidator.setRequestId(requestState.getSamlRequestId());
            ssoResponseValidator.setSpIdentifier(requestState.getIssuerId());
            ssoResponseValidator.setEnforceAssertionsSigned(enforceAssertionsSigned);
            ssoResponseValidator.setEnforceKnownIssuer(enforceKnownIssuer);
            ssoResponseValidator.setReplayCache(getReplayCache());

            return ssoResponseValidator.validateSamlResponse(samlResponse, postBinding);
        } catch (WSSecurityException ex) {
            reportError("INVALID_SAML_RESPONSE");
            throw ExceptionUtils.toBadRequestException(ex, null);
        }
    }
    
    private URI getTargetURI(String targetAddress) {
        if (targetAddress != null) {
            try {
                return URI.create(targetAddress);
            } catch (IllegalArgumentException ex) {
                reportError("INVALID_TARGET_URI");
            }
        } else {
            reportError("MISSING_TARGET_URI");
        }
        throw ExceptionUtils.toBadRequestException(null, null);
    }
    
    private void reportError(String code) {
        org.apache.cxf.common.i18n.Message errorMsg = 
            new org.apache.cxf.common.i18n.Message(code, BUNDLE);
        LOG.warning(errorMsg.toString());
    }
    
    public void setKeyInfoMustBeAvailable(boolean keyInfoMustBeAvailable) {
        this.keyInfoMustBeAvailable = keyInfoMustBeAvailable;
    }
}