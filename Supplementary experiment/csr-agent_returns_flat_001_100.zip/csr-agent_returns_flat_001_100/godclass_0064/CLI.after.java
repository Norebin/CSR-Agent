public class CLI {

    private CLI() {}

    /**
     * Make sure the connection is open against Jenkins server.
     *
     * @param c The open connection.
     * @throws IOException in case of communication problem.
     * @throws NotTalkingToJenkinsException when connection is not made to Jenkins service.
     */
    /*package*/ static void verifyJenkinsConnection(URLConnection c) throws IOException {
        if (c.getHeaderField("X-Hudson") == null && c.getHeaderField("X-Jenkins") == null)
            throw new NotTalkingToJenkinsException(c);
    }

    /*package*/ static final class NotTalkingToJenkinsException extends IOException {
        NotTalkingToJenkinsException(String s) {
            super(s);
        }

        NotTalkingToJenkinsException(URLConnection c) {
            super("There's no Jenkins running at " + c.getURL().toString());
        }
    }

    public static void main(final String[] _args) throws Exception {
        try {
            System.exit(_main(_args));
        } catch (NotTalkingToJenkinsException ex) {
            System.err.println(ex.getMessage());
            System.exit(3);
        } catch (Throwable t) {
            // if the CLI main thread die, make sure to kill the JVM.
            t.printStackTrace();
            System.exit(-1);
        }
    }

    private enum Mode { HTTP, SSH, WEB_SOCKET }

public static int _main(String[] _args) throws Exception {
    CommandLineParser parser = new CommandLineParser(_args);
    if (parser.isVersionRequested()) {
        System.out.println("Version: " + computeVersion());
        return 0;
    }
    if (!parser.isModeValid()) {
        printUsage(parser.getModeError());
        return -1;
    }
    if (parser.isRemotingMode()) {
        printUsage("-remoting mode is no longer supported");
        return -1;
    }
    if (parser.isFileSpecified() && !parser.getKeyFile().exists()) {
        printUsage(Messages.CLI_NoSuchFileExists(parser.getKeyFile()));
        return -1;
    }
    if (parser.isFileSpecified()) {
        parser.getPrivateKeyProvider().readFrom(parser.getKeyFile());
    }
    if (parser.isStrictHostKey() && parser.getMode() != Mode.SSH) {
        LOGGER.warning("-strictHostKey meaningful only with -ssh");
    }
    if (parser.isNoKeyAuth() && parser.getMode() != Mode.SSH) {
        LOGGER.warning("-noKeyAuth meaningful only with -ssh");
    }
    if (parser.getUser() != null && parser.getMode() != Mode.SSH) {
        LOGGER.warning("Warning: -user ignored unless using -ssh");
    }
    if (parser.getUrl() == null) {
        printUsage(Messages.CLI_NoURL());
        return -1;
    }
    if (parser.isAuthAndBearerBothSet()) {
        LOGGER.warning("-auth and -bearer are mutually exclusive");
    }
    if (!parser.isAuthOrBearerSet()) {
        if (parser.isEnvAuthValid()) {
            parser.setAuthFromEnv();
        } else if (parser.isEnvAuthPartial()) {
            printUsage(Messages.CLI_BadAuth());
            return -1;
        }
    }
    if (!parser.getUrl().endsWith("/")) {
        parser.setUrl(parser.getUrl() + '/');
    }
    if (parser.getArgs().isEmpty()) {
        parser.setArgs(List.of("help"));
    }
    if (parser.getMode() == null) {
        parser.setMode(Mode.WEB_SOCKET);
    }
    LOGGER.log(FINE, "using connection mode {0}", parser.getMode());
    if (parser.getMode() == Mode.SSH) {
        if (parser.getUser() == null) {
            LOGGER.warning("-user required when using -ssh");
            return -1;
        }
        if (!parser.isNoKeyAuth() && !parser.getPrivateKeyProvider().hasKeys()) {
            parser.getPrivateKeyProvider().readFromDefaultLocations();
        }
        return SSHCLI.sshConnection(parser.getUrl(), parser.getUser(), parser.getArgs(), parser.getPrivateKeyProvider(), parser.isStrictHostKey());
    }
    CLIConnectionFactory factory = new CLIConnectionFactory().noCertificateCheck(parser.isNoCertificateCheck());
    String userInfo = new URL(parser.getUrl()).getUserInfo();
    if (userInfo != null) {
        factory = factory.basicAuth(userInfo);
    } else if (parser.getAuth() != null) {
        factory = factory.basicAuth(parser.getAuth().startsWith("@") ? readAuthFromFile(parser.getAuth()).trim() : parser.getAuth());
    } else if (parser.getBearer() != null) {
        factory = factory.bearerAuth(parser.getBearer().startsWith("@") ? readAuthFromFile(parser.getBearer()).trim() : parser.getBearer());
    }
    if (parser.getMode() == Mode.HTTP) {
        return plainHttpConnection(parser.getUrl(), parser.getArgs(), factory);
    }
    if (parser.getMode() == Mode.WEB_SOCKET) {
        return webSocketConnection(parser.getUrl(), parser.getArgs(), factory);
    }
    throw new AssertionError();
}
    @SuppressFBWarnings(value = "PATH_TRAVERSAL_IN", justification = "User provided value for running the program.")
    private static String readAuthFromFile(String auth) throws IOException {
        Path path;
        try {
            path = Paths.get(auth.substring(1));
        } catch (InvalidPathException e) {
            throw new IOException(e);
        }
        return Files.readString(path, Charset.defaultCharset());
    }

    @SuppressFBWarnings(value = "PATH_TRAVERSAL_IN", justification = "User provided value for running the program.")
    private static File getFileFromArguments(List<String> args) {
        return new File(args.get(1));
    }

    private static int webSocketConnection(String url, List<String> args, CLIConnectionFactory factory) throws Exception {
        LOGGER.fine(() -> "Trying to connect to " + url + " via plain protocol over WebSocket");
        class CLIEndpoint extends Endpoint {
            @Override
            public void onOpen(Session session, EndpointConfig config) {}
        }

        class Authenticator extends ClientEndpointConfig.Configurator {
            HandshakeResponse hr;

            @Override
            public void beforeRequest(Map<String, List<String>> headers) {
                if (factory.authorization != null) {
                    headers.put("Authorization", List.of(factory.authorization));
                }
            }

            @Override
            public void afterResponse(HandshakeResponse hr) {
                this.hr = hr;
            }
        }

        var authenticator = new Authenticator();

        ClientManager client = ClientManager.createClient(JdkClientContainer.class.getName()); // ~ ContainerProvider.getWebSocketContainer()
        client.getProperties().put(ClientProperties.REDIRECT_ENABLED, true); // https://tyrus-project.github.io/documentation/1.13.1/index/tyrus-proprietary-config.html#d0e1775
        if (factory.noCertificateCheck) {
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[] {new NoCheckTrustManager()}, new SecureRandom());
            SslEngineConfigurator sslEngineConfigurator = new SslEngineConfigurator(sslContext);
            sslEngineConfigurator.setHostnameVerifier((s, sslSession) -> true);
            client.getProperties().put(ClientProperties.SSL_ENGINE_CONFIGURATOR, sslEngineConfigurator);
        }
        Session session;
        try {
            session = client.connectToServer(new CLIEndpoint(), ClientEndpointConfig.Builder.create().configurator(authenticator).build(), URI.create(url.replaceFirst("^http", "ws") + "cli/ws"));
        } catch (DeploymentHandshakeException x) {
            System.err.println("CLI handshake failed with status code " + x.getHttpStatusCode());
            if (authenticator.hr != null) {
                for (var entry : authenticator.hr.getHeaders().entrySet()) {
                    // org.glassfish.tyrus.core.Utils.parseHeaderValue improperly splits values like Date at commas, so undo that:
                    System.err.println(entry.getKey() + ": " + String.join(", ", entry.getValue()));
                }
                // UpgradeResponse.getReasonPhrase is useless since Jetty generates it from the code,
                // and the body is not accessible at all.
            }
            return 15; // compare CLICommand.main
        }
        PlainCLIProtocol.Output out = new PlainCLIProtocol.Output() {
            @Override
            public void send(byte[] data) throws IOException {
                session.getBasicRemote().sendBinary(ByteBuffer.wrap(data));
            }

            @Override
            public void close() throws IOException {
                session.close();
            }
        };
        try (ClientSideImpl connection = new ClientSideImpl(out)) {
            session.addMessageHandler(InputStream.class, is -> {
                try {
                    connection.handle(new DataInputStream(is));
                } catch (IOException x) {
                    LOGGER.log(Level.WARNING, null, x);
                }
            });
            connection.start(args);
            return connection.exit();
        }
    }

    private static int plainHttpConnection(String url, List<String> args, CLIConnectionFactory factory)
            throws GeneralSecurityException, IOException, InterruptedException {
        LOGGER.log(FINE, "Trying to connect to {0} via plain protocol over HTTP", url);
        if (factory.noCertificateCheck) {
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[] {new NoCheckTrustManager()}, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((s, sslSession) -> true);
        }
        FullDuplexHttpStream streams = new FullDuplexHttpStream(new URL(url), "cli?remoting=false", factory.authorization);
        try (ClientSideImpl connection = new ClientSideImpl(new PlainCLIProtocol.FramedOutput(streams.getOutputStream()))) {
            connection.start(args);
            InputStream is = streams.getInputStream();
            if (is.read() != 0) { // cf. FullDuplexHttpService
                throw new IOException("expected to see initial zero byte; perhaps you are connecting to an old server which does not support -http?");
            }
            new PlainCLIProtocol.FramedReader(connection, is).start();
            new Thread("ping") { // JENKINS-46659
                @Override
                public void run() {
                    try {
                        Thread.sleep(PING_INTERVAL);
                        while (!connection.complete) {
                            LOGGER.fine("sending ping");
                            connection.sendEncoding(Charset.defaultCharset().name()); // no-op at this point
                            Thread.sleep(PING_INTERVAL);
                        }
                    } catch (IOException | InterruptedException x) {
                        LOGGER.log(Level.WARNING, null, x);
                    }
                }

            }.start();
            return connection.exit();
        }
    }

    private static final class ClientSideImpl extends PlainCLIProtocol.ClientSide {

        volatile boolean complete;
        private int exit = -1;

        ClientSideImpl(PlainCLIProtocol.Output out) {
            super(out);
        }

        void start(List<String> args) throws IOException {
            for (String arg : args) {
                sendArg(arg);
            }
            sendEncoding(Charset.defaultCharset().name());
            sendLocale(Locale.getDefault().toString());
            sendStart();
            new Thread("input reader") {
                @Override
                public void run() {
                    try {
                        final OutputStream stdin = streamStdin();
                        byte[] buf = new byte[60_000]; // less than 64Kb frame size for WS
                        while (!complete) {
                            int len = System.in.read(buf);
                            if (len == -1) {
                                break;
                            } else {
                                stdin.write(buf, 0, len);
                            }
                        }
                        sendEndStdin();
                    } catch (IOException x) {
                        LOGGER.log(Level.WARNING, null, x);
                    }
                }
            }.start();
        }

        @Override
        protected synchronized void onExit(int code) {
            this.exit = code;
            finished();
        }

        @Override
        protected void onStdout(byte[] chunk) throws IOException {
            System.out.write(chunk);
        }

        @Override
        protected void onStderr(byte[] chunk) throws IOException {
            System.err.write(chunk);
        }

        @Override
        protected void handleClose() {
            finished();
        }

        private synchronized void finished() {
            complete = true;
            notifyAll();
        }

        synchronized int exit() throws InterruptedException {
            while (!complete) {
                wait();
            }
            return exit;
        }

    }

    private static String computeVersion() {
        Properties props = new Properties();
        try (InputStream is = CLI.class.getResourceAsStream("/jenkins/cli/jenkins-cli-version.properties")) {
            if (is != null) {
                props.load(is);
            }
        } catch (IOException e) {
            e.printStackTrace(); // if the version properties is missing, that's OK.
        }
        return props.getProperty("version", "?");
    }

    /**
     * Loads an SSH private key (RSA, DSA, ECDSA or Ed25519) into a {@link KeyPair}.
     */
    public static KeyPair loadKey(File f, String passwd) throws IOException, GeneralSecurityException {
        return PrivateKeyProvider.loadKey(f, passwd);
    }

    public static KeyPair loadKey(File f) throws IOException, GeneralSecurityException {
        return loadKey(f, null);
    }

    /**
     * Loads an SSH private key (RSA, DSA, ECDSA or Ed25519) into a {@link KeyPair}.
     */
    public static KeyPair loadKey(String pemString, String passwd) throws IOException, GeneralSecurityException {
        return PrivateKeyProvider.loadKey(pemString, passwd);
    }

    public static KeyPair loadKey(String pemString) throws IOException, GeneralSecurityException {
        return loadKey(pemString, null);
    }

    /** For access from {@code HelpCommand}. */
    static String usage() {
        return Messages.CLI_Usage();
    }

    private static void printUsage(String msg) {
        if (msg != null)   System.out.println(msg);
        System.err.println(usage());
    }

    static final Logger LOGGER = Logger.getLogger(CLI.class.getName());

    private static final int PING_INTERVAL = Integer.getInteger(CLI.class.getName() + ".pingInterval", 3_000); // JENKINS-59267
}