public class CurrentAssignmentBuilder {
    /**
     * The consumer group member which is reconciled.
     */
    private final ConsumerGroupMember member;

    /**
     * The metadata image.
     */
    private CoordinatorMetadataImage metadataImage = CoordinatorMetadataImage.EMPTY;

    /**
     * The target assignment epoch.
     */
    private int targetAssignmentEpoch;

    /**
     * The target assignment.
     */
    private Assignment targetAssignment;

    /**
     * Whether the member has changed its subscription on the current heartbeat.
     */
    private boolean hasSubscriptionChanged;

    /**
     * The resolved regular expressions.
     */
    private Map<String, ResolvedRegularExpression> resolvedRegularExpressions = Map.of();

    /**
     * A function which returns the current epoch of a topic-partition or -1 if the
     * topic-partition is not assigned. The current epoch is the epoch of the current owner.
     */
    private BiFunction<Uuid, Integer, Integer> currentPartitionEpoch;

    /**
     * The partitions owned by the consumer. This is directly provided by the member in the
     * ConsumerGroupHeartbeat request.
     */
    private List<ConsumerGroupHeartbeatRequestData.TopicPartitions> ownedTopicPartitions;

    /**
     * Constructs the CurrentAssignmentBuilder based on the current state of the
     * provided consumer group member.
     *
     * @param member The consumer group member that must be reconciled.
     */
    public CurrentAssignmentBuilder(ConsumerGroupMember member) {
        this.member = Objects.requireNonNull(member);
    }

    /**
     * Sets the metadata image.
     *
     * @param metadataImage    The metadata image.
     * @return This object.
     */
    public CurrentAssignmentBuilder withMetadataImage(
        CoordinatorMetadataImage metadataImage
    ) {
        this.metadataImage = metadataImage;
        return this;
    }

    /**
     * Sets the target assignment epoch and the target assignment that the
     * consumer group member must be reconciled to.
     *
     * @param targetAssignmentEpoch The target assignment epoch.
     * @param targetAssignment      The target assignment.
     * @return This object.
     */
    public CurrentAssignmentBuilder withTargetAssignment(
        int targetAssignmentEpoch,
        Assignment targetAssignment
    ) {
        this.targetAssignmentEpoch = targetAssignmentEpoch;
        this.targetAssignment = Objects.requireNonNull(targetAssignment);
        return this;
    }

    /**
     * Sets whether the member has changed its subscription on the current heartbeat.
     *
     * @param hasSubscriptionChanged If true, always removes unsubscribed topics from the current assignment.
     * @return This object.
     */
    public CurrentAssignmentBuilder withHasSubscriptionChanged(
        boolean hasSubscriptionChanged
    ) {
        this.hasSubscriptionChanged = hasSubscriptionChanged;
        return this;
    }

    /**
     * Sets the resolved regular expressions.
     *
     * @param resolvedRegularExpressions The resolved regular expressions.
     * @return This object.
     */
    public CurrentAssignmentBuilder withResolvedRegularExpressions(
        Map<String, ResolvedRegularExpression> resolvedRegularExpressions
    ) {
        this.resolvedRegularExpressions = resolvedRegularExpressions;
        return this;
    }

    /**
     * Sets a BiFunction which allows to retrieve the current epoch of a
     * partition. This is used by the state machine to determine if a
     * partition is free or still used by another member.
     *
     * @param currentPartitionEpoch A BiFunction which gets the epoch of a
     *                              topic id / partitions id pair.
     * @return This object.
     */
    public CurrentAssignmentBuilder withCurrentPartitionEpoch(
        BiFunction<Uuid, Integer, Integer> currentPartitionEpoch
    ) {
        this.currentPartitionEpoch = Objects.requireNonNull(currentPartitionEpoch);
        return this;
    }

    /**
     * Sets the partitions currently owned by the member. This comes directly
     * from the last ConsumerGroupHeartbeat request. This is used to determine
     * if the member has revoked the necessary partitions.
     *
     * @param ownedTopicPartitions A list of topic-partitions.
     * @return This object.
     */
    public CurrentAssignmentBuilder withOwnedTopicPartitions(
        List<ConsumerGroupHeartbeatRequestData.TopicPartitions> ownedTopicPartitions
    ) {
        this.ownedTopicPartitions = ownedTopicPartitions;
        return this;
    }

    /**
     * Builds the next state for the member or keep the current one if it
     * is not possible to move forward with the current state.
     *
     * @return A new ConsumerGroupMember or the current one.
     */
public ConsumerGroupMember build() {
    MemberStateReconciler reconciler = new MemberStateReconciler(
        member,
        targetAssignmentEpoch,
        targetAssignment,
        hasSubscriptionChanged,
        resolvedRegularExpressions,
        currentPartitionEpoch,
        ownedTopicPartitions,
        metadataImage
    );
    return reconciler.reconcile();
}
    /**
     * Decides whether the current ownedTopicPartitions contains any partition that is pending revocation.
     *
     * @param assignment The assignment that has the partitions pending revocation.
     * @return A boolean based on the condition mentioned above.
     */
    private boolean ownsRevokedPartitions(
        Map<Uuid, Map<Integer, Integer>> assignment
    ) {
        if (ownedTopicPartitions == null) return true;

        for (ConsumerGroupHeartbeatRequestData.TopicPartitions topicPartitions : ownedTopicPartitions) {
            Map<Integer, Integer> partitionsPendingRevocation =
                assignment.getOrDefault(topicPartitions.topicId(), Map.of());

            for (Integer partitionId : topicPartitions.partitions()) {
                if (partitionsPendingRevocation.containsKey(partitionId)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Updates the current assignment, removing any partitions that are not part of the subscribed topics.
     * This method is a lot faster than running the full reconciliation logic in computeNextAssignment.
     *
     * @param memberEpoch               The epoch of the member to use.
     * @param memberAssignedPartitions  The assigned partitions of the member to use and their assignment epochs.
     * @return A new ConsumerGroupMember.
     */
    private ConsumerGroupMember updateCurrentAssignment(
        int memberEpoch,
        Map<Uuid, Map<Integer, Integer>> memberAssignedPartitions
    ) {
        Set<Uuid> subscribedTopicIds = subscribedTopicIds();

        // Reuse the original map if no topics need to be removed.
        Map<Uuid, Map<Integer, Integer>> newAssignedPartitions;
        Map<Uuid, Map<Integer, Integer>> newPartitionsPendingRevocation;

        if (subscribedTopicIds.isEmpty() && member.partitionsPendingRevocation().isEmpty()) {
            newAssignedPartitions = Map.of();
            // Move all assigned to pending revocation
            newPartitionsPendingRevocation = memberAssignedPartitions;
        } else {
            newAssignedPartitions = memberAssignedPartitions;
            newPartitionsPendingRevocation = member.partitionsPendingRevocation();
            for (Map.Entry<Uuid, Map<Integer, Integer>> entry : memberAssignedPartitions.entrySet()) {
                if (!subscribedTopicIds.contains(entry.getKey())) {
                    if (newAssignedPartitions == memberAssignedPartitions) {
                        newAssignedPartitions = new HashMap<>(memberAssignedPartitions);
                        newPartitionsPendingRevocation = new HashMap<>(member.partitionsPendingRevocation());
                    }
                    newAssignedPartitions.remove(entry.getKey());
                    newPartitionsPendingRevocation.merge(
                        entry.getKey(),
                        entry.getValue(),
                        (existing, additional) -> {
                            existing = new HashMap<>(existing);
                            existing.putAll(additional);
                            return existing;
                        }
                    );
                }
            }
        }

        if (newAssignedPartitions == memberAssignedPartitions) {
            // If no partitions were removed, we can return the member as is.
            return member;
        }

        if (!newPartitionsPendingRevocation.isEmpty() && ownsRevokedPartitions(newPartitionsPendingRevocation)) {
            return new ConsumerGroupMember.Builder(member)
                .setState(MemberState.UNREVOKED_PARTITIONS)
                .updateMemberEpoch(memberEpoch)
                .setAssignedPartitions(newAssignedPartitions)
                .setPartitionsPendingRevocation(newPartitionsPendingRevocation)
                .build();
        } else {
            // There were partitions removed, but they were already revoked.
            // Keep the member in the current state and shrink the assigned partitions.

            // We do not expect to be in the UNREVOKED_PARTITIONS state here. The full
            // reconciliation logic should handle the case where the member has revoked all its
            // partitions pending revocation.
            return new ConsumerGroupMember.Builder(member)
                .updateMemberEpoch(memberEpoch)
                .setAssignedPartitions(newAssignedPartitions)
                .build();
        }
    }

    /**
     * Computes the next assignment.
     *
     * @param memberEpoch               The epoch of the member to use. This may be different
     *                                  from the epoch in {@link CurrentAssignmentBuilder#member}.
     * @param memberAssignedPartitions  The assigned partitions of the member to use and their assignment epochs.
     * @return A new ConsumerGroupMember.
     */
    private ConsumerGroupMember computeNextAssignment(
        int memberEpoch,
        Map<Uuid, Map<Integer, Integer>> memberAssignedPartitions
    ) {
        Set<Uuid> subscribedTopicIds = subscribedTopicIds();

        boolean hasUnreleasedPartitions = false;
        Map<Uuid, Map<Integer, Integer>> newAssignedPartitions = new HashMap<>();
        Map<Uuid, Map<Integer, Integer>> newPartitionsPendingRevocation = new HashMap<>();
        Map<Uuid, Set<Integer>> newPartitionsPendingAssignment = new HashMap<>();

        Set<Uuid> allTopicIds = new HashSet<>(targetAssignment.partitions().keySet());
        allTopicIds.addAll(memberAssignedPartitions.keySet());

        for (Uuid topicId : allTopicIds) {
            Set<Integer> target = targetAssignment.partitions()
                .getOrDefault(topicId, Set.of());
            Map<Integer, Integer> currentAssignedPartitions = memberAssignedPartitions
                .getOrDefault(topicId, Map.of());

            // If the member is no longer subscribed to the topic, treat its target assignment as empty.
            if (!subscribedTopicIds.contains(topicId)) {
                target = Set.of();
            }

            // New Assigned Partitions = Previous Assigned Partitions ∩ Target
            Map<Integer, Integer> assignedPartitions = new HashMap<>(currentAssignedPartitions);
            assignedPartitions.keySet().retainAll(target);

            // Partitions Pending Revocation = Previous Assigned Partitions - New Assigned Partitions
            Map<Integer, Integer> partitionsPendingRevocation = new HashMap<>(currentAssignedPartitions);
            partitionsPendingRevocation.keySet().removeAll(assignedPartitions.keySet());

            // Partitions Pending Assignment = Target - New Assigned Partitions - Unreleased Partitions
            Set<Integer> partitionsPendingAssignment = new HashSet<>(target);
            partitionsPendingAssignment.removeAll(assignedPartitions.keySet());
            hasUnreleasedPartitions = partitionsPendingAssignment.removeIf(partitionId ->
                currentPartitionEpoch.apply(topicId, partitionId) != -1 &&
                // Don't consider a partition unreleased if it is owned by the current member
                // because it is pending revocation. This is safe to do since only a single member
                // can own a partition at a time.
                !member.partitionsPendingRevocation().getOrDefault(topicId, Map.of()).containsKey(partitionId)
            ) || hasUnreleasedPartitions;

            if (!assignedPartitions.isEmpty()) {
                newAssignedPartitions.put(topicId, assignedPartitions);
            }

            if (!partitionsPendingRevocation.isEmpty()) {
                newPartitionsPendingRevocation.put(topicId, partitionsPendingRevocation);
            }

            if (!partitionsPendingAssignment.isEmpty()) {
                newPartitionsPendingAssignment.put(topicId, partitionsPendingAssignment);
            }
        }

        if (!newPartitionsPendingRevocation.isEmpty() && ownsRevokedPartitions(newPartitionsPendingRevocation)) {
            // If there are partitions to be revoked, the member remains in its current
            // epoch and requests the revocation of those partitions. It transitions to
            // the UNREVOKED_PARTITIONS state to wait until the client acknowledges the
            // revocation of the partitions.
            return new ConsumerGroupMember.Builder(member)
                .setState(MemberState.UNREVOKED_PARTITIONS)
                .updateMemberEpoch(memberEpoch)
                .setAssignedPartitions(newAssignedPartitions)
                .setPartitionsPendingRevocation(newPartitionsPendingRevocation)
                .build();
        } else if (!newPartitionsPendingAssignment.isEmpty()) {
            // If there are partitions to be assigned, the member transitions to the
            // target epoch and requests the assignment of those partitions. Note that
            // the partitions are directly added to the assigned partitions set. The
            // member transitions to the STABLE state or to the UNRELEASED_PARTITIONS
            // state depending on whether there are unreleased partitions or not.
            newPartitionsPendingAssignment.forEach((topicId, partitions) -> {
                Map<Integer, Integer> topicEpochs = newAssignedPartitions
                    .computeIfAbsent(topicId, __ -> new HashMap<>());
                for (Integer partitionId : partitions) {
                    topicEpochs.put(partitionId, targetAssignmentEpoch);
                }
            });
            MemberState newState = hasUnreleasedPartitions ? MemberState.UNRELEASED_PARTITIONS : MemberState.STABLE;
            return new ConsumerGroupMember.Builder(member)
                .setState(newState)
                .updateMemberEpoch(targetAssignmentEpoch)
                .setAssignedPartitions(newAssignedPartitions)
                .setPartitionsPendingRevocation(Map.of())
                .build();
        } else if (hasUnreleasedPartitions) {
            // If there are no partitions to be revoked nor to be assigned but some
            // partitions are not available yet, the member transitions to the target
            // epoch, to the UNRELEASED_PARTITIONS state and waits.
            return new ConsumerGroupMember.Builder(member)
                .setState(MemberState.UNRELEASED_PARTITIONS)
                .updateMemberEpoch(targetAssignmentEpoch)
                .setAssignedPartitions(newAssignedPartitions)
                .setPartitionsPendingRevocation(Map.of())
                .build();
        } else {
            // Otherwise, the member transitions to the target epoch and to the
            // STABLE state.
            return new ConsumerGroupMember.Builder(member)
                .setState(MemberState.STABLE)
                .updateMemberEpoch(targetAssignmentEpoch)
                .setAssignedPartitions(newAssignedPartitions)
                .setPartitionsPendingRevocation(Map.of())
                .build();
        }
    }

    /**
     * Gets the set of topic IDs that the member is subscribed to.
     *
     * @return The set of topic IDs that the member is subscribed to.
     */
    private Set<Uuid> subscribedTopicIds() {
        Set<String> subscriptions = member.subscribedTopicNames();
        String subscribedTopicRegex = member.subscribedTopicRegex();
        if (subscribedTopicRegex != null && !subscribedTopicRegex.isEmpty()) {
            ResolvedRegularExpression resolvedRegularExpression = resolvedRegularExpressions.get(subscribedTopicRegex);
            if (resolvedRegularExpression != null) {
                if (subscriptions.isEmpty()) {
                    subscriptions = resolvedRegularExpression.topics();
                } else if (!resolvedRegularExpression.topics().isEmpty()) {
                    subscriptions = new UnionSet<>(subscriptions, resolvedRegularExpression.topics());
                }
            } else {
                // Treat an unresolved regex as matching no topics, to be conservative.
            }
        }

        return new TopicIds(subscriptions, metadataImage);
    }
}