public class NodeTransformLib
{
    /** Do a node->node conversion of an Op - return original BGP for "no change" */
    public static Op transform(NodeTransform nodeTransform, Op op)
    {
        Transform opTransform = new NodeTransformOp(nodeTransform) ; 
        return Transformer.transform(opTransform, null, op) ;   // No expr transform - we do it ourselves.
    }
    
    /** Do a node->node conversion of a BGP - return original BGP for "no change" */
public static BasicPattern transform(NodeTransform nodeTransform, BasicPattern pattern)  
{
    return BasicPatternTransformUtil.transform(nodeTransform, pattern);
}
    /** Do a node->node conversion of a QuadPattern - return original QuadPattern for "no change" */
    public static QuadPattern transform(NodeTransform nodeTransform, QuadPattern pattern)  
    {
        QuadPattern qp2 = new QuadPattern() ;
        boolean changed = false ;
        for ( Quad quad : pattern )
        {
            Quad q2 = transform(nodeTransform, quad) ;
            qp2.add(q2) ;
            if ( q2 != quad )
                changed = true ;
        }
        if ( ! changed )
            return pattern ;
        return qp2 ;
    }

    /** Do a node->node conversion of a Triple - return original Triple for "no change" */
public static Triple transform(NodeTransform nodeTransform, Triple triple)  
{
    return TripleTransformUtil.transform(nodeTransform, triple);
}
    /** Do a node->node conversion of a Quad - return original Quad for "no change" */
public static Quad transform(NodeTransform nodeTransform, Quad quad)  
{
    return QuadTransformUtil.transform(nodeTransform, quad);
}    
    public static Table transform(Table table, NodeTransform transform) {
        // Non-streaming rewrite 
        List<Var> vars = transformVars(transform, table.getVars()) ;
        Iterator<Binding> iter = table.rows() ; 
        List<Binding> newRows = new ArrayList<>() ;
        for ( ; iter.hasNext() ; ) { 
            Binding b = iter.next() ;
            Binding b2 = transform(b, transform) ;
            newRows.add(b2) ;
        }
        return new TableData(vars, newRows) ;
    }
    
    public static Binding transform(Binding b, NodeTransform transform) {
        BindingMap b2 = BindingFactory.create() ;
        List<Var> vars = Iter.toList(b.vars()) ;
        for ( Var v : vars ) {
            Var v2 = (Var)transform.apply(v) ;
            b2.add(v2, b.get(v));
        }
        return b2 ;
    }



    /** Do a node->node conversion of a List&lt;Quad&gt; - return original List&lt;Quad&gt; for "no change" */
    public static List<Quad> transformQuads(NodeTransform nodeTransform, List<Quad> quads)
    {
        List<Quad> x = new ArrayList<>() ;
        boolean changed = false ; 
        for ( Quad q : quads )
        {
            Quad q2 = NodeTransformLib.transform(nodeTransform, q) ;
            if ( q != q2 )
                changed = true ;
            x.add(q2) ;
        }
        if ( ! changed )
            return quads ;
        return x ;
    }

    /** Do a node->node conversion of a VarExprList - return original VarExprList for "no change" */
    public static VarExprList transform(NodeTransform nodeTransform, VarExprList varExprList)
    {
        VarExprList varExprList2 = new VarExprList() ;
        boolean changed = false ;
        for ( Var v : varExprList.getVars() )
        {
            Expr expr = varExprList.getExpr(v) ;
            Var v2 = (Var)nodeTransform.apply(v) ;
            Expr expr2 = ( expr != null ) ? transform(nodeTransform, expr) : null ;
            
            if ( ! Objects.equals(v, v2) || ! Objects.equals(expr, expr2) )
                changed = true ;
            varExprList2.add(v2, expr2) ;
        }
        if ( ! changed )
            return varExprList ; 
        return varExprList2 ;
    }

    public static List<Var> transformVars(NodeTransform nodeTransform, List<Var> varList)
    {
        List<Var> varList2 = new ArrayList<>(varList.size()) ;
        boolean changed = false ;
        for ( Var v : varList )
        {
            Var v2 = (Var)nodeTransform.apply(v) ;
            varList2.add(v2) ;
            if ( !Objects.equals(v, v2) )
                changed = true ;
        }
        if ( ! changed )
            return varList ; 
        return varList2 ;
    }

    public static ExprList transform(NodeTransform nodeTransform, ExprList exprList)
    {
          ExprList exprList2 = new ExprList() ;
          boolean changed = false ;
          for(Expr expr : exprList)
          {
              Expr expr2 = transform(nodeTransform, expr) ;
              if ( expr != expr2 )
                  changed = true ;
              exprList2.add(expr2) ;
          }
          if ( ! changed ) return exprList ;
          return exprList2 ;
    }

    public static Expr transform(NodeTransform nodeTransform, Expr expr)
    {
        return expr.applyNodeTransform(nodeTransform) ;
    }

    public static List<SortCondition> transform(NodeTransform nodeTransform, List<SortCondition> conditions)
    {
        List<SortCondition> conditions2 = new ArrayList<>() ;
        boolean same = true ;
        for ( SortCondition sc : conditions )
        {
            Expr expr = sc.getExpression() ;
            Expr expr2 = transform(nodeTransform, expr) ;
            if ( expr != expr2 )
                same = false ;
            SortCondition sc2 = new SortCondition(expr2, sc.getDirection()) ;
            conditions2.add(sc2) ;
        }

        if ( same )
            return conditions ;
        return conditions2 ;
    }
}