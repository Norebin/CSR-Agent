public class IssuedTokenInterceptorProvider extends AbstractPolicyInterceptorProvider {
    
    private static final Logger LOG = LogUtils.getL7dLogger(IssuedTokenInterceptorProvider.class);
    
    private static final long serialVersionUID = -6936475570762840527L;
    private static final String ASSOCIATED_TOKEN = 
        IssuedTokenInterceptorProvider.class.getName() + "-" + "Associated_Token";

    public IssuedTokenInterceptorProvider() {
        super(Arrays.asList(SP11Constants.ISSUED_TOKEN, SP12Constants.ISSUED_TOKEN));
        
        //issued tokens can be attached as a supporting token without
        //any type of binding.  Make sure we can support that.
        this.getOutInterceptors().add(PolicyBasedWSS4JOutInterceptor.INSTANCE);
        this.getOutFaultInterceptors().add(PolicyBasedWSS4JOutInterceptor.INSTANCE);
        this.getInInterceptors().add(PolicyBasedWSS4JInInterceptor.INSTANCE);
        this.getInFaultInterceptors().add(PolicyBasedWSS4JInInterceptor.INSTANCE);
        
        this.getOutInterceptors().add(new IssuedTokenOutInterceptor());
        this.getOutFaultInterceptors().add(new IssuedTokenOutInterceptor());
        this.getInInterceptors().add(new IssuedTokenInInterceptor());
        this.getInFaultInterceptors().add(new IssuedTokenInInterceptor());
        
        this.getOutInterceptors().add(PolicyBasedWSS4JStaxOutInterceptor.INSTANCE);
        this.getOutFaultInterceptors().add(PolicyBasedWSS4JStaxOutInterceptor.INSTANCE);
        this.getInInterceptors().add(PolicyBasedWSS4JStaxInInterceptor.INSTANCE);
        this.getInFaultInterceptors().add(PolicyBasedWSS4JStaxInInterceptor.INSTANCE);
    }
    
protected static void assertIssuedToken(IssuedToken issuedToken, AssertionInfoMap aim) {
    if (issuedToken == null) {
        return;
    }
    // Assert some policies
    if (issuedToken.isRequireExternalReference()) {
        IssuedTokenPolicyUtils.assertPolicy(new QName(issuedToken.getName().getNamespaceURI(), 
                               SPConstants.REQUIRE_EXTERNAL_REFERENCE), aim);
    }
    if (issuedToken.isRequireInternalReference()) {
        IssuedTokenPolicyUtils.assertPolicy(new QName(issuedToken.getName().getNamespaceURI(), 
                               SPConstants.REQUIRE_INTERNAL_REFERENCE), aim);
    }
}

protected static void assertPolicy(QName n, AssertionInfoMap aim) {
    IssuedTokenPolicyUtils.assertPolicy(n, aim);
}    
/**
 * @deprecated Use org.apache.cxf.ws.security.policy.interceptors.IssuedTokenOutInterceptor instead.
 */
@Deprecated
static class IssuedTokenOutInterceptor extends AbstractPhaseInterceptor<Message> {
    private final org.apache.cxf.ws.security.policy.interceptors.IssuedTokenOutInterceptor delegate;

    public IssuedTokenOutInterceptor() {
        super(Phase.PREPARE_SEND);
        delegate = new org.apache.cxf.ws.security.policy.interceptors.IssuedTokenOutInterceptor();
    }

    public void handleMessage(Message message) throws Fault {
        delegate.handleMessage(message);
    }
}    
/**
 * @deprecated Use org.apache.cxf.ws.security.policy.interceptors.IssuedTokenInInterceptor instead.
 */
@Deprecated
static class IssuedTokenInInterceptor extends AbstractPhaseInterceptor<Message> {
    private final org.apache.cxf.ws.security.policy.interceptors.IssuedTokenInInterceptor delegate;

    public IssuedTokenInInterceptor() {
        super(Phase.PRE_PROTOCOL);
        addAfter(WSS4JInInterceptor.class.getName());
        addAfter(PolicyBasedWSS4JInInterceptor.class.getName());
        delegate = new org.apache.cxf.ws.security.policy.interceptors.IssuedTokenInInterceptor();
    }

    public void handleMessage(Message message) throws Fault {
        delegate.handleMessage(message);
    }
}        
}