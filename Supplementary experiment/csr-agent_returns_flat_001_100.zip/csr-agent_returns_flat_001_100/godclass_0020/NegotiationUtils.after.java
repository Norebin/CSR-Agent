final class NegotiationUtils {
    
    private NegotiationUtils() {
        // complete
    }

static Trust10 getTrust10(AssertionInfoMap aim) {
    return AssertionUtils.getTrust10(aim);
}    
    static Trust13 getTrust13(AssertionInfoMap aim) {
        AssertionInfo ai = PolicyUtils.getFirstAssertionByLocalname(aim, SPConstants.TRUST_13);
        if (ai == null) {
            return null;
        }
        return (Trust13)ai.getAssertion();
    }
    
    static Assertion getAddressingPolicy(AssertionInfoMap aim, boolean optional) {
        Collection<AssertionInfo> lst = aim.get(MetadataConstants.USING_ADDRESSING_2004_QNAME);
        Assertion assertion = null;
        if (null != lst && !lst.isEmpty()) {
            assertion = lst.iterator().next().getAssertion();
        }
        if (assertion == null) {
            lst = aim.get(MetadataConstants.USING_ADDRESSING_2005_QNAME);
            if (null != lst && !lst.isEmpty()) {
                assertion = lst.iterator().next().getAssertion();
            }
        }
        if (assertion == null) {
            lst = aim.get(MetadataConstants.USING_ADDRESSING_2006_QNAME);
            if (null != lst && !lst.isEmpty()) {
                assertion = lst.iterator().next().getAssertion();
            }
        }
        if (assertion == null) {
            return new PrimitiveAssertion(MetadataConstants.USING_ADDRESSING_2006_QNAME,
                                          optional);
        } else if (optional) {
            return new PrimitiveAssertion(assertion.getName(),
                                          optional);            
        }
        return assertion;
    }

    static AlgorithmSuite getAlgorithmSuite(AssertionInfoMap aim) {
        AbstractBinding transport = null;
        Collection<AssertionInfo> ais = 
            PolicyUtils.getAllAssertionsByLocalname(aim, SPConstants.TRANSPORT_BINDING);
        if (!ais.isEmpty()) {
            for (AssertionInfo ai : ais) {
                transport = (AbstractBinding)ai.getAssertion();
            }                    
        } else {
            ais = PolicyUtils.getAllAssertionsByLocalname(aim, SPConstants.ASYMMETRIC_BINDING);
            if (!ais.isEmpty()) {
                for (AssertionInfo ai : ais) {
                    transport = (AbstractBinding)ai.getAssertion();
                }                    
            } else {
                ais = PolicyUtils.getAllAssertionsByLocalname(aim, SPConstants.SYMMETRIC_BINDING);
                if (!ais.isEmpty()) {
                    for (AssertionInfo ai : ais) {
                        transport = (AbstractBinding)ai.getAssertion();
                    }                    
                }
            }
        }
        if (transport != null) {
            return transport.getAlgorithmSuite();
        }
        return null;
    }
    
static int getWSCVersion(String tokenTypeValue) throws WSSecurityException {
    return SecurityTokenUtils.getWSCVersion(tokenTypeValue);
}    
static void recalcEffectivePolicy(
    SoapMessage message, 
    String namespace, 
    Policy policy,
    Invoker invoker,
    boolean secConv
) {
    PolicyNegotiationHandler.recalcEffectivePolicy(message, namespace, policy, invoker, secConv);
}
    /**
     * Return true on successfully parsing a SecurityContextToken result
     */
    static boolean parseSCTResult(SoapMessage message) {
        List<WSHandlerResult> results = 
            CastUtils.cast((List<?>)message.get(WSHandlerConstants.RECV_RESULTS));
        if (results == null) {
            // Try Streaming results
            @SuppressWarnings("unchecked")
            final List<SecurityEvent> incomingEventList = 
                (List<SecurityEvent>) message.getExchange().get(SecurityEvent.class.getName() + ".in");
            if (incomingEventList != null) {
                for (SecurityEvent incomingEvent : incomingEventList) {
                    if (WSSecurityEventConstants.SecurityContextToken 
                        == incomingEvent.getSecurityEventType()) {
                        return true;
                    }
                }
            }
            return false;
        }
        
        for (WSHandlerResult rResult : results) {
            List<WSSecurityEngineResult> wsSecEngineResults = rResult.getResults();

            for (WSSecurityEngineResult wser : wsSecEngineResults) {
                Integer actInt = (Integer)wser.get(WSSecurityEngineResult.TAG_ACTION);
                if (actInt.intValue() == WSConstants.SCT) {
                    SecurityContextToken tok = 
                        (SecurityContextToken)wser.get(WSSecurityEngineResult.TAG_SECURITY_CONTEXT_TOKEN);
                    message.getExchange().put(SecurityConstants.TOKEN_ID, tok.getIdentifier());
                    
                    SecurityToken token = SecurityUtils.getTokenStore(message).getToken(tok.getIdentifier());
                    if (token == null || token.isExpired()) {
                        byte[] secret = (byte[])wser.get(WSSecurityEngineResult.TAG_SECRET);
                        if (secret != null) {
                            token = new SecurityToken(tok.getIdentifier());
                            token.setToken(tok.getElement());
                            token.setSecret(secret);
                            token.setTokenType(tok.getTokenType());
                            SecurityUtils.getTokenStore(message).add(token);
                        }
                    }
                    if (token != null) {
                        final SecurityContext sc = token.getSecurityContext();
                        if (sc != null) {
                            message.put(SecurityContext.class, sc);
                        }
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
}