public class RMOutInterceptor extends AbstractRMInterceptor<Message>  {
    
    private static final Logger LOG = LogUtils.getL7dLogger(RMOutInterceptor.class);
 
    public RMOutInterceptor() {
        addAfter(MAPAggregator.class.getName());
    }
    
protected void handle(Message msg) throws SequenceFault, RMException {  
    AddressingProperties maps = ContextUtils.retrieveMAPs(msg, false, true,  false);
    if (null == maps) {
        LogUtils.log(LOG, Level.WARNING, "MAPS_RETRIEVAL_FAILURE_MSG");
        return;
    }
    
    if (isRuntimeFault(msg)) {
        LogUtils.log(LOG, Level.WARNING, "RUNTIME_FAULT_MSG");
        // in case of a SequenceFault or other WS-RM related fault, set action appropriately.
        // the received inbound maps is available to extract some values in case if needed.
        Throwable cause = msg.getContent(Exception.class).getCause();
        if (cause instanceof SequenceFault || cause instanceof RMException) {
            maps.getAction().setValue(getAddressingNamespace(maps) + "/fault");
        }
        return;
    }

    Source source = getManager().getSource(msg);
    
    RMConfiguration config = getManager().getEffectiveConfiguration(msg);
    String wsaNamespace = config.getAddressingNamespace();
    String rmNamespace = config.getRMNamespace();
    ProtocolVariation protocol = ProtocolVariation.findVariant(rmNamespace, wsaNamespace);
    RMContextUtils.setProtocolVariation(msg, protocol);
    maps.exposeAs(wsaNamespace);
    Destination destination = getManager().getDestination(msg);

    String action = null;
    if (null != maps.getAction()) {
        action = maps.getAction().getValue();
    }
    
    if (LOG.isLoggable(Level.FINE)) {
        LOG.fine("Action: " + action);
    }

    boolean isApplicationMessage = !RMContextUtils.isRMProtocolMessage(action);
    boolean isPartialResponse = MessageUtils.isPartialResponse(msg);
    RMConstants constants = protocol.getConstants();
    boolean isLastMessage = constants.getCloseSequenceAction().equals(action);
    
    if (isApplicationMessage && !isPartialResponse) {
        addRetransmissionInterceptor(msg);
    }
    
    RMProperties rmpsOut = RMContextUtils.retrieveRMProperties(msg, true);
    if (null == rmpsOut) {
        rmpsOut = new RMProperties();
        rmpsOut.exposeAs(protocol.getWSRMNamespace());
        RMContextUtils.storeRMProperties(msg, rmpsOut, true);
    }
    
    // Activate process response for oneWay
    if (msg.getExchange().isOneWay()) {
        msg.getExchange().put(Message.PROCESS_ONEWAY_RESPONSE, true);
    }
    
    RMProperties rmpsIn = null;
    Identifier inSeqId = null;
    long inMessageNumber = 0;
    
    if (isApplicationMessage) {
        rmpsIn = RMContextUtils.retrieveRMProperties(msg, false);
        if (null != rmpsIn && null != rmpsIn.getSequence()) {
            inSeqId = rmpsIn.getSequence().getIdentifier();
            inMessageNumber = rmpsIn.getSequence().getMessageNumber();
        }
        ContextUtils.storeDeferUncorrelatedMessageAbort(msg);
    }
    
    Map<?, ?> invocationContext = (Map<?, ?>)msg.get(Message.INVOCATION_CONTEXT);
    if ((isApplicationMessage || (isLastMessage && invocationContext != null)) && !isPartialResponse) {
        if (LOG.isLoggable(Level.FINE)) {
            LOG.fine("inbound sequence: " + (null == inSeqId ? "null" : inSeqId.getValue()));
        }
        
        // get the current sequence, requesting the creation of a new one if necessary
        
        synchronized (source) {
            SourceSequence seq = null;
            if (isLastMessage) {
                seq = (SourceSequence)invocationContext.get(SourceSequence.class.getName());
            } else {
                seq = getManager().getSequence(inSeqId, msg, maps);
            }
            assert null != seq;

            // increase message number and store a sequence type object in
            // context
            seq.nextMessageNumber(inSeqId, inMessageNumber, isLastMessage);
            
            if (Boolean.TRUE.equals(msg.getContextualProperty(RMManager.WSRM_LAST_MESSAGE_PROPERTY))) {
                // mark the message as the last one
                seq.setLastMessage(true);
            }
            
            rmpsOut.setSequence(seq);

            // if this was the last message in the sequence, reset the
            // current sequence so that a new one will be created next
            // time the handler is invoked

            if (seq.isLastMessage()) {
                source.setCurrent(null);
            }
        }
    } else if (!MessageUtils.isRequestor(msg) && constants.getCreateSequenceAction().equals(action)) {
        maps.getAction().setValue(constants.getCreateSequenceResponseAction());
    } else if (isPartialResponse && action == null
        && isResponseToAction(msg, constants.getSequenceAckAction())) {
        Collection<SequenceAcknowledgement> acks = rmpsIn.getAcks();
        if (acks.size() == 1) {
            SourceSequence ss = source.getSequence(acks.iterator().next().getIdentifier());
            if (ss != null && ss.allAcknowledged()) {
                setAction(maps, constants.getTerminateSequenceAction());
                setTerminateSequence(msg, ss.getIdentifier(), protocol);
                msg.remove(Message.EMPTY_PARTIAL_RESPONSE_MESSAGE);
                // removing this sequence now. See the comment in SourceSequence.setAcknowledged()
                source.removeSequence(ss);
            }
        }
    }
    
    // add Acknowledgements (to application messages or explicitly 
    // created Acknowledgement messages only)
    if (isApplicationMessage || constants.getSequenceAckAction().equals(action)) {
        AttributedURIType to = maps.getTo();
        assert null != to;
        addAcknowledgements(destination, rmpsOut, inSeqId, to);
        if (isPartialResponse && rmpsOut.getAcks() != null && rmpsOut.getAcks().size() > 0) {
            setAction(maps, constants.getSequenceAckAction());
            msg.remove(Message.EMPTY_PARTIAL_RESPONSE_MESSAGE);
        }
    } 
    if (constants.getSequenceAckAction().equals(action)
        || constants.getTerminateSequenceAction().equals(action)) {
        maps.setReplyTo(RMUtils.createNoneReference());
    }
    
    assertReliability(msg);
}
    private void addRetransmissionInterceptor(Message msg) {
        RetransmissionInterceptor ri = new RetransmissionInterceptor();
        ri.setManager(getManager());
        // TODO:
        // On the server side: If a fault occurs after this interceptor we will switch 
        // interceptor chains (if this is not already a fault message) and therefore need to 
        // make sure the retransmission interceptor is added to the fault chain
        // 
        msg.getInterceptorChain().add(ri);
        LOG.fine("Added RetransmissionInterceptor to chain.");
        
        getManager().getRetransmissionQueue().start();
    }

    private String getAddressingNamespace(AddressingProperties maps) {
        String wsaNamespace = maps.getNamespaceURI();
        if (wsaNamespace == null) {
            getManager().getConfiguration().getAddressingNamespace();
        }
        return wsaNamespace;
    }
    
    void addAcknowledgements(Destination destination, 
                             RMProperties rmpsOut, 
                             Identifier inSeqId, 
                             AttributedURIType to) {
        for (DestinationSequence seq : destination.getAllSequences()) {
            if (!seq.sendAcknowledgement()) {
                if (LOG.isLoggable(Level.FINE)) {
                    LOG.fine("no need to add acknowledgements for sequence "
                        + seq.getIdentifier().getValue()); 
                }
                continue;
            }
            String address = seq.getAcksTo().getAddress().getValue();
            if (!to.getValue().equals(address)) {
                if (LOG.isLoggable(Level.FINE)) {
                    LOG.fine("sequences acksTo address (" + address
                        + ") does not match to address (" + to.getValue() + ")");
                }
                continue;
            }
            // there may be multiple sources with anonymous acksTo 
            if (RMUtils.getAddressingConstants().getAnonymousURI().equals(address)
                && !AbstractSequence.identifierEquals(seq.getIdentifier(), inSeqId)) {                
                if (LOG.isLoggable(Level.FINE)) {
                    LOG.fine("sequence identifier does not match inbound sequence identifier");
                }
                continue;
            }
            rmpsOut.addAck(seq);
        }

        if (LOG.isLoggable(Level.FINE)) {
            Collection<SequenceAcknowledgement> acks = rmpsOut.getAcks();
            if (null == acks) {
                LOG.fine("No acknowledgements added.");
            } else {
                LOG.fine("Added " + acks.size() + " acknowledgements.");
            }
        }
    }
    
    boolean isRuntimeFault(Message message) {
        FaultMode mode = MessageUtils.getFaultMode(message);
        if (null == mode) {
            return false;
        }
        return FaultMode.CHECKED_APPLICATION_FAULT != mode;
    }

    private boolean isResponseToAction(Message msg, String action) {
        AddressingProperties inMaps = RMContextUtils.retrieveMAPs(msg, false, false);
        String inAction = null;
        if (null != inMaps.getAction()) {
            inAction = inMaps.getAction().getValue();
        }
        return action.equals(inAction);
    }
    
    private void setTerminateSequence(Message msg, Identifier identifier, ProtocolVariation protocol) 
        throws RMException {
        TerminateSequenceType ts = new TerminateSequenceType();
        ts.setIdentifier(identifier);
        MessageContentsList contents = 
            new MessageContentsList(new Object[]{protocol.getCodec().convertToSend(ts)});
        msg.setContent(List.class, contents);

        // create a new exchange for this output-only exchange
        Exchange newex = new ExchangeImpl();
        Exchange oldex = msg.getExchange();
        
        newex.put(Bus.class, oldex.getBus());
        newex.put(Endpoint.class, oldex.getEndpoint());
        newex.put(Service.class, oldex.getEndpoint().getService());
        newex.put(Binding.class, oldex.getEndpoint().getBinding());
        newex.setConduit(oldex.getConduit(msg));
        newex.setDestination(oldex.getDestination());
        
        //Setup the BindingOperationInfo
        RMEndpoint rmep = getManager().getReliableEndpoint(msg);
        OperationInfo oi = rmep.getEndpoint(protocol).getEndpointInfo().getService().getInterface()
            .getOperation(protocol.getConstants().getTerminateSequenceAnonymousOperationName());
        BindingInfo bi = rmep.getBindingInfo(protocol);
        BindingOperationInfo boi = bi.getOperation(oi);
        
        newex.put(BindingInfo.class, bi);
        newex.put(BindingOperationInfo.class, boi);
        newex.put(OperationInfo.class, boi.getOperationInfo());
        
        msg.setExchange(newex);
        newex.setOutMessage(msg);
    }

    private static void setAction(AddressingProperties maps, String action) {
        AttributedURIType actionURI = new AttributedURIType();
        actionURI.setValue(action);
        maps.setAction(actionURI);
    }
}