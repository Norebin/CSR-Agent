class LuceneQueryBuilder implements QueryNodeVisitor {

    /** Logger for this class */
    private static final Logger log = Logger.getLogger(LuceneQueryBuilder.class);

    /** QName for jcr:primaryType */
    private static QName primaryType = new QName(NamespaceRegistryImpl.NS_JCR_URI, "primaryType");

    /** Root node of the abstract query tree */
    private QueryRootNode root;

    /** Session of the user executing this query */
    private SessionImpl session;

    /** Namespace mappings to internal prefixes */
    private NamespaceMappings nsMappings;

    /** The analyzer instance to use for contains function query parsing */
    private Analyzer analyzer;

    /** Exceptions thrown during tree translation */
    private List exceptions = new ArrayList();

    /**
     * Creates a new <code>LuceneQueryBuilder</code> instance.
     * @param root the root node of the abstract query tree.
     * @param session of the user executing this query.
     * @param nsMappings namespace resolver for internal prefixes.
     * @param analyzer for parsing the query statement of the contains function.
     */
    private LuceneQueryBuilder(QueryRootNode root,
                               SessionImpl session,
                               NamespaceMappings nsMappings,
                               Analyzer analyzer) {
        this.root = root;
        this.session = session;
        this.nsMappings = nsMappings;
        this.analyzer = analyzer;
    }

    /**
     * Creates a lucene {@link org.apache.lucene.search.Query} tree from an
     * abstract query tree.
     * @param root the root node of the abstract query tree.
     * @param session of the user executing the query.
     * @param nsMappings namespace resolver for internal prefixes.
     * @param analyzer for parsing the query statement of the contains function.
     * @return the lucene query tree.
     * @throws RepositoryException if an error occurs during the translation.
     */
public static Query createQuery(QueryRootNode root,
                                SessionImpl session,
                                NamespaceMappings nsMappings,
                                Analyzer analyzer)
        throws RepositoryException {

    LuceneQueryNodeVisitor visitor = new LuceneQueryNodeVisitor(session, nsMappings, analyzer);
    Query q = (Query) root.accept(visitor, null);

    if (visitor.getExceptions().size() > 0) {
        StringBuffer msg = new StringBuffer();
        for (Iterator it = visitor.getExceptions().iterator(); it.hasNext();) {
            msg.append(it.next().toString()).append('\n');
        }
        throw new RepositoryException("Exception building query: " + msg.toString());
    }
    return q;
}
    /**
     * Starts the tree traversal and returns the lucene
     * {@link org.apache.lucene.search.Query}.
     * @return the lucene <code>Query</code>.
     */
    private Query createLuceneQuery() {
        return (Query) root.accept(this, null);
    }

    //---------------------< QueryNodeVisitor interface >-----------------------

    public Object visit(QueryRootNode node, Object data) {
        BooleanQuery root = new BooleanQuery();

        QName[] props = node.getSelectProperties();
        for (int i = 0; i < props.length; i++) {
            try {
                String prop = props[i].toJCRName(nsMappings);
                // @todo really search nodes that have non null values?
                root.add(new MatchAllQuery(prop), true, false);
            } catch (NoPrefixDeclaredException e) {
                // should never happen actually. prefixes are dynamically created
                exceptions.add(e);
            }
        }

        Query wrapped = root;
        if (node.getLocationNode() != null) {
            wrapped = (Query) node.getLocationNode().accept(this, root);
        }

        return wrapped;
    }

    public Object visit(OrQueryNode node, Object data) {
        BooleanQuery orQuery = new BooleanQuery();
        Object[] result = node.acceptOperands(this, null);
        for (int i = 0; i < result.length; i++) {
            Query operand = (Query) result[i];
            orQuery.add(operand, false, false);
        }
        return orQuery;
    }

    public Object visit(AndQueryNode node, Object data) {
        Object[] result = node.acceptOperands(this, null);
        if (result.length == 0) {
            return null;
        }
        BooleanQuery andQuery = new BooleanQuery();
        for (int i = 0; i < result.length; i++) {
            Query operand = (Query) result[i];
            andQuery.add(operand, true, false);
        }
        return andQuery;
    }

    public Object visit(NotQueryNode node, Object data) {
        BooleanQuery notQuery = new BooleanQuery();
        try {
            // first select any node
            notQuery.add(new MatchAllQuery(primaryType.toJCRName(nsMappings)),
                    false, false);
        } catch (NoPrefixDeclaredException e) {
            // will never happen, prefixes are created when unknown
        }
        Object[] result = node.acceptOperands(this, null);
        for (int i = 0; i < result.length; i++) {
            Query operand = (Query) result[i];
            // then prohibit the nodes from the not clause
            notQuery.add(operand, false, true);
        }
        return notQuery;
    }

    public Object visit(ExactQueryNode node, Object data) {
        String field = "";
        String value = "";
        try {
            field = node.getPropertyName().toJCRName(nsMappings);
            value = node.getValue().toJCRName(nsMappings);
        } catch (NoPrefixDeclaredException e) {
            // will never happen, prefixes are created when unknown
        }
        return new TermQuery(new Term(field, value));
    }

    public Object visit(NodeTypeQueryNode node, Object data) {
        String field = "";
        List values = new ArrayList();
        try {
            field = NodeTypeRegistry.JCR_PRIMARY_TYPE.toJCRName(nsMappings);
            values.add(node.getValue().toJCRName(nsMappings));
            NodeTypeManager ntMgr = session.getWorkspace().getNodeTypeManager();
            NodeType base = ntMgr.getNodeType(node.getValue().toJCRName(session.getNamespaceResolver()));
            NodeTypeIterator allTypes = ntMgr.getAllNodeTypes();
            while (allTypes.hasNext()) {
                NodeType nt = allTypes.nextNodeType();
                NodeType[] superTypes = nt.getSupertypes();
                if (Arrays.asList(superTypes).contains(base)) {
                    values.add(nsMappings.translatePropertyName(nt.getName(),
                            session.getNamespaceResolver()));
                }
            }
        } catch (IllegalNameException e) {
            exceptions.add(e);
        } catch (UnknownPrefixException e) {
            exceptions.add(e);
        } catch (NoPrefixDeclaredException e) {
            // should never happen
            exceptions.add(e);
        } catch (RepositoryException e) {
            exceptions.add(e);
        }
        if (values.size() == 0) {
            // exception occured
            return new BooleanQuery();
        } else if (values.size() == 1) {
            return new TermQuery(new Term(field, (String) values.get(0)));
        } else {
            BooleanQuery b = new BooleanQuery();
            for (Iterator it = values.iterator(); it.hasNext();) {
                b.add(new TermQuery(new Term(field, (String)it.next())), false, false);
            }
            return b;
        }
    }

    public Object visit(RangeQueryNode node, Object data) {
        return null;
    }

    public Object visit(TextsearchQueryNode node, Object data) {
        try {
            org.apache.lucene.queryParser.QueryParser parser
                    = new org.apache.lucene.queryParser.QueryParser(FieldNames.FULLTEXT, analyzer);
            parser.setOperator(org.apache.lucene.queryParser.QueryParser.DEFAULT_OPERATOR_AND);
            // replace unescaped ' with " and escaped ' with just '
            StringBuffer query = new StringBuffer();
            String textsearch = node.getQuery();
            boolean escaped = false;
            for (int i = 0; i < textsearch.length(); i++) {
                if (textsearch.charAt(i) == '\\') {
                    if (escaped) {
                        query.append("\\\\");
                        escaped = false;
                    } else {
                        escaped = true;
                    }
                } else if (textsearch.charAt(i) == '\'') {
                    if (escaped) {
                        query.append('\'');
                        escaped = false;
                    } else {
                        query.append('\"');
                    }
                } else {
                    if (escaped) {
                        query.append('\\');
                        escaped = false;
                    }
                    query.append(textsearch.charAt(i));
                }
            }
            return parser.parse(query.toString());
        } catch (ParseException e) {
            exceptions.add(e);
        }
        return null;
    }

    public Object visit(PathQueryNode node, Object data) {
        Query context = null;
        // loop over steps
        QueryNode[] steps = node.getPathSteps();
        for (int i = 0; i < steps.length; i++) {
            context = (Query) steps[i].accept(this, context);
        }
        if (data instanceof BooleanQuery) {
            BooleanQuery constraint = (BooleanQuery) data;
            if (constraint.getClauses().length > 0) {
                constraint.add(context, true, false);
                context = constraint;
            }
        }
        return context;
    }

    public Object visit(LocationStepQueryNode node, Object data) {
        if (node.getNameTest() != null && node.getNameTest().getLocalName().length() == 0) {
            // select root node
            return new TermQuery(new Term(FieldNames.PARENT, ""));
        }

        Query context = (Query) data;

        BooleanQuery andQuery = new BooleanQuery();
        if (context == null) {
            exceptions.add(new IllegalArgumentException("Unsupported query"));
        }

        // predicate on step?
        Object[] predicates = node.acceptOperands(this, data);
        for (int i = 0; i < predicates.length; i++) {
            andQuery.add((Query) predicates[i], true, false);
        }

        TermQuery nameTest = null;
        if (node.getNameTest() != null) {
            try {
                String internalName = node.getNameTest().toJCRName(nsMappings);
                nameTest = new TermQuery(new Term(FieldNames.LABEL, internalName));
            } catch (NoPrefixDeclaredException e) {
                // should never happen
                exceptions.add(e);
            }
        }

        if (node.getIncludeDescendants()) {
            if (nameTest != null) {
                andQuery.add(new DescendantSelfAxisQuery(context, nameTest), true, false);
            } else {
                // descendant-or-self with nametest=*
                if (predicates.length > 0) {
                    // if we have a predicate attached, the condition acts as
                    // the sub query.
                    Query subQuery = new DescendantSelfAxisQuery(context, andQuery);
                    andQuery = new BooleanQuery();
                    andQuery.add(subQuery, true, false);
                } else {
                    // @todo this will traverse the whole index, optimize!
                    Query subQuery = new MatchAllQuery(FieldNames.UUID);
                    andQuery.add(new DescendantSelfAxisQuery(context, subQuery), true, false);
                }
            }
        } else {
            // select child nodes
            andQuery.add(new ChildAxisQuery(context), true, false);

            // name test
            if (nameTest != null) {
                andQuery.add(nameTest, true, false);
            }
        }

        return andQuery;
    }

    public Object visit(RelationQueryNode node, Object data) {
        Query query;
        String stringValue = null;
        switch (node.getType()) {
            case 0:
                // not set: either IS NULL or IS NOT NULL
                break;
            case Constants.TYPE_DATE:
                stringValue = DateField.dateToString(node.getDateValue());
                break;
            case Constants.TYPE_DOUBLE:
                stringValue = DoubleField.doubleToString(node.getDoubleValue());
                break;
            case Constants.TYPE_LONG:
                stringValue = LongField.longToString(node.getLongValue());
                break;
            case Constants.TYPE_STRING:
                stringValue = node.getStringValue();
                break;
            default:
                throw new IllegalArgumentException("Unknown relation type: "
                        + node.getType());
        }

        String field = "";
        String primaryTypeField = "";
        String mvpField = "";
        try {
            field = node.getProperty().toJCRName(nsMappings);
            primaryTypeField = primaryType.toJCRName(nsMappings);
            StringBuffer tmp = new StringBuffer();
            tmp.append(nsMappings.getPrefix(node.getProperty().getNamespaceURI()));
            tmp.append(':').append(FieldNames.MVP_PREFIX);
            tmp.append(node.getProperty().getLocalName());
            mvpField = tmp.toString();
        } catch (NamespaceException e) {
            // should never happen
            exceptions.add(e);
        } catch (NoPrefixDeclaredException e) {
            // should never happen
            exceptions.add(e);
        }

        switch (node.getOperation()) {
            case Constants.OPERATION_EQ_VALUE:      // =
                query = new TermQuery(new Term(field, stringValue));
                break;
            case Constants.OPERATION_EQ_GENERAL:    // =
                // search in single and multi valued properties
                BooleanQuery or = new BooleanQuery();
                or.add(new TermQuery(new Term(field, stringValue)), false, false);
                or.add(new TermQuery(new Term(mvpField, stringValue)), false, false);
                query = or;
                break;
            case Constants.OPERATION_GE_VALUE:      // >=
                query = new RangeQuery(new Term(field, stringValue), null, true);
                break;
            case Constants.OPERATION_GT_VALUE:      // >
                query = new RangeQuery(new Term(field, stringValue), null, false);
                break;
            case Constants.OPERATION_LE_VALUE:      // <=
                query = new RangeQuery(null, new Term(field, stringValue), true);
                break;
            case Constants.OPERATION_LIKE:          // LIKE
                if (stringValue.equals("%")) {
                    query = new MatchAllQuery(field);
                } else {
                    query = new WildcardQuery(new Term(field, stringValue));
                }
                break;
            case Constants.OPERATION_LT_VALUE:      // <
                query = new RangeQuery(null, new Term(field, stringValue), false);
                break;
            case Constants.OPERATION_NE_VALUE:      // !=
                BooleanQuery notQuery = new BooleanQuery();
                notQuery.add(new MatchAllQuery(field), false, false);
                notQuery.add(new TermQuery(new Term(field, stringValue)), false, true);
                query = notQuery;
                break;
            case Constants.OPERATION_NE_GENERAL:    // !=
                // search in single and multi valued properties
                notQuery = new BooleanQuery();
                notQuery.add(new MatchAllQuery(field), false, false);
                notQuery.add(new MatchAllQuery(mvpField), false, false);
                notQuery.add(new TermQuery(new Term(field, stringValue)), false, true);
                notQuery.add(new TermQuery(new Term(mvpField, stringValue)), false, true);
                query = notQuery;
                break;
            case Constants.OPERATION_NULL:
                notQuery = new BooleanQuery();
                notQuery.add(new MatchAllQuery(primaryTypeField), false, false);
                notQuery.add(new MatchAllQuery(field), false, true);
                query = notQuery;
                break;
            case Constants.OPERATION_NOT_NULL:
                query = new MatchAllQuery(field);
                break;
            default:
                throw new IllegalArgumentException("Unknown relation operation: "
                        + node.getOperation());
        }
        return query;
    }

    public Object visit(OrderQueryNode node, Object data) {
        return data;
    }
}