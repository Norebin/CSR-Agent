public class StreamsMembershipManager implements RequestManager {

    /**
     * A data structure to represent the current task assignment, and target task assignment of a member in a
     * streams group.
     * <p/>
     * Besides the assigned tasks, it contains a local epoch that is bumped whenever the assignment changes, to ensure
     * that two assignments with the same tasks but different local epochs are not considered equal.
     */
    private static class LocalAssignment {
        public static final long NONE_EPOCH = -1;
        public static final LocalAssignment NONE = new LocalAssignment(
            NONE_EPOCH,
            Collections.emptyMap(),
            Collections.emptyMap(),
            Collections.emptyMap(),
            false
        );

        public final long localEpoch;
        public final Map<String, SortedSet<Integer>> activeTasks;
        public final Map<String, SortedSet<Integer>> standbyTasks;
        public final Map<String, SortedSet<Integer>> warmupTasks;
        public final boolean isGroupReady;

        public LocalAssignment(final long localEpoch,
                               final Map<String, SortedSet<Integer>> activeTasks,
                               final Map<String, SortedSet<Integer>> standbyTasks,
                               final Map<String, SortedSet<Integer>> warmupTasks,
                               final boolean isGroupReady) {
            this.localEpoch = localEpoch;
            this.activeTasks = activeTasks;
            this.standbyTasks = standbyTasks;
            this.warmupTasks = warmupTasks;
            this.isGroupReady = isGroupReady;
            if (localEpoch == NONE_EPOCH &&
                    (!activeTasks.isEmpty() || !standbyTasks.isEmpty() || !warmupTasks.isEmpty())) {
                throw new IllegalArgumentException("Local epoch must be set if tasks are assigned.");
            }
        }

Optional<LocalAssignment> updateWith(final Map<String, SortedSet<Integer>> activeTasks,
                                     final Map<String, SortedSet<Integer>> standbyTasks,
                                     final Map<String, SortedSet<Integer>> warmupTasks,
                                     final boolean isGroupReady) {
    if (localEpoch != NONE_EPOCH &&
            activeTasks.equals(this.activeTasks) &&
            standbyTasks.equals(this.standbyTasks) &&
            warmupTasks.equals(this.warmupTasks) &&
            isGroupReady == this.isGroupReady
    ) {
        return Optional.empty();
    }

    long nextLocalEpoch = localEpoch + 1;
    return Optional.of(new LocalAssignment(nextLocalEpoch, activeTasks, standbyTasks, warmupTasks, isGroupReady));
}
        @Override
        public String toString() {
            return "LocalAssignment{" +
                "localEpoch=" + localEpoch +
                ", activeTasks=" + activeTasks +
                ", standbyTasks=" + standbyTasks +
                ", warmupTasks=" + warmupTasks +
                ", isGroupReady=" + isGroupReady +
                '}';
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            LocalAssignment that = (LocalAssignment) o;
            return localEpoch == that.localEpoch &&
                Objects.equals(activeTasks, that.activeTasks) &&
                Objects.equals(standbyTasks, that.standbyTasks) &&
                Objects.equals(warmupTasks, that.warmupTasks) &&
                isGroupReady == that.isGroupReady;
        }

        @Override
        public int hashCode() {
            return Objects.hash(localEpoch, activeTasks, standbyTasks, warmupTasks, isGroupReady);
        }
    }