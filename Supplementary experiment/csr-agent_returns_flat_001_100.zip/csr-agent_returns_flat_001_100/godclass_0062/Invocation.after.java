public class Invocation implements PrintableInvocation, InvocationOnMock, PrintingFriendlyInvocation {

    private static final int MAX_LINE_LENGTH = 45;
    private final int sequenceNumber;
    private final Object mock;
    private final Method method;
    private final Object[] arguments;
    private final Location location;

    private boolean verified;
    private boolean verifiedInOrder;
    private Object[] rawArguments;
    final RealMethod realMethod;

    public Invocation(Object mock, Method method, Object[] args, int sequenceNumber, RealMethod realMethod) {
        this.mock = mock;
        this.method = method;
        this.realMethod = realMethod;
private static Object[] expandVarArgs(final boolean isVarArgs, final Object[] args) {
    ArgumentHandler argumentHandler = new ArgumentHandler();
    return argumentHandler.expandVarArgs(isVarArgs, args);
}
    public Object getMock() {
        return mock;
    }

    public Method getMethod() {
        return method;
    }

    public Object[] getArguments() {
        return arguments;
    }

    public boolean isVerified() {
        return verified;
    }

    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    public boolean isVerifiedInOrder() {
        return verifiedInOrder;
    }

public boolean equals(Object o) {
    if (o == null || !o.getClass().equals(this.getClass())) {
        return false;
    }

    Invocation other = (Invocation) o;
    ArgumentHandler argumentHandler = new ArgumentHandler();

    return this.mock.equals(other.mock) && this.method.equals(other.method)
            && argumentHandler.equalArguments(this.arguments, other.arguments);
}
    private boolean equalArguments(Object[] arguments) {
        return Arrays.equals(arguments, this.arguments);
    }

    public int hashCode() {
        throw new RuntimeException("hashCode() is not implemented");
    }

public String toString() {
    InvocationPrinter printer = new InvocationPrinter();
    return printer.toString(this);
}

protected String toString(List<Matcher> matchers, PrintSettings printSettings) {
    InvocationPrinter printer = new InvocationPrinter();
    return printer.toString(this, matchers, printSettings);
}
    private String qualifiedMethodName() {
        return new MockUtil().getMockName(mock) + "." + method.getName();
    }

    protected List<Matcher> argumentsToMatchers() {
        List<Matcher> matchers = new ArrayList<Matcher>(arguments.length);
        for (Object arg : arguments) {
            if (arg != null && arg.getClass().isArray()) {
                matchers.add(new ArrayEquals(arg));
            } else {
                matchers.add(new Equals(arg));
            }
        }
        return matchers;
    }

    public static boolean isToString(InvocationOnMock invocation) {
        return isToString(invocation.getMethod());
    }

    public static boolean isToString(Method method) {
        return method.getReturnType() == String.class && method.getParameterTypes().length == 0
                && method.getName().equals("toString");
    }

    public boolean isValidException(Throwable throwable) {
        Class<?>[] exceptions = this.getMethod().getExceptionTypes();
        Class<?> throwableClass = throwable.getClass();
        for (Class<?> exception : exceptions) {
            if (exception.isAssignableFrom(throwableClass)) {
                return true;
            }
        }

        return false;
    }

    public boolean isValidReturnType(Class clazz) {
        if (method.getReturnType().isPrimitive()) {
            return Primitives.primitiveTypeOf(clazz) == method.getReturnType();
        } else {
            return method.getReturnType().isAssignableFrom(clazz);
        }
    }

    public boolean isVoid() {
        return this.method.getReturnType() == Void.TYPE;
    }

    public String printMethodReturnType() {
        return method.getReturnType().getSimpleName();
    }

    public String getMethodName() {
        return method.getName();
    }

    public boolean returnsPrimitive() {
        return method.getReturnType().isPrimitive();
    }

    public Location getLocation() {
        return location;
    }

    public int getArgumentsCount() {
        return arguments.length;
    }

    public Object[] getRawArguments() {
        return this.rawArguments;
    }

    public Object callRealMethod() throws Throwable {
        return realMethod.invoke(mock, arguments);
    }

    public String toString(PrintSettings printSettings) {
        return toString(argumentsToMatchers(), printSettings);
    }

    void markVerified() {
        this.verified = true;
    }

    void markVerifiedInOrder() {
        markVerified();
        this.verifiedInOrder = true;
    }
}