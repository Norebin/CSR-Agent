public abstract class Lifecycle {
    private static Lifecycle INSTANCE = null;

    /**
     * Gets the singleton instance.
     */
    @NonNull
@NonNull
public static synchronized Lifecycle get() {
    if (INSTANCE == null) {
        Lifecycle instance;
        try {
            instance = LifecycleFactory.createLifecycle();
        } catch (ClassNotFoundException e) {
            LOGGER.log(Level.FINE, e, () -> "Failed to load lifecycle class so will try again later");
            instance = new PlaceholderLifecycle();
        } catch (NoSuchMethodException e) {
            NoSuchMethodError x = new NoSuchMethodError(e.getMessage());
            x.initCause(e);
            throw x;
        } catch (InstantiationException e) {
            InstantiationError x = new InstantiationError(e.getMessage());
            x.initCause(e);
            throw x;
        } catch (IllegalAccessException e) {
            IllegalAccessError x = new IllegalAccessError(e.getMessage());
            x.initCause(e);
            throw x;
        } catch (InvocationTargetException e) {
            Throwable t = e.getCause();
            switch (t) {
                case RuntimeException runtimeException -> throw runtimeException;
                case IOException ioException -> throw new UncheckedIOException(ioException);
                case Exception exception -> throw new RuntimeException(t);
                case Error error -> throw error;
                case null, default -> throw new Error(e);
            }
        }
        assert instance != null;
        INSTANCE = instance;
    }

    return INSTANCE;
}
    /**
     * If the location of {@code jenkins.war} is known in this life cycle,
     * return it location. Otherwise return null to indicate that it is unknown.
     *
     * <p>
     * When a non-null value is returned, Hudson will offer an upgrade UI
     * to a newer version.
     */
public File getHudsonWar() {
    return JenkinsWarManager.getHudsonWar();
}
    /**
     * Replaces jenkins.war by the given file.
     *
     * <p>
     * On some system, most notably Windows, a file being in use cannot be changed,
     * so rewriting {@code jenkins.war} requires some special trick. Override this method
     * to do so.
     */
public void rewriteHudsonWar(File by) throws IOException {
    JenkinsWarManager.rewriteHudsonWar(by);
}
    /**
     * Can {@link #rewriteHudsonWar(File)} work?
     */
    public boolean canRewriteHudsonWar() {
        // if we don't know where jenkins.war is, it's impossible to replace.
        File f = getHudsonWar();
        if (f == null || !f.canWrite()) {
            return false;
        }
        File parent = f.getParentFile();
        if (parent == null || !parent.canWrite()) {
            return false;
        }
        return true;
    }

    /**
     * If this life cycle supports a restart of Hudson, do so.
     * Otherwise, throw {@link UnsupportedOperationException},
     * which is what the default implementation does.
     *
     * <p>
     * The restart operation may happen synchronously (in which case
     * this method will never return), or asynchronously (in which
     * case this method will successfully return.)
     *
     * <p>
     * Throw an exception if the operation fails unexpectedly.
     */
    public void restart() throws IOException, InterruptedException {
        throw new UnsupportedOperationException();
    }

    /**
     * Can the {@link #restart()} method restart Hudson?
     *
     * @throws RestartNotSupportedException
     *      If the restart is not supported, throw this exception and explain the cause.
     */
    public void verifyRestartable() throws RestartNotSupportedException {
        // the rewriteHudsonWar method isn't overridden.
        if (!Util.isOverridden(Lifecycle.class, getClass(), "restart"))
            throw new RestartNotSupportedException("Restart is not supported in this running mode (" +
                    getClass().getName() + ").");
    }

    /**
     * The same as {@link #verifyRestartable()} except the status is indicated by the return value,
     * not by an exception.
     */
    public boolean canRestart() {
        try {
            verifyRestartable();
            return true;
        } catch (RestartNotSupportedException e) {
            return false;
        }
    }

    /**
     * Called when Jenkins startup is finished or when Jenkins has finished reloading its
     * configuration.
     *
     * @since 2.333
     */
    public void onReady() {
        LOGGER.log(Level.INFO, "Jenkins is fully up and running");
    }

    /**
     * Called when Jenkins is reloading its configuration.
     *
     * <p>Callers must also send an {@link #onReady()} notification when Jenkins has finished
     * reloading its configuration.
     *
     * @since 2.333
     */
    public void onReload(@NonNull String user, @CheckForNull String remoteAddr) {
        if (remoteAddr != null) {
            LOGGER.log(
                    Level.INFO,
                    "Reloading Jenkins as requested by {0} from {1}",
                    new Object[] {user, remoteAddr});
        } else {
            LOGGER.log(Level.INFO, "Reloading Jenkins as requested by {0}", user);
        }
    }

    /**
     * Called when Jenkins is beginning its shutdown.
     *
     * @since 2.333
     */
    public void onStop(@NonNull String user, @CheckForNull String remoteAddr) {
        if (remoteAddr != null) {
            LOGGER.log(
                    Level.INFO,
                    "Stopping Jenkins as requested by {0} from {1}",
                    new Object[] {user, remoteAddr});
        } else {
            LOGGER.log(Level.INFO, "Stopping Jenkins as requested by {0}", user);
        }
    }

    /**
     * Tell the service manager to extend the startup or shutdown timeout. The value specified is a
     * time during which either {@link #onExtendTimeout(long, TimeUnit)} must be called again or
     * startup/shutdown must complete.
     *
     * @param timeout The amount by which to extend the timeout.
     * @param unit The time unit of the timeout argument.
     *
     * @since 2.335
     */
    public void onExtendTimeout(long timeout, @NonNull TimeUnit unit) {}

    /**
     * Called when Jenkins service state has changed.
     *
     * @param status The status string. This is free-form and can be used for various purposes:
     *     general state feedback, completion percentages, human-readable error message, etc.
     *
     * @since 2.333
     */
    public void onStatusUpdate(String status) {
        LOGGER.log(Level.INFO, status);
    }

    /**
     * Whether {@link PluginManager#dynamicLoad(File)} should be supported at all.
     * If not, {@link RestartRequiredException} will always be thrown.
     * @return true by default
     * @since 2.449
     */
    @Restricted(Beta.class)
    public boolean supportsDynamicLoad() {
        return true;
    }

    /**
     * Called when Jenkins has failed to boot.
     * @param problem a boot failure (could be {@link JenkinsReloadFailed})
     * @since 2.469
     */
    public void onBootFailure(BootFailure problem) {
    }

    @Restricted(NoExternalUse.class)
    public static final class PlaceholderLifecycle extends ExitLifecycle {

        @Initializer(after = InitMilestone.PLUGINS_STARTED, before = InitMilestone.EXTENSIONS_AUGMENTED)
        public static synchronized void replacePlaceholder() {
            if (get() instanceof PlaceholderLifecycle) {
                String p = SystemProperties.getString("hudson.lifecycle");
                try {
                    INSTANCE = (Lifecycle) Jenkins.get().getPluginManager().uberClassLoader.loadClass(p).getConstructor().newInstance();
                    LOGGER.fine(() -> "Updated to " + INSTANCE);
                } catch (Exception | LinkageError x) {
                    LOGGER.log(Level.WARNING, x, () -> "Failed to load " + p + "; using fallback exit lifecycle");
                }
            }
        }

    }

    private static final Logger LOGGER = Logger.getLogger(Lifecycle.class.getName());
}