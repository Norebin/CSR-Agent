class OffsetFetcherUtils {
    private final ConsumerMetadata metadata;
    private final SubscriptionState subscriptionState;
    private final Time time;
    private final long retryBackoffMs;
    private final ApiVersions apiVersions;
    private final PositionsValidator positionsValidator;
    private final Logger log;

    /**
     * Exception that occurred while resetting positions, that will be propagated on the next
     * call to reset positions. This will have the error received in the response to the
     * ListOffsets request. It will be cleared when thrown on the next call to reset.
     */
    private final AtomicReference<RuntimeException> cachedResetPositionsException = new AtomicReference<>();

    OffsetFetcherUtils(LogContext logContext,
                       ConsumerMetadata metadata,
                       SubscriptionState subscriptionState,
                       Time time,
                       long retryBackoffMs,
                       ApiVersions apiVersions) {
        this(logContext, metadata, subscriptionState,
            time, retryBackoffMs, apiVersions,
            new PositionsValidator(logContext, time, subscriptionState, metadata));
    }

    OffsetFetcherUtils(LogContext logContext,
                       ConsumerMetadata metadata,
                       SubscriptionState subscriptionState,
                       Time time,
                       long retryBackoffMs,
                       ApiVersions apiVersions,
                       PositionsValidator positionsValidator) {
        this.log = logContext.logger(getClass());
        this.metadata = metadata;
        this.subscriptionState = subscriptionState;
        this.time = time;
        this.retryBackoffMs = retryBackoffMs;
        this.apiVersions = apiVersions;
        this.positionsValidator = positionsValidator;
    }

    /**
     * Callback for the response of the list offset call.
     *
     * @param listOffsetsResponse The response from the server.
     * @return {@link OffsetFetcherUtils.ListOffsetResult} extracted from the response, containing the fetched offsets
     * and partitions to retry.
     */
    OffsetFetcherUtils.ListOffsetResult handleListOffsetResponse(ListOffsetsResponse listOffsetsResponse) {
        Map<TopicPartition, OffsetFetcherUtils.ListOffsetData> fetchedOffsets = new HashMap<>();
        Set<TopicPartition> partitionsToRetry = new HashSet<>();
        Set<String> unauthorizedTopics = new HashSet<>();

        for (ListOffsetsResponseData.ListOffsetsTopicResponse topic : listOffsetsResponse.topics()) {
            for (ListOffsetsResponseData.ListOffsetsPartitionResponse partition : topic.partitions()) {
                TopicPartition topicPartition = new TopicPartition(topic.name(), partition.partitionIndex());
                Errors error = Errors.forCode(partition.errorCode());
                switch (error) {
                    case NONE:
                        log.debug("Handling ListOffsetResponse response for {}. Fetched offset {}, timestamp {}",
                                topicPartition, partition.offset(), partition.timestamp());
                        if (partition.offset() != ListOffsetsResponse.UNKNOWN_OFFSET) {
                            Optional<Integer> leaderEpoch = (partition.leaderEpoch() == ListOffsetsResponse.UNKNOWN_EPOCH)
                                    ? Optional.empty()
                                    : Optional.of(partition.leaderEpoch());
                            OffsetFetcherUtils.ListOffsetData offsetData = new OffsetFetcherUtils.ListOffsetData(partition.offset(), partition.timestamp(),
                                    leaderEpoch);
                            fetchedOffsets.put(topicPartition, offsetData);
                        }
                        break;
                    case UNSUPPORTED_FOR_MESSAGE_FORMAT:
                        // The message format on the broker side is before 0.10.0, which means it does not
                        // support timestamps. We treat this case the same as if we weren't able to find an
                        // offset corresponding to the requested timestamp and leave it out of the result.
                        log.debug("Cannot search by timestamp for partition {} because the message format version " +
                                "is before 0.10.0", topicPartition);
                        break;
                    case NOT_LEADER_OR_FOLLOWER:
                    case REPLICA_NOT_AVAILABLE:
                    case KAFKA_STORAGE_ERROR:
                    case OFFSET_NOT_AVAILABLE:
                    case LEADER_NOT_AVAILABLE:
                    case FENCED_LEADER_EPOCH:
                    case UNKNOWN_LEADER_EPOCH:
                        log.debug("Attempt to fetch offsets for partition {} failed due to {}, retrying.",
                                topicPartition, error);
                        partitionsToRetry.add(topicPartition);
                        break;
                    case UNKNOWN_TOPIC_OR_PARTITION:
                        log.warn("Received unknown topic or partition error in ListOffset request for partition {}", topicPartition);
                        partitionsToRetry.add(topicPartition);
                        break;
                    case TOPIC_AUTHORIZATION_FAILED:
                        unauthorizedTopics.add(topicPartition.topic());
                        break;
                    default:
                        log.warn("Attempt to fetch offsets for partition {} failed due to unexpected exception: {}, retrying.",
                                topicPartition, error.message());
                        partitionsToRetry.add(topicPartition);
                }
            }
        }

        if (!unauthorizedTopics.isEmpty())
            throw new TopicAuthorizationException(unauthorizedTopics);
        else
            return new OffsetFetcherUtils.ListOffsetResult(fetchedOffsets, partitionsToRetry);
    }

    <T> Map<Node, Map<TopicPartition, T>> regroupPartitionMapByNode(
            Map<TopicPartition, T> partitionMap,
            Set<TopicPartition> partitionsToRetry) {
        Map<Node, Map<TopicPartition, T>> partitionsByNode = new HashMap<>();

        final var cluster = metadata.fetch();

        partitionMap.forEach((tp, value) -> {
            Node leader = cluster.leaderFor(tp);
            if (leader == null) {
                log.debug("Leader for partition {} is unknown while regrouping partition map by node", tp);
                partitionsToRetry.add(tp);
                return;
            }
            partitionsByNode.computeIfAbsent(leader, __ -> new HashMap<>())
                .put(tp, value);
        });

        return partitionsByNode;
    }

    Map<TopicPartition, SubscriptionState.FetchPosition> refreshAndGetPartitionsToValidate() {
        return positionsValidator.refreshAndGetPartitionsToValidate(apiVersions);
    }

    /**
     * If we have seen new metadata (as tracked by {@link org.apache.kafka.clients.Metadata#updateVersion()}), then
     * we should check that all the assignments have a valid position.
     */
    void validatePositionsOnMetadataChange() {
        positionsValidator.validatePositionsOnMetadataChange(apiVersions);
    }

    /**
     * get OffsetResetStrategy for all assigned partitions
     */
    Map<TopicPartition, AutoOffsetResetStrategy> getOffsetResetStrategyForPartitions() {
        return new PositionResetter(log, metadata, subscriptionState, time, retryBackoffMs, cachedResetPositionsException)
            .getOffsetResetStrategyForPartitions();
    }
    static Map<TopicPartition, OffsetAndTimestamp> buildListOffsetsResult(
        final Map<TopicPartition, Long> timestampsToSearch,
        final Map<TopicPartition, ListOffsetData> fetchedOffsets,
        BiFunction<TopicPartition, ListOffsetData, OffsetAndTimestamp> resultMapper) {

        HashMap<TopicPartition, OffsetAndTimestamp> offsetsResults = new HashMap<>(timestampsToSearch.size());
        for (Map.Entry<TopicPartition, Long> entry : timestampsToSearch.entrySet())
            offsetsResults.put(entry.getKey(), null);

        for (Map.Entry<TopicPartition, ListOffsetData> entry : fetchedOffsets.entrySet()) {
            ListOffsetData offsetData = entry.getValue();
            offsetsResults.put(entry.getKey(), resultMapper.apply(entry.getKey(), offsetData));
        }

        return offsetsResults;
    }

    static Map<TopicPartition, OffsetAndTimestamp> buildOffsetsForTimesResult(
        final Map<TopicPartition, Long> timestampsToSearch,
        final Map<TopicPartition, ListOffsetData> fetchedOffsets) {
        return buildListOffsetsResult(timestampsToSearch, fetchedOffsets,
            (topicPartition, offsetData) -> new OffsetAndTimestamp(
                offsetData.offset,
                offsetData.timestamp,
                offsetData.leaderEpoch));
    }

    static Map<TopicPartition, OffsetAndTimestampInternal> buildOffsetsForTimeInternalResult(
            final Map<TopicPartition, Long> timestampsToSearch,
            final Map<TopicPartition, ListOffsetData> fetchedOffsets) {
        HashMap<TopicPartition, OffsetAndTimestampInternal> offsetsResults = new HashMap<>(timestampsToSearch.size());
        for (Map.Entry<TopicPartition, Long> entry : timestampsToSearch.entrySet()) {
            offsetsResults.put(entry.getKey(), null);
        }
        for (Map.Entry<TopicPartition, ListOffsetData> entry : fetchedOffsets.entrySet()) {
            ListOffsetData offsetData = entry.getValue();
            offsetsResults.put(entry.getKey(), new OffsetAndTimestampInternal(
                    offsetData.offset,
                    offsetData.timestamp,
                    offsetData.leaderEpoch));
        }
        return offsetsResults;
    }

    private AutoOffsetResetStrategy offsetResetStrategyWithValidTimestamp(final TopicPartition partition) {
        AutoOffsetResetStrategy strategy = subscriptionState.resetStrategy(partition);
        if (strategy.timestamp().isPresent()) {
            return strategy;
        } else {
            throw new NoOffsetForPartitionException(partition);
        }
    }

    static Set<String> topicsForPartitions(Collection<TopicPartition> partitions) {
        return partitions.stream().map(TopicPartition::topic).collect(Collectors.toSet());
    }

    void updateSubscriptionState(Map<TopicPartition, OffsetFetcherUtils.ListOffsetData> fetchedOffsets,
                                 IsolationLevel isolationLevel) {
        for (final Map.Entry<TopicPartition, ListOffsetData> entry : fetchedOffsets.entrySet()) {
            final TopicPartition partition = entry.getKey();

            // if the interested partitions are part of the subscriptions, use the returned offset to update
            // the subscription state as well:
            //   * with read-committed, the returned offset would be LSO;
            //   * with read-uncommitted, the returned offset would be HW;
            if (subscriptionState.isAssigned(partition)) {
                final long offset = entry.getValue().offset;
                if (isolationLevel == IsolationLevel.READ_COMMITTED) {
                    log.trace("Updating last stable offset for partition {} to {}", partition, offset);
                    subscriptionState.updateLastStableOffset(partition, offset);
                } else {
                    log.trace("Updating high watermark for partition {} to {}", partition, offset);
                    subscriptionState.updateHighWatermark(partition, offset);
                }
            } else {
                if (isolationLevel == IsolationLevel.READ_COMMITTED) {
                    log.debug("Not updating last stable offset for partition {} as it is no longer assigned", partition);
                } else {
                    log.debug("Not updating high watermark for partition {} as it is no longer assigned", partition);
                }
            }
        }
    }

    /**
     * The {@code LIST_OFFSETS} lag lookup is serialized, so if there's an inflight request it must finish before
     * another request can be issued. This serialization mechanism is controlled by the 'end offset requested'
     * flag in {@link SubscriptionState}.
     *
     * @return {@code true} if the partition's end offset can be requested, {@code false} if there's already an
     *         in-flight request
     */
    boolean maybeSetPartitionEndOffsetRequest(TopicPartition partition) {
        if (subscriptionState.partitionEndOffsetRequested(partition)) {
            log.info("Not requesting the log end offset for {} to compute lag as an outstanding request already exists", partition);
            return false;
        } else {
            log.info("Requesting the log end offset for {} in order to compute lag", partition);
            subscriptionState.requestPartitionEndOffset(partition);
            return true;
        }
    }

    /**
     * If any of the given partitions are assigned, this will clear the partition's 'end offset requested' flag so
     * that the next attempt to look up the lag will properly issue another <code>LIST_OFFSETS</code> request. This
     * is only intended to be called when <code>LIST_OFFSETS</code> fails. Successful <code>LIST_OFFSETS</code> calls
     * should use {@link #updateSubscriptionState(Map, IsolationLevel)}.
     *
     * @param partitions Partitions for which the 'end offset requested' flag should be cleared (if still assigned)
     */
    void clearPartitionEndOffsetRequests(Collection<TopicPartition> partitions) {
        for (final TopicPartition partition : partitions) {
            if (subscriptionState.maybeClearPartitionEndOffsetRequested(partition)) {
                log.trace("Clearing end offset requested for partition {}", partition);
            }
        }
    }

    void onSuccessfulResponseForResettingPositions(
            final ListOffsetResult result,
            final Map<TopicPartition, AutoOffsetResetStrategy> partitionAutoOffsetResetStrategyMap) {
        new PositionResetter(log, metadata, subscriptionState, time, retryBackoffMs, cachedResetPositionsException)
            .onSuccessfulResponse(result, partitionAutoOffsetResetStrategyMap);
    }
    void onFailedResponseForResettingPositions(
            final Map<TopicPartition, ListOffsetsRequestData.ListOffsetsPartition> resetTimestamps,
            final RuntimeException error) {
        new PositionResetter(log, metadata, subscriptionState, time, retryBackoffMs, cachedResetPositionsException)
            .onFailedResponse(resetTimestamps, error);
    }

    void onSuccessfulResponseForValidatingPositions(
            final Map<TopicPartition, SubscriptionState.FetchPosition> fetchPositions,
            final OffsetsForLeaderEpochUtils.OffsetForEpochResult offsetsResult) {
        List<SubscriptionState.LogTruncation> truncations = new ArrayList<>();
        if (!offsetsResult.partitionsToRetry().isEmpty()) {
            subscriptionState.setNextAllowedRetry(offsetsResult.partitionsToRetry(),
                    time.milliseconds() + retryBackoffMs);
            metadata.requestUpdate(false);
        }

        // For each OffsetsForLeader response, check if the end-offset is lower than our current offset
        // for the partition. If so, it means we have experienced log truncation and need to reposition
        // that partition's offset.
        // In addition, check whether the returned offset and epoch are valid. If not, then we should reset
        // its offset if reset policy is configured, or throw out of range exception.
        offsetsResult.endOffsets().forEach((topicPartition, respEndOffset) -> {
            SubscriptionState.FetchPosition requestPosition = fetchPositions.get(topicPartition);
            Optional<SubscriptionState.LogTruncation> truncationOpt =
                    subscriptionState.maybeCompleteValidation(topicPartition, requestPosition,
                            respEndOffset);
            truncationOpt.ifPresent(truncations::add);
        });

        if (!truncations.isEmpty()) {
            positionsValidator.maybeSetError(buildLogTruncationException(truncations));
        }
    }

    void onFailedResponseForValidatingPositions(final Map<TopicPartition, SubscriptionState.FetchPosition> fetchPositions,
                                                final RuntimeException error) {
        subscriptionState.requestFailed(fetchPositions.keySet(), time.milliseconds() + retryBackoffMs);
        metadata.requestUpdate(false);

        if (!(error instanceof RetriableException)) {
            positionsValidator.maybeSetError(error);
        }
    }

    private LogTruncationException buildLogTruncationException(List<SubscriptionState.LogTruncation> truncations) {
        Map<TopicPartition, OffsetAndMetadata> divergentOffsets = new HashMap<>();
        Map<TopicPartition, Long> truncatedFetchOffsets = new HashMap<>();
        for (SubscriptionState.LogTruncation truncation : truncations) {
            truncation.divergentOffsetOpt.ifPresent(divergentOffset ->
                    divergentOffsets.put(truncation.topicPartition, divergentOffset));
            truncatedFetchOffsets.put(truncation.topicPartition, truncation.fetchPosition.offset);
        }
        return new LogTruncationException(truncatedFetchOffsets, divergentOffsets);
    }

    // Visible for testing
    void resetPositionIfNeeded(TopicPartition partition, AutoOffsetResetStrategy requestedResetStrategy,
                               ListOffsetData offsetData) {
        SubscriptionState.FetchPosition position = new SubscriptionState.FetchPosition(
                offsetData.offset,
                Optional.empty(), // This will ensure we skip validation
                metadata.currentLeader(partition));
        offsetData.leaderEpoch.ifPresent(epoch -> metadata.updateLastSeenEpochIfNewer(partition, epoch));
        subscriptionState.maybeSeekUnvalidated(partition, position, requestedResetStrategy);
    }

    static Map<Node, Map<TopicPartition, SubscriptionState.FetchPosition>> regroupFetchPositionsByLeader(
            Map<TopicPartition, SubscriptionState.FetchPosition> partitionMap) {
        return partitionMap.entrySet()
                .stream()
                .filter(entry -> entry.getValue().currentLeader.leader.isPresent())
                .collect(Collectors.groupingBy(entry -> entry.getValue().currentLeader.leader.get(),
                        Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)));
    }

    static boolean hasUsableOffsetForLeaderEpochVersion(NodeApiVersions nodeApiVersions) {
        ApiVersionsResponseData.ApiVersion apiVersion = nodeApiVersions.apiVersion(ApiKeys.OFFSET_FOR_LEADER_EPOCH);
        if (apiVersion == null)
            return false;

        return OffsetsForLeaderEpochRequest.supportsTopicPermission(apiVersion.maxVersion());
    }

    static class ListOffsetResult {
        final Map<TopicPartition, OffsetFetcherUtils.ListOffsetData> fetchedOffsets;
        final Set<TopicPartition> partitionsToRetry;

        ListOffsetResult(Map<TopicPartition, OffsetFetcherUtils.ListOffsetData> fetchedOffsets,
                         Set<TopicPartition> partitionsNeedingRetry) {
            this.fetchedOffsets = fetchedOffsets;
            this.partitionsToRetry = partitionsNeedingRetry;
        }

        ListOffsetResult() {
            this.fetchedOffsets = new HashMap<>();
            this.partitionsToRetry = new HashSet<>();
        }
    }

    /**
     * Represents data about an offset returned by a broker.
     */
    static class ListOffsetData {
        final long offset;
        final Long timestamp; //  null if the broker does not support returning timestamps
        final Optional<Integer> leaderEpoch; // empty if the leader epoch is not known

        ListOffsetData(long offset, Long timestamp, Optional<Integer> leaderEpoch) {
            this.offset = offset;
            this.timestamp = timestamp;
            this.leaderEpoch = leaderEpoch;
        }
    }
}