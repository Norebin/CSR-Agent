public class IssuedTokenInterceptorProvider extends AbstractPolicyInterceptorProvider {
    
    private static final Logger LOG = LogUtils.getL7dLogger(IssuedTokenInterceptorProvider.class);
    
    private static final long serialVersionUID = -6936475570762840527L;
    private static final String ASSOCIATED_TOKEN = 
        IssuedTokenInterceptorProvider.class.getName() + "-" + "Associated_Token";

    public IssuedTokenInterceptorProvider() {
        super(Arrays.asList(SP11Constants.ISSUED_TOKEN, SP12Constants.ISSUED_TOKEN));
        
        //issued tokens can be attached as a supporting token without
        //any type of binding.  Make sure we can support that.
        this.getOutInterceptors().add(PolicyBasedWSS4JOutInterceptor.INSTANCE);
        this.getOutFaultInterceptors().add(PolicyBasedWSS4JOutInterceptor.INSTANCE);
        this.getInInterceptors().add(PolicyBasedWSS4JInInterceptor.INSTANCE);
        this.getInFaultInterceptors().add(PolicyBasedWSS4JInInterceptor.INSTANCE);
        
        this.getOutInterceptors().add(new IssuedTokenOutInterceptor());
        this.getOutFaultInterceptors().add(new IssuedTokenOutInterceptor());
        this.getInInterceptors().add(new IssuedTokenInInterceptor());
        this.getInFaultInterceptors().add(new IssuedTokenInInterceptor());
        
        this.getOutInterceptors().add(PolicyBasedWSS4JStaxOutInterceptor.INSTANCE);
        this.getOutFaultInterceptors().add(PolicyBasedWSS4JStaxOutInterceptor.INSTANCE);
        this.getInInterceptors().add(PolicyBasedWSS4JStaxInInterceptor.INSTANCE);
        this.getInFaultInterceptors().add(PolicyBasedWSS4JStaxInInterceptor.INSTANCE);
    }
    
    protected static void assertIssuedToken(IssuedToken issuedToken, AssertionInfoMap aim) {
        if (issuedToken == null) {
            return;
        }
        // Assert some policies
        if (issuedToken.isRequireExternalReference()) {
            assertPolicy(new QName(issuedToken.getName().getNamespaceURI(), 
                                   SPConstants.REQUIRE_EXTERNAL_REFERENCE), aim);
        }
        if (issuedToken.isRequireInternalReference()) {
            assertPolicy(new QName(issuedToken.getName().getNamespaceURI(), 
                                   SPConstants.REQUIRE_INTERNAL_REFERENCE), aim);
        }
    }
    
    protected static void assertPolicy(QName n, AssertionInfoMap aim) {
        Collection<AssertionInfo> ais = aim.getAssertionInfo(n);
        if (ais != null && !ais.isEmpty()) {
            for (AssertionInfo ai : ais) {
                ai.setAsserted(true);
            }
        }
    }
    
    static class IssuedTokenOutInterceptor extends AbstractPhaseInterceptor<Message> {
        public IssuedTokenOutInterceptor() {
            super(Phase.PREPARE_SEND);
        }    
        private static void mapSecurityProps(Message message, Map<String, Object> ctx) {
            for (String s : SecurityConstants.ALL_PROPERTIES) {
                Object v = message.getContextualProperty(s + ".it");
                if (v == null) {
                    v = message.getContextualProperty(s);
                }
                if (!ctx.containsKey(s) && v != null) {
                    ctx.put(s, v);
                }
            }
        }
        public void handleMessage(Message message) throws Fault {
            AssertionInfoMap aim = message.get(AssertionInfoMap.class);
            // extract Assertion information
            
            if (aim != null) {
                Collection<AssertionInfo> ais = 
                    PolicyUtils.getAllAssertionsByLocalname(aim, SPConstants.ISSUED_TOKEN);
                if (ais.isEmpty()) {
                    return;
                }
                if (isRequestor(message)) {
                    IssuedToken itok = (IssuedToken)ais.iterator().next().getAssertion();
                    assertIssuedToken(itok, aim);
                    
                    SecurityToken tok = retrieveCachedToken(message);
                    if (tok == null) {
                        tok = issueToken(message, aim, itok);
                    } else {
                        tok = renewToken(message, aim, itok, tok);
                    }
                    if (tok != null) {
                        for (AssertionInfo ai : ais) {
                            ai.setAsserted(true);
                        }
                        boolean cacheIssuedToken = 
                            MessageUtils.getContextualBoolean(
                                message, SecurityConstants.CACHE_ISSUED_TOKEN_IN_ENDPOINT, true
                            ) && !isOneTimeUse(tok);
                        if (cacheIssuedToken) {
                            message.getExchange().get(Endpoint.class).put(SecurityConstants.TOKEN, tok);
                            message.getExchange().put(SecurityConstants.TOKEN, tok);
                            message.getExchange().put(SecurityConstants.TOKEN_ID, tok.getId());
                            message.getExchange().get(Endpoint.class).put(SecurityConstants.TOKEN_ID, 
                                                                          tok.getId());
                        } else {
                            message.put(SecurityConstants.TOKEN, tok);
                            message.put(SecurityConstants.TOKEN_ID, tok.getId());
                        }
                        WSS4JUtils.getTokenStore(message).add(tok);
                    }
                } else {
                    //server side should be checked on the way in
                    for (AssertionInfo ai : ais) {
                        ai.setAsserted(true);
                    }
                    IssuedToken itok = (IssuedToken)ais.iterator().next().getAssertion();
                    assertIssuedToken(itok, aim);
                }
            }
        }
        
        private Trust10 getTrust10(AssertionInfoMap aim) {
            Collection<AssertionInfo> ais = 
                PolicyUtils.getAllAssertionsByLocalname(aim, SPConstants.TRUST_10);
            if (ais.isEmpty()) {
                return null;
            }
            return (Trust10)ais.iterator().next().getAssertion();
        }
        private Trust13 getTrust13(AssertionInfoMap aim) {
            Collection<AssertionInfo> ais = 
                PolicyUtils.getAllAssertionsByLocalname(aim, SPConstants.TRUST_13);
            if (ais.isEmpty()) {
                return null;
            }
            return (Trust13)ais.iterator().next().getAssertion();
        }
        
        // Check to see if the received token is a SAML2 Token with "OneTimeUse" set. If so,
        // it should not be cached on the endpoint, but only on the message.
        private boolean isOneTimeUse(SecurityToken issuedToken) {
            Element token = issuedToken.getToken();
            if (token != null && "Assertion".equals(token.getLocalName())
                && WSConstants.SAML2_NS.equals(token.getNamespaceURI())) {
                try {
                    SamlAssertionWrapper assertion = new SamlAssertionWrapper(token);
                    
                    if (assertion.getSaml2().getConditions() != null
                        && assertion.getSaml2().getConditions().getOneTimeUse() != null) {
                        return true;
                    }
                } catch (WSSecurityException ex) {
                    throw new Fault(ex);
                }
            }
            
            return false;
        }
        
        private SecurityToken retrieveCachedToken(Message message) {
            boolean cacheIssuedToken = 
                MessageUtils.getContextualBoolean(
                    message, SecurityConstants.CACHE_ISSUED_TOKEN_IN_ENDPOINT, true
                );
            SecurityToken tok = null;
            if (cacheIssuedToken) {
                tok = (SecurityToken)message.getContextualProperty(SecurityConstants.TOKEN);
                if (tok == null) {
                    String tokId = (String)message.getContextualProperty(SecurityConstants.TOKEN_ID);
                    if (tokId != null) {
                        tok = WSS4JUtils.getTokenStore(message).getToken(tokId);
                    }
                }
            } else {
                tok = (SecurityToken)message.get(SecurityConstants.TOKEN);
                if (tok == null) {
                    String tokId = (String)message.get(SecurityConstants.TOKEN_ID);
                    if (tokId != null) {
                        tok = WSS4JUtils.getTokenStore(message).getToken(tokId);
                    }
                }
            }
            return tok;
        }
        
        /**
         * Parse ActAs/OnBehalfOf appropriately. See if the required token is stored in the cache.
         */
        private SecurityToken handleDelegation(
            Message message, 
            Element onBehalfOfToken,
            Element actAsToken,
            String appliesTo,
            boolean enableAppliesTo
        ) throws Exception {
            DelegationTokenHandler handler = new DelegationTokenHandler(message, ASSOCIATED_TOKEN);
            return handler.handleDelegation(onBehalfOfToken, actAsToken, appliesTo, enableAppliesTo);
        }        
        private String getIdFromToken(Element token) {
            if (token != null) {
                // Try to find the "Id" on the token.
                if (token.hasAttributeNS(WSConstants.WSU_NS, "Id")) {
                    return token.getAttributeNS(WSConstants.WSU_NS, "Id");
                } else if (token.hasAttributeNS(null, "ID")) {
                    return token.getAttributeNS(null, "ID");
                } else if (token.hasAttributeNS(null, "AssertionID")) {
                    return token.getAttributeNS(null, "AssertionID");
                }
            }
            return "";
        }
        
        private void storeDelegationTokens(
            Message message,
            SecurityToken issuedToken,
            Element onBehalfOfToken,
            Element actAsToken,
            String appliesTo,
            boolean enableAppliesTo
        ) throws Exception {
            DelegationTokenHandler handler = new DelegationTokenHandler(message, ASSOCIATED_TOKEN);
            handler.storeDelegationTokens(
                issuedToken, onBehalfOfToken, actAsToken, appliesTo, enableAppliesTo
            );
        }        
        private SecurityToken getTokenFromSTS(
            Message message,
            STSClient client,
            AssertionInfoMap aim,
            AddressingProperties maps,
            IssuedToken itok,
            String appliesTo
        ) throws Exception {
            client.setTrust(getTrust10(aim));
            client.setTrust(getTrust13(aim));
            client.setTemplate(itok.getRequestSecurityTokenTemplate());
            if (itok.getPolicy() != null && itok.getPolicy().getNamespace() != null) {
                client.setWspNamespace(itok.getPolicy().getNamespace());
            }
            if (maps != null && maps.getNamespaceURI() != null) {
                client.setAddressingNamespace(maps.getNamespaceURI());
            }
            if (itok.getClaims() != null) {
                client.setClaims(itok.getClaims());
            }
            return client.requestSecurityToken(appliesTo);
        }
        
        private SecurityToken renewToken(
            Message message, 
            AssertionInfoMap aim,
            IssuedToken itok,
            SecurityToken tok
        ) {
            String imminentExpiryValue = 
                (String)message.getContextualProperty(SecurityConstants.STS_TOKEN_IMMINENT_EXPIRY_VALUE);
            long imminentExpiry = 10L;
            if (imminentExpiryValue != null) {
                imminentExpiry = Long.parseLong(imminentExpiryValue);
            }
            
            // If the token has not expired then we don't need to renew it
            if (!(tok.isExpired() || tok.isAboutToExpire(imminentExpiry))) {
                return tok;
            }
            
            // Remove token from cache
            message.getExchange().get(Endpoint.class).remove(SecurityConstants.TOKEN);
            message.getExchange().get(Endpoint.class).remove(SecurityConstants.TOKEN_ID);
            message.getExchange().remove(SecurityConstants.TOKEN_ID);
            message.getExchange().remove(SecurityConstants.TOKEN);
            NegotiationUtils.getTokenStore(message).remove(tok.getId());
            
            // If the user has explicitly disabled Renewing then we can't renew a token,
            // so just get a new one
            STSClient client = STSUtils.getClient(message, "sts", itok);
            if (!client.isAllowRenewing()) {
                return issueToken(message, aim, itok);
            }
            
            AddressingProperties maps =
                (AddressingProperties)message
                    .get("javax.xml.ws.addressing.context.outbound");
            if (maps == null) {
                maps = (AddressingProperties)message
                    .get("javax.xml.ws.addressing.context");
            }
            synchronized (client) {
                try {
                    Map<String, Object> ctx = client.getRequestContext();
                    mapSecurityProps(message, ctx);
                
                    client.setMessage(message);

                    if (maps != null && maps.getNamespaceURI() != null) {
                        client.setAddressingNamespace(maps.getNamespaceURI());
                    }
                    
                    client.setTrust(getTrust10(aim));
                    client.setTrust(getTrust13(aim));
                    
                    client.setTemplate(itok.getRequestSecurityTokenTemplate());
                    return client.renewSecurityToken(tok);
                } catch (RuntimeException ex) {
                    LOG.log(Level.WARNING, "Error renewing a token", ex);
                    boolean issueAfterFailedRenew = 
                        MessageUtils.getContextualBoolean(
                            message, SecurityConstants.STS_ISSUE_AFTER_FAILED_RENEW, true
                        );
                    if (issueAfterFailedRenew) {
                        // Perhaps the STS does not support renewing, so try to issue a new token
                        return issueToken(message, aim, itok);
                    } else {
                        throw ex;
                    }
                } catch (Exception ex) {
                    LOG.log(Level.WARNING, "Error renewing a token", ex);
                    boolean issueAfterFailedRenew = 
                        MessageUtils.getContextualBoolean(
                            message, SecurityConstants.STS_ISSUE_AFTER_FAILED_RENEW, true
                        );
                    if (issueAfterFailedRenew) {
                        // Perhaps the STS does not support renewing, so try to issue a new token
                        return issueToken(message, aim, itok);
                    } else {
                        throw new Fault(ex);
                    }
                }
            }
        }
        
        private SecurityToken issueToken(
             Message message, 
             AssertionInfoMap aim,
             IssuedToken itok
        ) {
            STSClient client = STSUtils.getClient(message, "sts", itok);
            AddressingProperties maps =
                (AddressingProperties)message
                    .get("javax.xml.ws.addressing.context.outbound");
            if (maps == null) {
                maps = (AddressingProperties)message
                    .get("javax.xml.ws.addressing.context");
            }
            synchronized (client) {
                try {
                    // Transpose ActAs/OnBehalfOf info from original request to the STS client.
                    Object token = 
                        message.getContextualProperty(SecurityConstants.STS_TOKEN_ACT_AS);
                    if (token != null) {
                        client.setActAs(token);
                    }
                    token = 
                        message.getContextualProperty(SecurityConstants.STS_TOKEN_ON_BEHALF_OF);
                    if (token != null) {
                        client.setOnBehalfOf(token);
                    }
                    Map<String, Object> ctx = client.getRequestContext();
                    mapSecurityProps(message, ctx);
                
                    Object o = message.getContextualProperty(SecurityConstants.STS_APPLIES_TO);
                    String appliesTo = o == null ? null : o.toString();
                    appliesTo = appliesTo == null 
                        ? message.getContextualProperty(Message.ENDPOINT_ADDRESS).toString()
                            : appliesTo;
                    boolean enableAppliesTo = client.isEnableAppliesTo();
                    
                    client.setMessage(message);
                    Element onBehalfOfToken = client.getOnBehalfOfToken();
                    Element actAsToken = client.getActAsToken();
                    
                    SecurityToken secToken = 
                        handleDelegation(
                            message, onBehalfOfToken, actAsToken, appliesTo, enableAppliesTo
                        );
                    if (secToken == null) {
                        secToken = getTokenFromSTS(message, client, aim, maps, itok, appliesTo);
                    }
                    storeDelegationTokens(
                        message, secToken, onBehalfOfToken, actAsToken, appliesTo, enableAppliesTo
                    );
                    return secToken;
                } catch (RuntimeException e) {
                    throw e;
                } catch (Exception e) {
                    throw new Fault(e);
                }
            }
        }
        
    }
    
    static class IssuedTokenInInterceptor extends AbstractPhaseInterceptor<Message> {
        public IssuedTokenInInterceptor() {
            super(Phase.PRE_PROTOCOL);
            addAfter(WSS4JInInterceptor.class.getName());
            addAfter(PolicyBasedWSS4JInInterceptor.class.getName());
        }

        public void handleMessage(Message message) throws Fault {
            AssertionInfoMap aim = message.get(AssertionInfoMap.class);
            // extract Assertion information
            if (aim != null) {
                Collection<AssertionInfo> ais = 
                    PolicyUtils.getAllAssertionsByLocalname(aim, SPConstants.ISSUED_TOKEN);
                if (ais.isEmpty()) {
                    return;
                }
                
                IssuedToken itok = (IssuedToken)ais.iterator().next().getAssertion();
                assertIssuedToken(itok, aim);
                
                if (!isRequestor(message)) {
                    message.getExchange().remove(SecurityConstants.TOKEN);
                    List<WSHandlerResult> results = 
                        CastUtils.cast((List<?>)message.get(WSHandlerConstants.RECV_RESULTS));
                    if (results != null && results.size() > 0) {
                        parseHandlerResults(results.get(0), message, ais);
                    }
                } else {
                    for (AssertionInfo ai : ais) {
                        ai.setAsserted(true);
                    }
                }
            }
        }
        
        private void parseHandlerResults(
            WSHandlerResult rResult,
            Message message,
            Collection<AssertionInfo> issuedAis
        ) {
            List<WSSecurityEngineResult> signedResults = 
                WSSecurityUtil.fetchAllActionResults(rResult.getResults(), WSConstants.SIGN);
            
            IssuedTokenPolicyValidator issuedValidator = 
                new IssuedTokenPolicyValidator(signedResults, message);

            for (SamlAssertionWrapper assertionWrapper : findSamlTokenResults(rResult.getResults())) {
                boolean valid = issuedValidator.validatePolicy(issuedAis, assertionWrapper);
                if (valid) {
                    SecurityToken token = createSecurityToken(assertionWrapper);
                    message.getExchange().put(SecurityConstants.TOKEN, token);
                    return;
                }
            }
            for (BinarySecurity binarySecurityToken : findBinarySecurityTokenResults(rResult.getResults())) {
                boolean valid = issuedValidator.validatePolicy(issuedAis, binarySecurityToken);
                if (valid) {
                    SecurityToken token = createSecurityToken(binarySecurityToken);
                    message.getExchange().put(SecurityConstants.TOKEN, token);
                    return;
                }
            }
        }
        
        private List<SamlAssertionWrapper> findSamlTokenResults(
            List<WSSecurityEngineResult> wsSecEngineResults
        ) {
            List<SamlAssertionWrapper> results = new ArrayList<SamlAssertionWrapper>();
            for (WSSecurityEngineResult wser : wsSecEngineResults) {
                Integer actInt = (Integer)wser.get(WSSecurityEngineResult.TAG_ACTION);
                if (actInt.intValue() == WSConstants.ST_SIGNED
                    || actInt.intValue() == WSConstants.ST_UNSIGNED) {
                    results.add((SamlAssertionWrapper)wser.get(WSSecurityEngineResult.TAG_SAML_ASSERTION));
                }
            }
            return results;
        }
        
        private List<BinarySecurity> findBinarySecurityTokenResults(
            List<WSSecurityEngineResult> wsSecEngineResults
        ) {
            List<BinarySecurity> results = new ArrayList<BinarySecurity>();
            for (WSSecurityEngineResult wser : wsSecEngineResults) {
                Integer actInt = (Integer)wser.get(WSSecurityEngineResult.TAG_ACTION);
                if (actInt.intValue() == WSConstants.BST 
                    && Boolean.TRUE.equals(wser.get(WSSecurityEngineResult.TAG_VALIDATED_TOKEN))) {
                    results.add((BinarySecurity)wser.get(WSSecurityEngineResult.TAG_BINARY_SECURITY_TOKEN));
                }
            }
            return results;
        }
        
        private SecurityToken createSecurityToken(
            SamlAssertionWrapper assertionWrapper
        ) {
            SecurityToken token = new SecurityToken(assertionWrapper.getId());

            SAMLKeyInfo subjectKeyInfo = assertionWrapper.getSubjectKeyInfo();
            if (subjectKeyInfo != null) {
                token.setSecret(subjectKeyInfo.getSecret());
                X509Certificate[] certs = subjectKeyInfo.getCerts();
                if (certs != null && certs.length > 0) {
                    token.setX509Certificate(certs[0], null);
                }
            }
            if (assertionWrapper.getSaml1() != null) {
                token.setTokenType(WSConstants.WSS_SAML_TOKEN_TYPE);
            } else if (assertionWrapper.getSaml2() != null) {
                token.setTokenType(WSConstants.WSS_SAML2_TOKEN_TYPE);
            }
            token.setToken(assertionWrapper.getElement());

            return token;
        }
    
        private SecurityToken createSecurityToken(BinarySecurity binarySecurityToken) {
            SecurityToken token = new SecurityToken(binarySecurityToken.getID());
            token.setToken(binarySecurityToken.getElement());
            token.setSecret(binarySecurityToken.getToken());
            token.setTokenType(binarySecurityToken.getValueType());
    
            return token;
        }
        
    }
        
}