public class JSONInput extends SPARQLResult {
    public static ResultSet fromJSON(InputStream input) {
        SPARQLResult r = new JSONInput().process(input, null);
        return r.getResultSet();
    }

    public static boolean booleanFromJSON(InputStream input) {
        SPARQLResult r = new JSONInput().process(input, null);
        return r.getBooleanResult();
    }

    public static SPARQLResult make(InputStream input) {
        return make(input, null);
    }

    public static SPARQLResult make(InputStream input, Model model) {
        return new JSONInput().process(input, model);
    }

    public JSONInput() {}

    public JSONInput(InputStream in) {
        this(in, null);
    }

    // See also XMLInputSAX for design structure.
    public JSONInput(InputStream in, Model model) {
        if ( model == null )
            model = GraphFactory.makeJenaDefaultModel();
        process(in, model);
    }

    Boolean       booleanResult = null; // Valid if rows is null.
    List<Binding> rows          = null;
    List<Var>     vars          = null;

    // TODO Streaming version of JSON Result set processing

    private SPARQLResult process(InputStream in, Model model) {
        parse(in);
        if ( model == null )
            model = GraphFactory.makeJenaDefaultModel();
        if ( rows != null ) {
            QueryIterator qIter = new QueryIterPlainWrapper(rows.iterator());
            ResultSet rs = new ResultSetStream(Var.varNames(vars), model, qIter);
            super.set(rs);
        } else
            super.set(booleanResult);
        return this;
    }

    private void parse(InputStream in) {
        JsonObject obj = JSON.parse(in);

        if ( obj.hasKey(kBoolean) ) {
            checkContains(obj, true, true, kHead, kBoolean);
            booleanResult = obj.get(kBoolean).getAsBoolean().value();
            rows = null;
            return;
        }

        rows = new ArrayList<>(1000);

        checkContains(obj, true, true, kHead, kResults);

        // process head
        if ( !obj.get(kHead).isObject() )
            throw new ResultSetException("Key 'head' must have a JSON object as value: found: " + obj.get(kHead));
        JsonObject head = obj.get(kHead).getAsObject();
        parseHead(head, obj);

        // ---- Results
        JsonObject results = obj.get(kResults).getAsObject();
        parseResults(results);
    }
    private List<Var> parseVars(JsonObject obj) {
        if ( !obj.get(kVars).isArray() )
            throw new ResultSetException("Key 'vars' must be a JSON array");
        JsonArray a = obj.get(kVars).getAsArray();
        Iterator<JsonValue> iter = a.iterator();
        List<Var> vars = new ArrayList<>();
        for ( ; iter.hasNext() ; ) {
            JsonValue v = iter.next();
            if ( !v.isString() )
                throw new ResultSetException("Entries in vars array must be strings");
            Var var = Var.alloc(v.getAsString().value());
            vars.add(var);
        }
        return vars;
    }

    LabelToNode labelMap = SyntaxLabels.createLabelToNode();

    private Node parseOneTerm(JsonObject term) {
        checkContains(term, false, false, kType, kValue, kXmlLang, kDatatype);

        String type = stringOrNull(term, kType);
        String v = stringOrNull(term, kValue);

        if ( kUri.equals(type) ) {
            checkContains(term, false, true, kType, kValue);
            String uri = v;
            Node n = NodeFactory.createURI(v);
            return n;
        }

        if ( kLiteral.equals(type) || kTypedLiteral.equals(type) ) {
            String lang = stringOrNull(term, kXmlLang);
            String dtStr = stringOrNull(term, kDatatype);
            if ( lang != null && dtStr != null )
                throw new ResultSetException("Both language and datatype defined: " + term);
            RDFDatatype dt = TypeMapper.getInstance().getSafeTypeByName(dtStr);
            return NodeFactory.createLiteral(v, lang, dt);
        }

        if ( kBnode.equals(type) )
            return labelMap.get(null, v);

        throw new ResultSetException("Object key not recognized as valid for an RDF term: " + term);
    }

    private static String stringOrNull(JsonObject obj, String key) {
        JsonValue v = obj.get(key);
        if ( v == null )
            return null;
        if ( !v.isString() )
            throw new ResultSetException("Not a string: key: " + key);
        return v.getAsString().value();

    }

    private static void checkContains(JsonObject term, boolean allowUndefinedKeys, boolean requireAllExpectedKeys, String... keys) {
        List<String> expectedKeys = Arrays.asList(keys);
        Set<String> declared = new HashSet<>();
        for ( String k : term.keys() ) {
            if ( !expectedKeys.contains(k) && !allowUndefinedKeys )
                throw new ResultSetException("Expected only object keys " + Arrays.asList(keys) + " but encountered '" + k + "'");
            if ( expectedKeys.contains(k) )
                declared.add(k);
        }

        if ( requireAllExpectedKeys && declared.size() < expectedKeys.size() )
            throw new ResultSetException("One or more of the required keys " + expectedKeys + " was not found");
    }
}