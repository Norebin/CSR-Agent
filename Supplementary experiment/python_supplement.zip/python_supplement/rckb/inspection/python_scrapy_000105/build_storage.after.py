def build_storage(builder, uri, *args, feed_options=None, preargs=(), **kwargs):
    class BuildStorageParams:
        def __init__(self, builder, uri, args, feed_options, preargs, kwargs):
            self.builder = builder
            self.uri = uri
            self.args = args
            self.feed_options = feed_options
            self.preargs = preargs
            self.kwargs = kwargs

    params = BuildStorageParams(builder, uri, args, feed_options, preargs, kwargs)
    argument_names = get_func_args(params.builder)
    if 'feed_options' in argument_names:
        params.kwargs['feed_options'] = params.feed_options
    else:
        warnings.warn(
            f"{params.builder.__qualname__} does not support the 'feed_options' keyword argument. Add a "
            "'feed_options' parameter to its signature to remove this "
            "warning. This parameter will become mandatory in a future "
            "version of Scrapy.",
            category=ScrapyDeprecationWarning
        )
    return params.builder(*params.preargs, params.uri, *params.args, **params.kwargs)