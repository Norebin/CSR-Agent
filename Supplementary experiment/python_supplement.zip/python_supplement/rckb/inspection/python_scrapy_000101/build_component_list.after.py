def _check_components(complist, convert):
    if len({convert(c) for c in complist}) != len(complist):
        raise ValueError(
            f"Some paths in {complist!r} convert to the same object, "
            "please update your settings"
        )


def _map_keys(compdict, convert):
    if isinstance(compdict, BaseSettings):
        compbs = BaseSettings()
        for k, v in compdict.items():
            prio = compdict.getpriority(k)
            assert prio is not None
            if compbs.getpriority(convert(k)) == prio:
                raise ValueError(
                    f"Some paths in {list(compdict.keys())!r} "
                    "convert to the same "
                    "object, please update your settings"
                )
            else:
                compbs.set(convert(k), v, priority=prio)
        return compbs
    _check_components(compdict, convert)
    return {convert(k): v for k, v in compdict.items()}


def _validate_values(compdict):
    """Fail if a value in the components dict is not a real number or None."""
    for name, value in compdict.items():
        if value is not None and not isinstance(value, numbers.Real):
            raise ValueError(
                f"Invalid value {value} for component {name}, "
                "please provide a real number or None instead"
            )


def build_component_list(compdict, custom=None, convert=update_classpath):
    """Compose a component list from a { class: order } dictionary."""

    if custom is not None:
        warnings.warn(
            "The 'custom' attribute of build_component_list() is deprecated. "
            "Please merge its value into 'compdict' manually or change your "
            "code to use Settings.getwithbase().",
            category=ScrapyDeprecationWarning,
            stacklevel=2,
        )
        if isinstance(custom, (list, tuple)):
            _check_components(custom, convert)
            return type(custom)(convert(c) for c in custom)
        compdict.update(custom)

    _validate_values(compdict)
    compdict = without_none_values(_map_keys(compdict, convert))
    return [k for k, v in sorted(compdict.items(), key=itemgetter(1))]