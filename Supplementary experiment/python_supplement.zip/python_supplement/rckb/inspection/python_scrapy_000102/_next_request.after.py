    def _next_request(self) -> None:
        assert self.slot is not None  # typing
        assert self.spider is not None  # typing

        if self._is_paused():
            return None

        self._drain_scheduler()

        self._process_start_requests()

        if self.spider_is_idle() and self.slot.close_if_idle:
            self._spider_idle()

    def _is_paused(self) -> bool:
        return self.paused

    def _drain_scheduler(self) -> None:
        while not self._needs_backout() and self._next_request_from_scheduler() is not None:
            pass

    def _process_start_requests(self) -> None:
        if self.slot.start_requests is not None and not self._needs_backout():
            try:
                request = next(self.slot.start_requests)
            except StopIteration:
                self.slot.start_requests = None
            except Exception:
                self.slot.start_requests = None
                logger.error('Error while obtaining start requests', exc_info=True, extra={'spider': self.spider})
            else:
                self.crawl(request)