    def prepare_request(self, spider, request, opts):
        def determine_callback(response):
            cb = response.meta['_callback']
            if not cb:
                if opts.callback:
                    cb = opts.callback
                elif opts.rules and self.first_response == response:
                    cb = self.get_callback_from_rules(spider, response)
                    if not cb:
                        logger.error('Cannot find a rule that matches %(url)r in spider: %(spider)s',
                                     {'url': response.url, 'spider': spider.name})
                        return None
                else:
                    cb = 'parse'
            if not callable(cb):
                cb_method = getattr(spider, cb, None)
                if callable(cb_method):
                    cb = cb_method
                else:
                    logger.error('Cannot find callback %(callback)r in spider: %(spider)s',
                                 {'callback': cb, 'spider': spider.name})
                    return None
            return cb

        def process_items_and_requests(response, cb, cb_kwargs):
            depth = response.meta['_depth']
            items, requests = self.run_callback(response, cb, cb_kwargs)
            if opts.pipelines:
                itemproc = self.pcrawler.engine.scraper.itemproc
                for item in items:
                    itemproc.process_item(item, spider)
            self.add_items(depth, items)
            self.add_requests(depth, requests)
            return depth, items, requests

        def schedule_recursive_requests(depth, requests):
            for req in requests:
                req.meta['_depth'] = depth + 1
                req.meta['_callback'] = req.callback
                req.callback = callback

        def callback(response, **cb_kwargs):
            if not self.first_response:
                self.first_response = response

            cb = determine_callback(response)
            if cb is None:
                return

            depth, items, requests = process_items_and_requests(response, cb, cb_kwargs)

            scraped_data = items if opts.output else []
            if depth < opts.depth:
                schedule_recursive_requests(depth, requests)
                scraped_data += requests

            return scraped_data

        if opts.meta:
            request.meta.update(opts.meta)

        if opts.cbkwargs:
            request.cb_kwargs.update(opts.cbkwargs)

        request.meta['_depth'] = 1
        request.meta['_callback'] = request.callback
        request.callback = callback
        return request