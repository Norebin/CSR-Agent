    class _RequestParams:
        def __init__(self, key, endpoint, method, parsedURI, headers, bodyProducer, requestPath):
            self.key = key
            self.endpoint = endpoint
            self.method = method
            self.parsedURI = parsedURI
            self.headers = headers
            self.bodyProducer = bodyProducer
            self.requestPath = requestPath

    def _requestWithEndpoint(self, key, endpoint, method, parsedURI, headers, bodyProducer, requestPath):
        params = self._RequestParams(key, endpoint, method, parsedURI, headers, bodyProducer, requestPath)
        # proxy host and port are required for HTTP pool `key`
        # otherwise, same remote host connection request could reuse
        # a cached tunneled connection to a different proxy
        params.key += self._proxyConf
        return super()._requestWithEndpoint(
            key=params.key,
            endpoint=params.endpoint,
            method=params.method,
            parsedURI=params.parsedURI,
            headers=params.headers,
            bodyProducer=params.bodyProducer,
            requestPath=params.requestPath,
        )