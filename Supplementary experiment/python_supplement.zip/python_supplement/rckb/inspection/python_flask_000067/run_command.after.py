class RunCommandConfig:
    def __init__(
        self,
        info,
        host,
        port,
        reload,
        debugger,
        with_threads,
        cert,
        extra_files,
        exclude_patterns,
    ):
        self.info = info
        self.host = host
        self.port = port
        self.reload = reload
        self.debugger = debugger
        self.with_threads = with_threads
        self.cert = cert
        self.extra_files = extra_files
        self.exclude_patterns = exclude_patterns


def _run_command_with_config(config: RunCommandConfig):
    try:
        app = config.info.load_app()
    except Exception as e:
        if is_running_from_reloader():
            # When reloading, print out the error immediately, but raise
            # it later so the debugger or server can handle it.
            traceback.print_exc()
            err = e

            def app(environ, start_response):
                raise err from None

        else:
            # When not reloading, raise the error immediately so the
            # command fails.
            raise e from None

    debug = get_debug_flag()

    if config.reload is None:
        config.reload = debug

    if config.debugger is None:
        config.debugger = debug

    show_server_banner(debug, config.info.app_import_path)

    run_simple(
        config.host,
        config.port,
        app,
        use_reloader=config.reload,
        use_debugger=config.debugger,
        threaded=config.with_threads,
        ssl_context=config.cert,
        extra_files=config.extra_files,
        exclude_patterns=config.exclude_patterns,
    )


def run_command(
    info,
    host,
    port,
    reload,
    debugger,
    with_threads,
    cert,
    extra_files,
    exclude_patterns,
):
    config = RunCommandConfig(
        info,
        host,
        port,
        reload,
        debugger,
        with_threads,
        cert,
        extra_files,
        exclude_patterns,
    )
    _run_command_with_config(config)