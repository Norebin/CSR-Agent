    def _link_allowed(self, link):
        if not self._is_valid_link_url(link):
            return False
        if not self._is_allowed_by_allow_res(link):
            return False
        if self._is_denied_by_deny_res(link):
            return False
        parsed_url = urlparse(link.url)
        if not self._is_allowed_by_allow_domains(parsed_url):
            return False
        if self._is_denied_by_deny_domains(parsed_url):
            return False
        if self._is_denied_by_deny_extensions(parsed_url):
            return False
        if not self._is_allowed_by_restrict_text(link):
            return False
        return True

    def _is_valid_link_url(self, link):
        return _is_valid_url(link.url)

    def _is_allowed_by_allow_res(self, link):
        if self.allow_res:
            return _matches(link.url, self.allow_res)
        return True

    def _is_denied_by_deny_res(self, link):
        if self.deny_res:
            return _matches(link.url, self.deny_res)
        return False

    def _is_allowed_by_allow_domains(self, parsed_url):
        if self.allow_domains:
            return url_is_from_any_domain(parsed_url, self.allow_domains)
        return True

    def _is_denied_by_deny_domains(self, parsed_url):
        if self.deny_domains:
            return url_is_from_any_domain(parsed_url, self.deny_domains)
        return False

    def _is_denied_by_deny_extensions(self, parsed_url):
        if self.deny_extensions:
            return url_has_any_extension(parsed_url, self.deny_extensions)
        return False

    def _is_allowed_by_restrict_text(self, link):
        if self.restrict_text:
            return _matches(link.text, self.restrict_text)
        return True