class ScrapyAgentParams:
    def __init__(self, contextFactory=None, connectTimeout=10, bindAddress=None, pool=None,
                 maxsize=0, warnsize=0, fail_on_dataloss=True, crawler=None):
        self.contextFactory = contextFactory
        self.connectTimeout = connectTimeout
        self.bindAddress = bindAddress
        self.pool = pool
        self.maxsize = maxsize
        self.warnsize = warnsize
        self.fail_on_dataloss = fail_on_dataloss
        self.crawler = crawler

def __init__(self, contextFactory=None, connectTimeout=10, bindAddress=None, pool=None,
             maxsize=0, warnsize=0, fail_on_dataloss=True, crawler=None):
    params = ScrapyAgentParams(contextFactory, connectTimeout, bindAddress, pool,
                               maxsize, warnsize, fail_on_dataloss, crawler)
    self._init_with_params(params)

def _init_with_params(self, params):
    self._contextFactory = params.contextFactory
    self._connectTimeout = params.connectTimeout
    self._bindAddress = params.bindAddress
    self._pool = params.pool
    self._maxsize = params.maxsize
    self._warnsize = params.warnsize
    self._fail_on_dataloss = params.fail_on_dataloss
    self._txresponse = None
    self._crawler = params.crawler