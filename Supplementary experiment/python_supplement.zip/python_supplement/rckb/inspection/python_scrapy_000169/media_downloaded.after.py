    def media_downloaded(self, response, request, info, *, item=None):
        referer = referer_str(request)

        self._check_response_status(response, request, info, referer)
        self._check_response_body(response, request, info, referer)

        status = self._determine_status(response)
        self._log_download_status(status, request, info, referer)
        self.inc_stats(info.spider, status)

        path, checksum = self._process_file(response, request, info, item, referer)

        return {'url': request.url, 'path': path, 'checksum': checksum, 'status': status}

    def _check_response_status(self, response, request, info, referer):
        if response.status != 200:
            logger.warning(
                'File (code: %(status)s): Error downloading file from '
                '%(request)s referred in <%(referer)s>',
                {'status': response.status,
                 'request': request, 'referer': referer},
                extra={'spider': info.spider}
            )
            raise FileException('download-error')

    def _check_response_body(self, response, request, info, referer):
        if not response.body:
            logger.warning(
                'File (empty-content): Empty file from %(request)s referred '
                'in <%(referer)s>: no-content',
                {'request': request, 'referer': referer},
                extra={'spider': info.spider}
            )
            raise FileException('empty-content')

    def _determine_status(self, response):
        return 'cached' if 'cached' in response.flags else 'downloaded'

    def _log_download_status(self, status, request, info, referer):
        logger.debug(
            'File (%(status)s): Downloaded file from %(request)s referred in '
            '<%(referer)s>',
            {'status': status, 'request': request, 'referer': referer},
            extra={'spider': info.spider}
        )

    def _process_file(self, response, request, info, item, referer):
        try:
            path = self.file_path(request, response=response, info=info, item=item)
            checksum = self.file_downloaded(response, request, info, item=item)
        except FileException as exc:
            logger.warning(
                'File (error): Error processing file from %(request)s '
                'referred in <%(referer)s>: %(errormsg)s',
                {'request': request, 'referer': referer, 'errormsg': str(exc)},
                extra={'spider': info.spider}, exc_info=True
            )
            raise
        except Exception as exc:
            logger.error(
                'File (unknown-error): Error processing file from %(request)s '
                'referred in <%(referer)s>',
                {'request': request, 'referer': referer},
                exc_info=True, extra={'spider': info.spider}
            )
            raise FileException(str(exc))
        return path, checksum