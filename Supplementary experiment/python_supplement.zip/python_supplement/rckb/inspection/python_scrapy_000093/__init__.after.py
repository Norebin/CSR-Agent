from collections import namedtuple

_FilteringLinkExtractorConfig = namedtuple('_FilteringLinkExtractorConfig', [
    'allow', 'deny', 'allow_domains', 'deny_domains',
    'restrict_xpaths', 'canonicalize', 'deny_extensions',
    'restrict_css', 'restrict_text'
])

def _compile_regex_list(patterns):
    return [x if isinstance(x, _re_type) else re.compile(x) for x in arg_to_iter(patterns)]

class FilteringLinkExtractor:
    def __init__(self, link_extractor, allow, deny, allow_domains, deny_domains,
                 restrict_xpaths, canonicalize, deny_extensions, restrict_css, restrict_text):

        config = _FilteringLinkExtractorConfig(
            allow=allow,
            deny=deny,
            allow_domains=allow_domains,
            deny_domains=deny_domains,
            restrict_xpaths=restrict_xpaths,
            canonicalize=canonicalize,
            deny_extensions=deny_extensions,
            restrict_css=restrict_css,
            restrict_text=restrict_text
        )
        self._init_with_config(link_extractor, config)

    def _init_with_config(self, link_extractor, config):
        self.link_extractor = link_extractor

        self.allow_res = _compile_regex_list(config.allow)
        self.deny_res = _compile_regex_list(config.deny)

        self.allow_domains = set(arg_to_iter(config.allow_domains))
        self.deny_domains = set(arg_to_iter(config.deny_domains))

        self.restrict_xpaths = tuple(arg_to_iter(config.restrict_xpaths))
        self.restrict_xpaths += tuple(map(self._csstranslator.css_to_xpath,
                                          arg_to_iter(config.restrict_css)))

        self.canonicalize = config.canonicalize
        if config.deny_extensions is None:
            deny_extensions = IGNORED_EXTENSIONS
        else:
            deny_extensions = config.deny_extensions
        self.deny_extensions = {'.' + e for e in arg_to_iter(deny_extensions)}

        self.restrict_text = _compile_regex_list(config.restrict_text)