    def _check_deprecated_start_requests_use(self, spider: Spider):
        def find_method_classes(mro, *method_names):
            found = {name: None for name in method_names}
            for cls in mro:
                cls_dict = cls.__dict__
                for name in method_names:
                    if found[name] is None and name in cls_dict:
                        found[name] = cls
                if all(found[name] is not None for name in method_names):
                    break
            return found

        def format_source(cls, spidercls):
            src = global_object_name(cls)
            if cls is not spidercls:
                src += f" (inherited by {global_object_name(spidercls)})"
            return src

        def warn_deprecated_start_requests(src):
            warn(
                f"{src} defines the deprecated start_requests() method. "
                f"start_requests() has been deprecated in favor of a new "
                f"method, start(), to support asynchronous code "
                f"execution. start_requests() will stop being called in a "
                f"future version of Scrapy. If you use Scrapy 2.13 or "
                f"higher only, replace start_requests() with start(); "
                f"note that start() is a coroutine (async def). If you "
                f"need to maintain compatibility with lower Scrapy versions, "
                f"when overriding start_requests() in a spider class, "
                f"override start() as well; you can use super() to "
                f"reuse the inherited start() implementation without "
                f"copy-pasting. See the release notes of Scrapy 2.13 for "
                f"details: https://docs.scrapy.org/en/2.13/news.html",
                ScrapyDeprecationWarning,
            )

        def raise_incompatible_middleware_error(src):
            raise ValueError(
                f"{src} does not define the deprecated start_requests() "
                f"method. However, one or more of your enabled spider "
                f"middlewares (reported in an earlier deprecation warning) "
                f"define the process_start_requests() method, and not the "
                f"process_start() method, making them only compatible with "
                f"(deprecated) spiders that define the start_requests() "
                f"method. To solve this issue, disable the offending spider "
                f"middlewares, upgrade them as described in that earlier "
                f"deprecation warning, or make your spider compatible with "
                f"deprecated spider middlewares (and earlier Scrapy versions) "
                f"by defining a sync start_requests() method that works "
                f"similarly to its existing start() method. See the "
                f"release notes of Scrapy 2.13 for details: "
                f"https://docs.scrapy.org/en/2.13/news.html"
            )

        spidercls = spider.__class__
        mro = spidercls.__mro__

        methods = find_method_classes(mro, "start_requests", "start")
        start_requests_cls = methods["start_requests"]
        start_cls = methods["start"]

        # Spider defines both, start_requests and start.
        assert start_requests_cls is not None
        assert start_cls is not None

        if (
            start_requests_cls is not Spider
            and start_cls is not start_requests_cls
            and mro.index(start_requests_cls) < mro.index(start_cls)
        ):
            src = format_source(start_requests_cls, spidercls)
            warn_deprecated_start_requests(src)

        if (
            self._use_start_requests
            and start_cls is not Spider
            and start_requests_cls is not start_cls
            and mro.index(start_cls) < mro.index(start_requests_cls)
        ):
            src = format_source(start_cls, spidercls)
            raise_incompatible_middleware_error(src)