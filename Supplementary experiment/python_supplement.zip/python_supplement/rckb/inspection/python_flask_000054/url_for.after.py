    def url_for(
        self,
        endpoint: str,
        *,
        _anchor: t.Optional[str] = None,
        _method: t.Optional[str] = None,
        _scheme: t.Optional[str] = None,
        _external: t.Optional[bool] = None,
        **values: t.Any,
    ) -> str:
        """Generate a URL to the given endpoint with the given values.

        This is called by :func:`flask.url_for`, and can be called
        directly as well.

        An *endpoint* is the name of a URL rule, usually added with
        :meth:`@app.route() <route>`, and usually the same name as the
        view function. A route defined in a :class:`~flask.Blueprint`
        will prepend the blueprint's name separated by a ``.`` to the
        endpoint.

        In some cases, such as email messages, you want URLs to include
        the scheme and domain, like ``https://example.com/hello``. When
        not in an active request, URLs will be external by default, but
        this requires setting :data:`SERVER_NAME` so Flask knows what
        domain to use. :data:`APPLICATION_ROOT` and
        :data:`PREFERRED_URL_SCHEME` should also be configured as
        needed. This config is only used when not in an active request.

        Functions can be decorated with :meth:`url_defaults` to modify
        keyword arguments before the URL is built.

        If building fails for some reason, such as an unknown endpoint
        or incorrect values, the app's :meth:`handle_url_build_error`
        method is called. If that returns a string, that is returned,
        otherwise a :exc:`~werkzeug.routing.BuildError` is raised.

        :param endpoint: The endpoint name associated with the URL to
            generate. If this starts with a ``.``, the current blueprint
            name (if any) will be used.
        :param _anchor: If given, append this as ``#anchor`` to the URL.
        :param _method: If given, generate the URL associated with this
            method for the endpoint.
        :param _scheme: If given, the URL will have this scheme if it
            is external.
        :param _external: If given, prefer the URL to be internal
            (False) or require it to be external (True). External URLs
            include the scheme and domain. When not in an active
            request, URLs are external by default.
        :param values: Values to use for the variable parts of the URL
            rule. Unknown keys are appended as query string arguments,
            like ``?a=b&c=d``.

        .. versionadded:: 2.2
            Moved from ``flask.url_for``, which calls this method.
        """
        req_ctx = _cv_request.get(None)

        if req_ctx is not None:
            url_adapter = req_ctx.url_adapter
            blueprint_name = req_ctx.request.blueprint
            endpoint = self._adjust_endpoint_for_blueprint(endpoint, blueprint_name)
            _external = self._determine_external_in_request(_external, _scheme)
        else:
            url_adapter = self._get_url_adapter_outside_request()
            _external = self._determine_external_outside_request(_external)

        self._validate_scheme_external(_scheme, _external)

        self.inject_url_defaults(endpoint, values)

        try:
            rv = url_adapter.build(  # type: ignore[union-attr]
                endpoint,
                values,
                method=_method,
                url_scheme=_scheme,
                force_external=_external,
            )
        except BuildError as error:
            values.update(
                _anchor=_anchor, _method=_method, _scheme=_scheme, _external=_external
            )
            return self.handle_url_build_error(error, endpoint, values)

        if _anchor is not None:
            _anchor = _url_quote(_anchor, safe="%!#$&'()*+,/:;=?@")
            rv = f"{rv}#{_anchor}"

        return rv

    def _adjust_endpoint_for_blueprint(self, endpoint: str, blueprint_name: t.Optional[str]) -> str:
        if endpoint[:1] == ".":
            if blueprint_name is not None:
                endpoint = f"{blueprint_name}{endpoint}"
            else:
                endpoint = endpoint[1:]
        return endpoint

    def _determine_external_in_request(self, _external: t.Optional[bool], _scheme: t.Optional[str]) -> bool:
        if _external is None:
            return _scheme is not None
        return _external

    def _get_url_adapter_outside_request(self):
        app_ctx = _cv_app.get(None)
        if app_ctx is not None:
            url_adapter = app_ctx.url_adapter
        else:
            url_adapter = self.create_url_adapter(None)
        if url_adapter is None:
            raise RuntimeError(
                "Unable to build URLs outside an active request"
                " without 'SERVER_NAME' configured. Also configure"
                " 'APPLICATION_ROOT' and 'PREFERRED_URL_SCHEME' as"
                " needed."
            )
        return url_adapter

    def _determine_external_outside_request(self, _external: t.Optional[bool]) -> bool:
        if _external is None:
            return True
        return _external

    def _validate_scheme_external(self, _scheme: t.Optional[str], _external: bool) -> None:
        if _scheme is not None and not _external:
            raise ValueError("When specifying '_scheme', '_external' must be True.")