    def __init__(self, spidercls, settings=None, init_reactor: bool = False):
        self._validate_spidercls(spidercls)
        settings = self._init_settings(settings)
        self.spidercls = spidercls
        self.settings = settings.copy()
        self.spidercls.update_settings(self.settings)

        self._init_signals_and_stats()
        self._init_logging()
        self._log_overridden_settings()
        self._install_root_handler_and_connect_remove()
        self._init_logformatter()

        self._init_reactor(init_reactor)
        self._verify_reactor()

        self.extensions = ExtensionManager.from_crawler(self)

        self.settings.freeze()
        self.crawling = False
        self.spider = None
        self.engine = None

    def _validate_spidercls(self, spidercls):
        if isinstance(spidercls, Spider):
            raise ValueError('The spidercls argument must be a class, not an object')

    def _init_settings(self, settings):
        if isinstance(settings, dict) or settings is None:
            settings = Settings(settings)
        return settings

    def _init_signals_and_stats(self):
        self.signals = SignalManager(self)
        self.stats = load_object(self.settings['STATS_CLASS'])(self)

    def _init_logging(self):
        handler = LogCounterHandler(self, level=self.settings.get('LOG_LEVEL'))
        logging.root.addHandler(handler)
        self._log_handler = handler

    def _log_overridden_settings(self):
        d = dict(overridden_settings(self.settings))
        logger.info("Overridden settings:\n%(settings)s",
                    {'settings': pprint.pformat(d)})

    def _install_root_handler_and_connect_remove(self):
        if get_scrapy_root_handler() is not None:
            # scrapy root handler already installed: update it with new settings
            install_scrapy_root_handler(self.settings)
        # lambda is assigned to Crawler attribute because this way it is not
        # garbage collected after leaving __init__ scope
        self.__remove_handler = lambda: logging.root.removeHandler(self._log_handler)
        self.signals.connect(self.__remove_handler, signals.engine_stopped)

    def _init_logformatter(self):
        lf_cls = load_object(self.settings['LOG_FORMATTER'])
        self.logformatter = lf_cls.from_crawler(self)

    def _init_reactor(self, init_reactor):
        reactor_class = self.settings.get("TWISTED_REACTOR")
        if init_reactor:
            # this needs to be done after the spider settings are merged,
            # but before something imports twisted.internet.reactor
            if reactor_class:
                install_reactor(reactor_class, self.settings["ASYNCIO_EVENT_LOOP"])
            else:
                from twisted.internet import default
                default.install()
            log_reactor_info()
        self._reactor_class = reactor_class

    def _verify_reactor(self):
        if getattr(self, '_reactor_class', None):
            verify_installed_reactor(self._reactor_class)