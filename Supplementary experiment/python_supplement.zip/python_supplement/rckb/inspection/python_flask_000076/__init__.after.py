    def __init__(
        self,
        app: "Flask",
        path: str = "/",
        base_url: t.Optional[str] = None,
        subdomain: t.Optional[str] = None,
        url_scheme: t.Optional[str] = None,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> None:
        class Config:
            def __init__(
                self,
                app: "Flask",
                path: str,
                base_url: t.Optional[str],
                subdomain: t.Optional[str],
                url_scheme: t.Optional[str],
            ) -> None:
                self.app = app
                self.path = path
                self.base_url = base_url
                self.subdomain = subdomain
                self.url_scheme = url_scheme

            def validate(self) -> None:
                assert not (self.base_url or self.subdomain or self.url_scheme) or (
                    self.base_url is not None
                ) != bool(self.subdomain or self.url_scheme), (
                    'Cannot pass "subdomain" or "url_scheme" with "base_url".'
                )

            def compute_base_url_and_path(self) -> None:
                if self.base_url is None:
                    http_host = self.app.config.get("SERVER_NAME") or "localhost"
                    app_root = self.app.config["APPLICATION_ROOT"]

                    if self.subdomain:
                        http_host = f"{self.subdomain}.{http_host}"

                    if self.url_scheme is None:
                        self.url_scheme = self.app.config["PREFERRED_URL_SCHEME"]

                    url = urlsplit(self.path)
                    self.base_url = (
                        f"{url.scheme or self.url_scheme}://{url.netloc or http_host}"
                        f"/{app_root.lstrip('/')}"
                    )
                    self.path = url.path

                    if url.query:
                        sep = b"?" if isinstance(url.query, bytes) else "?"
                        self.path += sep + url.query

        config = Config(app, path, base_url, subdomain, url_scheme)
        config.validate()
        config.compute_base_url_and_path()

        self.app = config.app
        super().__init__(config.path, config.base_url, *args, **kwargs)