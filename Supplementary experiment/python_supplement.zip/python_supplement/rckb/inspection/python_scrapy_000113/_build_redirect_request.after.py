def _build_redirect_request(source_request, *, url, **kwargs):
    redirect_request = source_request.replace(
        url=url,
        **kwargs,
        cookies=None,
    )

    def _remove_proxy_auth_if_scheme_changed():
        if "_scheme_proxy" not in redirect_request.meta:
            return
        source_request_scheme = urlparse_cached(source_request).scheme
        redirect_request_scheme = urlparse_cached(redirect_request).scheme
        if source_request_scheme == redirect_request_scheme:
            return
        redirect_request.meta.pop("_scheme_proxy")
        redirect_request.meta.pop("proxy", None)
        redirect_request.meta.pop("_auth_proxy", None)
        redirect_request.headers.pop(b"Proxy-Authorization", None)

    def _should_delete_cookie_header():
        if "Cookie" not in redirect_request.headers:
            return False
        default_ports = {"http": 80, "https": 443}
        parsed_source = urlparse_cached(source_request)
        parsed_redirect = urlparse_cached(redirect_request)
        source_scheme = parsed_source.scheme
        source_host = parsed_source.hostname
        source_port = parsed_source.port or default_ports.get(source_scheme)
        redirect_scheme = parsed_redirect.scheme
        redirect_host = parsed_redirect.hostname
        redirect_port = parsed_redirect.port or default_ports.get(redirect_scheme)
        if (source_scheme != redirect_scheme and redirect_scheme != "https") or source_host != redirect_host:
            return True
        return False

    def _should_delete_authorization_header():
        if "Authorization" not in redirect_request.headers:
            return False
        default_ports = {"http": 80, "https": 443}
        parsed_source = urlparse_cached(source_request)
        parsed_redirect = urlparse_cached(redirect_request)
        source_scheme = parsed_source.scheme
        source_host = parsed_source.hostname
        source_port = parsed_source.port or default_ports.get(source_scheme)
        redirect_scheme = parsed_redirect.scheme
        redirect_host = parsed_redirect.hostname
        redirect_port = parsed_redirect.port or default_ports.get(redirect_scheme)
        if source_scheme != redirect_scheme or source_host != redirect_host or source_port != redirect_port:
            return True
        return False

    _remove_proxy_auth_if_scheme_changed()

    if "Cookie" in redirect_request.headers or "Authorization" in redirect_request.headers:
        if _should_delete_cookie_header():
            del redirect_request.headers["Cookie"]
        if _should_delete_authorization_header():
            del redirect_request.headers["Authorization"]

    return redirect_request