    class _BlueprintConfig:
        def __init__(
            self,
            name: str,
            import_name: str,
            static_folder: t.Optional[t.Union[str, os.PathLike]] = None,
            static_url_path: t.Optional[str] = None,
            template_folder: t.Optional[t.Union[str, os.PathLike]] = None,
            url_prefix: t.Optional[str] = None,
            subdomain: t.Optional[str] = None,
            url_defaults: t.Optional[dict] = None,
            root_path: t.Optional[str] = None,
            cli_group: t.Optional[str] = _sentinel,  # type: ignore
        ):
            self.name = name
            self.import_name = import_name
            self.static_folder = static_folder
            self.static_url_path = static_url_path
            self.template_folder = template_folder
            self.url_prefix = url_prefix
            self.subdomain = subdomain
            self.url_defaults = url_defaults
            self.root_path = root_path
            self.cli_group = cli_group

    def __init__(
        self,
        name: str,
        import_name: str,
        static_folder: t.Optional[t.Union[str, os.PathLike]] = None,
        static_url_path: t.Optional[str] = None,
        template_folder: t.Optional[t.Union[str, os.PathLike]] = None,
        url_prefix: t.Optional[str] = None,
        subdomain: t.Optional[str] = None,
        url_defaults: t.Optional[dict] = None,
        root_path: t.Optional[str] = None,
        cli_group: t.Optional[str] = _sentinel,  # type: ignore
    ):
        config = self._BlueprintConfig(
            name,
            import_name,
            static_folder,
            static_url_path,
            template_folder,
            url_prefix,
            subdomain,
            url_defaults,
            root_path,
            cli_group,
        )

        super().__init__(
            import_name=config.import_name,
            static_folder=config.static_folder,
            static_url_path=config.static_url_path,
            template_folder=config.template_folder,
            root_path=config.root_path,
        )

        if "." in config.name:
            raise ValueError("'name' may not contain a dot '.' character.")

        self.name = config.name
        self.url_prefix = config.url_prefix
        self.subdomain = config.subdomain
        self.deferred_functions: t.List[DeferredSetupFunction] = []

        if config.url_defaults is None:
            config.url_defaults = {}

        self.url_values_defaults = config.url_defaults
        self.cli_group = config.cli_group
        self._blueprints: t.List[t.Tuple["Blueprint", dict]] = []