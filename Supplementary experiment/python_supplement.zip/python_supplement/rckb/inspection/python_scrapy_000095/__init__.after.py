    class _FeedSlotParams:
        def __init__(self, file, exporter, storage, uri, format, store_empty, batch_id, uri_template, filter):
            self.file = file
            self.exporter = exporter
            self.storage = storage
            self.uri = uri
            self.format = format
            self.store_empty = store_empty
            self.batch_id = batch_id
            self.uri_template = uri_template
            self.filter = filter

    def __init__(self, file, exporter, storage, uri, format, store_empty, batch_id, uri_template, filter):
        params = self._FeedSlotParams(file, exporter, storage, uri, format, store_empty, batch_id, uri_template, filter)
        self.file = params.file
        self.exporter = params.exporter
        self.storage = params.storage
        # feed params
        self.batch_id = params.batch_id
        self.format = params.format
        self.store_empty = params.store_empty
        self.uri_template = params.uri_template
        self.uri = params.uri
        self.filter = params.filter
        # flags
        self.itemcount = 0
        self._exporting = False