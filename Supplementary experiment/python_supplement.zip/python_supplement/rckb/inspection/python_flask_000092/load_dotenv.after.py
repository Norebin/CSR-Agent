def load_dotenv(
    path: str | os.PathLike[str] | None = None, load_defaults: bool = True
) -> bool:
    """Load "dotenv" files to set environment variables. A given path takes
    precedence over ``.env``, which takes precedence over ``.flaskenv``. After
    loading and combining these files, values are only set if the key is not
    already set in ``os.environ``.

    This is a no-op if `python-dotenv`_ is not installed.

    .. _python-dotenv: https://github.com/theskumar/python-dotenv#readme

    :param path: Load the file at this location.
    :param load_defaults: Search for and load the default ``.flaskenv`` and
        ``.env`` files.
    :return: ``True`` if at least one env var was loaded.

    .. versionchanged:: 3.1
        Added the ``load_defaults`` parameter. A given path takes precedence
        over default files.

    .. versionchanged:: 2.0
        The current directory is not changed to the location of the
        loaded file.

    .. versionchanged:: 2.0
        When loading the env files, set the default encoding to UTF-8.

    .. versionchanged:: 1.1.0
        Returns ``False`` when python-dotenv is not installed, or when
        the given path isn't a file.

    .. versionadded:: 1.0
    """
    def _import_dotenv() -> bool:
        try:
            import dotenv
            return True
        except ImportError:
            return False

    def _warn_missing_dotenv(path: str | os.PathLike[str] | None) -> None:
        if path or os.path.isfile(".env") or os.path.isfile(".flaskenv"):
            click.secho(
                " * Tip: There are .env files present. Install python-dotenv"
                " to use them.",
                fg="yellow",
                err=True,
            )

    def _load_default_env_files(dotenv) -> dict[str, str | None]:
        env_data: dict[str, str | None] = {}
        for default_name in (".flaskenv", ".env"):
            default_path = dotenv.find_dotenv(default_name, usecwd=True)
            if not default_path:
                continue
            env_data |= dotenv.dotenv_values(default_path, encoding="utf-8")
        return env_data

    def _load_path_env_file(dotenv, path: str | os.PathLike[str]) -> dict[str, str | None]:
        if os.path.isfile(path):
            return dotenv.dotenv_values(path, encoding="utf-8")
        return {}

    def _set_env_vars(data: dict[str, str | None]) -> None:
        for key, value in data.items():
            if key in os.environ or value is None:
                continue
            os.environ[key] = value

    if not _import_dotenv():
        _warn_missing_dotenv(path)
        return False

    import dotenv

    data: dict[str, str | None] = {}

    if load_defaults:
        data |= _load_default_env_files(dotenv)

    if path is not None:
        data |= _load_path_env_file(dotenv, path)

    _set_env_vars(data)

    return bool(data)  # True if at least one env var was loaded.