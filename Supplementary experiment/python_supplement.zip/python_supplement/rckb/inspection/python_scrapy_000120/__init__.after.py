    class ProxyConf:
        def __init__(self, proxyConf):
            self.proxyConf = proxyConf

    def __init__(self, reactor, proxyConf, contextFactory=None,
                 connectTimeout=None, bindAddress=None, pool=None):
        super().__init__(reactor, contextFactory, connectTimeout, bindAddress, pool)
        self._proxyConf = self.ProxyConf(proxyConf).proxyConf
        self._contextFactory = contextFactory