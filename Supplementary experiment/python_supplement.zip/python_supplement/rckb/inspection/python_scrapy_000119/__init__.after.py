    class ProxyConfig:
        def __init__(self, proxyConf):
            self.proxyHost, self.proxyPort, self._proxyAuthHeader = proxyConf

    def __init__(self, reactor, host, port, proxyConf, contextFactory, timeout=30, bindAddress=None):
        proxy_config = self.ProxyConfig(proxyConf)
        super().__init__(reactor, proxy_config.proxyHost, proxy_config.proxyPort, timeout, bindAddress)
        self._proxyAuthHeader = proxy_config._proxyAuthHeader
        self._tunnelReadyDeferred = defer.Deferred()
        self._tunneledHost = host
        self._tunneledPort = port
        self._contextFactory = contextFactory
        self._connectBuffer = bytearray()