public final class URIParserUtil {
    private static final String EXCLUDED_CHARS = "<>\"{}|\\^`";
    private static final String HEX_DIGITS = "0123456789abcdef";

    private URIParserUtil() {
        // complete
    }

    private static boolean isExcluded(char ch) {
        return ch <= 0x20 || ch >= 0x7F || EXCLUDED_CHARS.indexOf(ch) != -1;
    }

public static URL[] pathToURLs(String path) {
    return org.apache.cxf.common.util.internal.URIParserClasspathUtil.pathToURLs(path);
}
    public static String parsePackageName(String namespace, String defaultPackageName) {
        String packageName = (defaultPackageName != null && defaultPackageName.trim().length() > 0)
            ? defaultPackageName : null;

        if (packageName == null) {
            packageName = getPackageName(namespace);
        }
        return packageName;
    }

    public static String getPackageName(String nameSpaceURI) {
        int idx = nameSpaceURI.indexOf(':');
        String scheme = "";
        if (idx >= 0) {
            scheme = nameSpaceURI.substring(0, idx);
            if ("http".equalsIgnoreCase(scheme) || "urn".equalsIgnoreCase(scheme)) {
                nameSpaceURI = nameSpaceURI.substring(idx + 1);
            }
        }

        List<String> tokens = tokenize(nameSpaceURI, "/: ");
        if (tokens.isEmpty()) {
            return "cxf";
        }

        if (tokens.size() > 1) {
            String lastToken = tokens.get(tokens.size() - 1);
            idx = lastToken.lastIndexOf('.');
            if (idx > 0) {
                //lastToken = lastToken.substring(0, idx);
                lastToken = lastToken.replace('.', '_');
                tokens.set(tokens.size() - 1, lastToken);
            }
        }

        String domain = tokens.get(0);
        idx = domain.indexOf(':');
        if (idx >= 0) {
            domain = domain.substring(0, idx);
        }
        List<String> r = reverse(tokenize(domain, "urn".equals(scheme) ? ".-" : "."));
        if ("www".equalsIgnoreCase(r.get(r.size() - 1))) {
            // remove leading www
            r.remove(r.size() - 1);
        }

        // replace the domain name with tokenized items
        tokens.addAll(1, r);
        tokens.remove(0);

        // iterate through the tokens and apply xml->java name algorithm
        for (int i = 0; i < tokens.size(); i++) {

            // get the token and remove illegal chars
            String token = tokens.get(i);
            token = removeIllegalIdentifierChars(token);

            // this will check for reserved keywords
            if (containsReservedKeywords(token)) {
                token = '_' + token;
            }

            tokens.set(i, token.toLowerCase());
        }

        // concat all the pieces and return it
        return combine(tokens, '.');
    }

    public static String getNamespace(String packageName) {
        if (packageName == null || packageName.length() == 0) {
            return null;
        }
        StringTokenizer tokenizer = new StringTokenizer(packageName, ".");
        String[] tokens;
        if (tokenizer.countTokens() == 0) {
            tokens = new String[0];
        } else {
            tokens = new String[tokenizer.countTokens()];
            for (int i = tokenizer.countTokens() - 1; i >= 0; i--) {
                tokens[i] = tokenizer.nextToken();
            }
        }
        StringBuilder namespace = new StringBuilder("http://");
        String dot = "";
        for (int i = 0; i < tokens.length; i++) {
            if (i == 1) {
                dot = ".";
            }
            namespace.append(dot + tokens[i]);
        }
        namespace.append('/');
        return namespace.toString();
    }

    private static List<String> tokenize(String str, String sep) {
        StringTokenizer tokens = new StringTokenizer(str, sep);
        List<String> r = new ArrayList<>();

        while (tokens.hasMoreTokens()) {
            r.add(tokens.nextToken());
        }
        return r;
    }

    private static String removeIllegalIdentifierChars(String token) {
        StringBuilder newToken = new StringBuilder();
        for (int i = 0; i < token.length(); i++) {
            char c = token.charAt(i);

            if (i == 0 && !Character.isJavaIdentifierStart(c)) {
                // prefix an '_' if the first char is illegal
                newToken.append("_" + c);
            } else if (!Character.isJavaIdentifierPart(c)) {
                // replace the char with an '_' if it is illegal
                newToken.append('_');
            } else {
                // add the legal char
                newToken.append(c);
            }
        }
        return newToken.toString();
    }

    private static String combine(List<String> r, char sep) {
        StringBuilder buf = new StringBuilder(r.get(0));

        for (int i = 1; i < r.size(); i++) {
            buf.append(sep);
            buf.append(r.get(i));
        }

        return buf.toString();
    }

    private static <T> List<T> reverse(List<T> a) {
        List<T> r = new ArrayList<>();

        for (int i = a.size() - 1; i >= 0; i--) {
            r.add(a.get(i));
        }
        return r;
    }

    public static boolean containsReservedKeywords(String token) {
        return JavaUtils.isJavaKeyword(token);
    }

    public static String escapeChars(String s) {
        StringBuilder b = new StringBuilder(s.length());

        for (int x = 0; x < s.length(); x++) {
            char ch = s.charAt(x);
            if (isExcluded(ch)) {
                byte[] bytes = Character.toString(ch).getBytes(StandardCharsets.UTF_8);
                for (int y = 0; y < bytes.length; y++) {
                    b.append("%");
                    b.append(HEX_DIGITS.charAt((bytes[y] & 0xFF) >> 4));
                    b.append(HEX_DIGITS.charAt(bytes[y] & 0x0F));
                }
            } else {
                b.append(ch);
            }
        }
        return b.toString();
    }
public static String normalize(final String uri) {
    return org.apache.cxf.common.util.internal.URIParserNormalizationUtil.normalize(uri);
}
    public static String getAbsoluteURI(final String arg) {
        if (arg == null) {
            return null;
        }

        try {
            URI uri = new URI(arg);
            if ("file".equalsIgnoreCase(uri.getScheme())) {
                if (!uri.isOpaque()) {
                    return uri.normalize().toString();
                }
                return new File("").toURI().resolve(uri.getPath()).toString();
            }
            return normalize(arg);
        } catch (Exception e2) {
            return normalize(arg);
        }
    }

public static String relativize(URI baseURI, URI toBeRelativizedURI) throws URISyntaxException {
    return org.apache.cxf.common.util.internal.URIParserRelativizationUtil.relativize(baseURI, toBeRelativizedURI);
}
    private static String getRoot(String uri) {
        int idx = uri.lastIndexOf('/');
        if (idx == uri.length() - 1) {
            return uri;
        } else if (idx == -1) {
            return "";
        } else {
            return uri.substring(0, idx + 1);
        }
    }
}