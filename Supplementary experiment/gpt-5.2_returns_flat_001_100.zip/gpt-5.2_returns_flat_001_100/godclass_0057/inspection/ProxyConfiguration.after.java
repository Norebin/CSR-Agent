public final class ProxyConfiguration implements Describable<ProxyConfiguration>, Saveable, Serializable {
    /**
     * Holds a default TCP connect timeout set on all connections returned from this class,
     * note this is value is in milliseconds, it's passed directly to {@link URLConnection#setConnectTimeout(int)}
     */
    private static final int DEFAULT_CONNECT_TIMEOUT_MILLIS = SystemProperties.getInteger("hudson.ProxyConfiguration.DEFAULT_CONNECT_TIMEOUT_MILLIS", (int) TimeUnit.SECONDS.toMillis(20));

    public final String name;
    public final int port;

    /**
     * Possibly null proxy user name.
     */
    private String userName;

    /**
    /**
     * List of host names that shouldn't use proxy, as typed by users.
     *
     * @see ProxyExclusionUtils#getNoProxyHostPatterns(String)
     */
    @Restricted(NoExternalUse.class)
    @SuppressFBWarnings(value = "PA_PUBLIC_PRIMITIVE_ATTRIBUTE", justification = "Preserve API compatibility")
    public String noProxyHost;    public String noProxyHost;

    @Deprecated
    private String password;

    /**
     * encrypted password
     */
    private Secret secretPassword;

    private String testUrl;

    private transient Authenticator authenticator;

    private transient boolean authCacheSeeded;

    @DataBoundConstructor
    public ProxyConfiguration(String name, int port) {
        this(name, port, null, null);
    }

    public ProxyConfiguration(String name, int port, String userName, String password) {
        this(name, port, userName, password, null);
    }

    public ProxyConfiguration(String name, int port, String userName, String password, String noProxyHost) {
        this(name, port, userName, password, noProxyHost, null);
    }

    public ProxyConfiguration(String name, int port, String userName, String password, String noProxyHost, String testUrl) {
        this.name = Util.fixEmptyAndTrim(name);
        this.port = port;
        this.userName = Util.fixEmptyAndTrim(userName);
        String tempPassword = Util.fixEmptyAndTrim(password);
        this.secretPassword = tempPassword != null ? Secret.fromString(tempPassword) : null;
        this.noProxyHost = Util.fixEmptyAndTrim(noProxyHost);
        this.testUrl = Util.fixEmptyAndTrim(testUrl);
        this.authenticator = newAuthenticator();
    }

    private Authenticator newAuthenticator() {
        return new Authenticator() {
            @Override
            public PasswordAuthentication getPasswordAuthentication() {
                String userName = getUserName();
                if (getRequestorType() == RequestorType.PROXY && userName != null) {
                    return new PasswordAuthentication(userName, Secret.toString(secretPassword).toCharArray());
                }
                return null;
            }
        };
    }

    public String getUserName() {
        return userName;
    }

    public Secret getSecretPassword() {
        return secretPassword;
    }

    /**
     * @deprecated
     *      Use {@link #getSecretPassword()}
     */
    @Deprecated
    public String getPassword() {
        return Secret.toString(secretPassword);
    }

    /**
     * @return the encrypted proxy password
     *
     * @deprecated
     *      Use {@link #getSecretPassword()}
     */
    @Deprecated
    public String getEncryptedPassword() {
        return secretPassword == null ? null : secretPassword.getEncryptedValue();
    }

    public String getTestUrl() {
        return testUrl;
    }

    public int getPort() {
        return port;
    }

    public String getName() {
        return name;
    }

    /**
     * Returns the list of properly formatted no proxy host names.
     */
    /**
     * Returns the list of properly formatted no proxy host names.
     */
    public List<Pattern> getNoProxyHostPatterns() {
        return ProxyExclusionUtils.getNoProxyHostPatterns(noProxyHost);
    }

    public String getNoProxyHost() {
        return noProxyHost;
    }

    /**
     * Returns the list of properly formatted no proxy host names.
     */
    public static List<Pattern> getNoProxyHostPatterns(String noProxyHost) {
        return ProxyExclusionUtils.getNoProxyHostPatterns(noProxyHost);
    }
    private static boolean isExcluded(String needle, String haystack) {
        return ProxyExclusionUtils.isExcluded(needle, haystack);
    }
    @DataBoundSetter
    public void setSecretPassword(Secret secretPassword) {
        this.secretPassword = secretPassword;
    }

    @DataBoundSetter
    public void setTestUrl(String testUrl) {
        this.testUrl = testUrl;
    }

    @DataBoundSetter
    public void setUserName(String userName) {
        this.userName = Util.fixEmptyAndTrim(userName);
    }

    @DataBoundSetter
    public void setNoProxyHost(String noProxyHost) {
        this.noProxyHost = noProxyHost;
    }

    /**
     * @deprecated
     *      Use {@link #createProxy(String)}
     */
    @Deprecated
    public Proxy createProxy() {
        return createProxy(null);
    }

    public Proxy createProxy(String host) {
        return createProxy(host, name, port, noProxyHost);
    }

    public static Proxy createProxy(String host, String name, int port, String noProxyHost) {
        if (host != null && noProxyHost != null && isExcluded(host, noProxyHost)) {
           return Proxy.NO_PROXY;
        }
        return new Proxy(Proxy.Type.HTTP, new InetSocketAddress(name, port));
    }

    @Override
    public void save() throws IOException {
        if (BulkChange.contains(this))   return;
        XmlFile config = getXmlFile();
        config.write(this);
        SaveableListener.fireOnChange(this, config);
    }

    private Object readResolve() {
        authenticator = newAuthenticator();
        userName = Util.fixEmptyAndTrim(userName);
        return this;
    }

    public static XmlFile getXmlFile() {
        return new XmlFile(XSTREAM, new File(Jenkins.get().getRootDir(), "proxy.xml"));
    }

    public static ProxyConfiguration load() throws IOException {
        XmlFile f = getXmlFile();
        if (f.exists())
            return (ProxyConfiguration) f.read();
        else
            return null;
    }

    /**
     * This method should be used wherever {@link URL#openConnection()} to internet URLs is invoked directly.
     *
     * @deprecated use {@link #newHttpClient}/{@link #newHttpClientBuilder} and {@link #newHttpRequestBuilder(URI)}
     */
    @Deprecated
    public static URLConnection open(URL url) throws IOException {
        final ProxyConfiguration p = get();

        URLConnection con;
        if (p == null) {
            con = url.openConnection();
        } else {
            Proxy proxy = p.createProxy(url.getHost());
            con = url.openConnection(proxy);
            if (p.getUserName() != null) {
                // Add an authenticator which provides the credentials for proxy authentication
                Authenticator.setDefault(p.authenticator);
                p.jenkins48775workaround(proxy, url);
            }
        }

        if (DEFAULT_CONNECT_TIMEOUT_MILLIS > 0) {
            con.setConnectTimeout(DEFAULT_CONNECT_TIMEOUT_MILLIS);
        }

        if (JenkinsJVM.isJenkinsJVM()) { // this code may run on an agent
            decorate(con);
        }

        return con;
    }

    /**
     * @deprecated use {@link #newHttpClient}/{@link #newHttpClientBuilder} and {@link #newHttpRequestBuilder(URI)}
     */
    @Deprecated
    public static InputStream getInputStream(URL url) throws IOException {
        final ProxyConfiguration p = get();
        if (p == null)
            return ((HttpURLConnection) url.openConnection()).getInputStream();

        Proxy proxy = p.createProxy(url.getHost());
        InputStream is = ((HttpURLConnection) url.openConnection(proxy)).getInputStream();
        if (p.getUserName() != null) {
            // Add an authenticator which provides the credentials for proxy authentication
            Authenticator.setDefault(p.authenticator);
            p.jenkins48775workaround(proxy, url);
        }

        return is;
    }

    /**
     * Return a new {@link HttpClient} with Jenkins-specific default settings.
     *
     * <p>Equivalent to {@code newHttpClientBuilder().followRedirects(HttpClient.Redirect.NORMAL).build()}.
     *
     * @return a new {@link HttpClient}
     * @since 2.379
     * @see #newHttpClientBuilder
     */
    public static HttpClient newHttpClient() {
        return newHttpClientBuilder().followRedirects(HttpClient.Redirect.NORMAL).build();
    }

    private static final Executor httpClientExecutor = Executors.newCachedThreadPool(new NamingThreadFactory(new DaemonThreadFactory(), "Jenkins HttpClient"));

    /**
     * Create a new {@link HttpClient.Builder} preconfigured with Jenkins-specific default settings.
     *
     * <p>The Jenkins-specific default settings include a proxy server and proxy authentication (as
     * configured by {@link ProxyConfiguration}) and a connection timeout (as configured by {@link
     * ProxyConfiguration#DEFAULT_CONNECT_TIMEOUT_MILLIS}).
     *
     * <p><strong>Warning:</strong> if both {@link #getName} and {@link #getUserName} are set
     * (meaning that an authenticated proxy is defined),
     * you will not be able to pass an {@code Authorization} header to the real server
     * when running on Java 17 and later
     * (pending <a href="https://bugs.openjdk.org/browse/JDK-8326949">JDK-8326949</a>.
     *
     * @return an {@link HttpClient.Builder}
     * @since 2.379
     */
    public static HttpClient.Builder newHttpClientBuilder() {
        HttpClient.Builder httpClientBuilder = HttpClient.newBuilder();
        ProxyConfiguration proxyConfiguration = get();
        if (proxyConfiguration != null) {
            if (proxyConfiguration.getName() != null) {
                httpClientBuilder.proxy(new JenkinsProxySelector(
                        proxyConfiguration.getName(),
                        proxyConfiguration.getPort(),
                        proxyConfiguration.getNoProxyHost()));
            }
            if (proxyConfiguration.getUserName() != null) {
                httpClientBuilder.authenticator(proxyConfiguration.authenticator);
            }
        }
        if (DEFAULT_CONNECT_TIMEOUT_MILLIS > 0) {
            httpClientBuilder.connectTimeout(Duration.ofMillis(DEFAULT_CONNECT_TIMEOUT_MILLIS));
        }
        httpClientBuilder.executor(httpClientExecutor);
        return httpClientBuilder;
    }

    /**
     * Create a new {@link HttpRequest.Builder} builder with the given URI preconfigured with
     * Jenkins-specific default settings.
     *
     * <p>The Jenkins-specific default settings include a custom user agent on the controller
     * (unless {@link UserAgentURLConnectionDecorator#DISABLED} is true).
     *
     * @param uri the request URI
     * @return an {@link HttpRequest.Builder}
     * @throws IllegalArgumentException if the URI scheme is not supported
     * @since 2.379
     */
    public static HttpRequest.Builder newHttpRequestBuilder(URI uri) {
        HttpRequest.Builder httpRequestBuilder = HttpRequest.newBuilder(uri);
        if (JenkinsJVM.isJenkinsJVM() && !UserAgentURLConnectionDecorator.DISABLED) {
            httpRequestBuilder.setHeader("User-Agent", UserAgentURLConnectionDecorator.getUserAgent());
        }
        return httpRequestBuilder;
    }

    private static class JenkinsProxySelector extends ProxySelector {
        @NonNull private final Proxy proxy;
        @CheckForNull private final String exclusions;

        private JenkinsProxySelector(@NonNull String hostname, int port, @CheckForNull String exclusions) {
            this.proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(hostname, port));
            this.exclusions = exclusions;
        }

        @Override
        public void connectFailed(URI uri, SocketAddress sa, IOException e) {
            // Ignore.
        }

        @Override
        public List<Proxy> select(URI uri) {
            Objects.requireNonNull(uri);
            String scheme = Objects.requireNonNull(uri.getScheme());
            String host = Objects.requireNonNull(uri.getHost());
            boolean excluded = exclusions != null && isExcluded(host.toLowerCase(), exclusions);
            if (!excluded && (scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))) {
                return List.of(proxy);
            } else {
                return List.of(Proxy.NO_PROXY);
            }
        }
    }

    /**
     * If the first URL we try to access with a HTTP proxy is HTTPS then the authentication cache will not have been
     * pre-populated, so we try to access at least one HTTP URL before the very first HTTPS url.
     * @param url the actual URL being opened.
     */
    private void jenkins48775workaround(Proxy proxy, URL url) {
        if ("https".equals(url.getProtocol()) && !authCacheSeeded && proxy != Proxy.NO_PROXY) {
            HttpURLConnection preAuth = null;
            try {
                // We do not care if there is anything at this URL, all we care is that it is using the proxy
                preAuth = (HttpURLConnection) new URL("http", url.getHost(), -1, "/").openConnection(proxy);
                preAuth.setRequestMethod("HEAD");
                preAuth.connect();
            } catch (IOException e) {
                // ignore, this is just a probe we don't care at all
            } finally {
                if (preAuth != null) {
                    preAuth.disconnect();
                }
            }
            authCacheSeeded = true;
        } else if ("https".equals(url.getProtocol())) {
            // if we access any http url using a proxy then the auth cache will have been seeded
            authCacheSeeded = authCacheSeeded || proxy != Proxy.NO_PROXY;
        }
    }

    @CheckForNull
    private static ProxyConfiguration get() {
        if (JenkinsJVM.isJenkinsJVM()) {
            return _get();
        }
        return null;
    }

    @CheckForNull
    private static ProxyConfiguration _get() {
        JenkinsJVM.checkJenkinsJVM();
        // this code could be called between the JVM flag being set and theInstance initialized
        Jenkins jenkins = Jenkins.getInstanceOrNull();
        return jenkins == null ? null : jenkins.proxy;
    }

    private static void decorate(URLConnection con) throws IOException {
        for (URLConnectionDecorator d : URLConnectionDecorator.all())
            d.decorate(con);
    }

    private static final XStream XSTREAM = new XStream2();

    private static final long serialVersionUID = 1L;

    static {
        XSTREAM.alias("proxy", ProxyConfiguration.class);
    }

    @Extension @Symbol("proxy")
    public static class DescriptorImpl extends Descriptor<ProxyConfiguration> {
        @NonNull
        @Override
        public String getDisplayName() {
            return "Proxy Configuration";
        }

        public FormValidation doCheckPort(@QueryParameter String value) {
            value = Util.fixEmptyAndTrim(value);
            if (value == null) {
                return FormValidation.ok();
            }
            int port;
            try {
                port = Integer.parseInt(value);
            } catch (NumberFormatException e) {
                return FormValidation.error(Messages.PluginManager_PortNotANumber());
            }
            if (port < 0 || port > 65535) {
                return FormValidation.error(Messages.PluginManager_PortNotInRange(0, 65535));
            }
            return FormValidation.ok();
        }

        /**
         * Do check if the provided value is empty or composed of whitespaces.
         * If so, return a validation warning.
         *
         * @param value the value to test
         * @return a validation warning iff the provided value is empty or composed of whitespaces.
         */
        private static FormValidation checkProxyCredentials(String value) {
            value = Util.fixEmptyAndTrim(value);
            if (value == null) {
                return FormValidation.ok();
            } else {
                return FormValidation.warning(Messages.ProxyConfiguration_NonTLSWarning());
            }
        }

        @RequirePOST
        @Restricted(NoExternalUse.class)
        public FormValidation doCheckUserName(@QueryParameter String value) {
            return checkProxyCredentials(value);
        }

        @RequirePOST
        @Restricted(NoExternalUse.class)
        public FormValidation doCheckSecretPassword(@QueryParameter String value) {
            return checkProxyCredentials(value);
        }

        @RequirePOST
        @Restricted(NoExternalUse.class)
        public FormValidation doValidateProxy(
                @QueryParameter("testUrl") String testUrl, @QueryParameter("name") String name, @QueryParameter("port") int port,
                @QueryParameter("userName") String userName, @QueryParameter("secretPassword") Secret password,
                @QueryParameter("noProxyHost") String noProxyHost) throws InterruptedException {

            Jenkins.get().checkPermission(Jenkins.ADMINISTER);

            testUrl = Util.fixEmptyAndTrim(testUrl);
            if (testUrl == null) {
                return FormValidation.error(Messages.ProxyConfiguration_TestUrlRequired());
            }

            URI uri;
            try {
                uri = new URI(testUrl);
            } catch (URISyntaxException e) {
                return FormValidation.error(e, Messages.ProxyConfiguration_MalformedTestUrl(testUrl));
            }
            HttpClient.Builder builder = HttpClient.newBuilder();
            builder.connectTimeout(DEFAULT_CONNECT_TIMEOUT_MILLIS > 0
                    ? Duration.ofMillis(DEFAULT_CONNECT_TIMEOUT_MILLIS)
                    : Duration.ofSeconds(30));
            if (Util.fixEmptyAndTrim(name) != null && !isNoProxyHost(uri.getHost(), noProxyHost)) {
                builder.proxy(ProxySelector.of(new InetSocketAddress(name, port)));
                Authenticator authenticator = newValidationAuthenticator(userName, password != null ? password.getPlainText() : null);
                builder.authenticator(authenticator);
            }
            HttpClient httpClient = builder.build();
            HttpRequest httpRequest;
            try {
                httpRequest = ProxyConfiguration.newHttpRequestBuilder(uri)
                        .method("HEAD", HttpRequest.BodyPublishers.noBody())
                        .build();
            } catch (IllegalArgumentException e) {
                return FormValidation.error(e, Messages.ProxyConfiguration_MalformedTestUrl(testUrl));
            }
            try {
                HttpResponse<Void> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.discarding());
                if (httpResponse.statusCode() < HttpURLConnection.HTTP_BAD_REQUEST) {
                    return FormValidation.ok(Messages.ProxyConfiguration_Success(httpResponse.statusCode()));
                }
                return FormValidation.error(Messages.ProxyConfiguration_FailedToConnect(testUrl, httpResponse.statusCode()));
            } catch (IOException e) {
                return FormValidation.error(e, Messages.ProxyConfiguration_FailedToConnectViaProxy(testUrl));
            }
        }

        private boolean isNoProxyHost(String host, String noProxyHost) {
            if (host != null && noProxyHost != null) {
                for (Pattern p : getNoProxyHostPatterns(noProxyHost)) {
                    if (p.matcher(host).matches()) {
                        return true;
                    }
                }
            }
            return false;
        }

        /**
         * Create an {@link Authenticator} for use in validation context.
         *
         * @see #newAuthenticator
         */
        private static Authenticator newValidationAuthenticator(String userName, String password) {
            return new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(
                            userName, Secret.fromString(password).getPlainText().toCharArray());
                }
            };
        }
    }
}