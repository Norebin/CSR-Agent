public class LogRotator extends BuildDiscarder {

    /** @deprecated Replaced by more generic {@link CompositeIOException}. */
    @Deprecated
    public static class CollatedLogRotatorException extends IOException {
        private static final long serialVersionUID = 5944233808072651101L;

        public final Collection<Exception> collated;

        public CollatedLogRotatorException(String msg, Exception... collated) {
            super(msg);
            if (collated == null || collated.length == 0) {
                this.collated = Collections.emptyList();
            } else {
                this.collated = Arrays.asList(collated);
            }
        }

        public CollatedLogRotatorException(String msg, Collection<Exception> values) {
            super(msg);
            this.collated = values != null ? values : Collections.emptyList();
        }
    }

    /**
     * If not -1, history is only kept up to this days.
     */
    private final int daysToKeep;

    /**
     * If not -1, only this number of build logs are kept.
     */
    private final int numToKeep;

    /**
     * If not -1 nor null, artifacts are only kept up to this days.
     * Null handling is necessary to remain data compatible with old versions.
     * @since 1.350
     */
    private final Integer artifactDaysToKeep;

    /**
     * If not -1 nor null, only this number of builds have their artifacts kept.
     * Null handling is necessary to remain data compatible with old versions.
     * @since 1.350
     */
    private final Integer artifactNumToKeep;

    /**
     * If enabled also remove last successful build.
     * @since 2.474
     */
    private boolean removeLastBuild;

    @DataBoundConstructor
    public LogRotator(String daysToKeepStr, String numToKeepStr, String artifactDaysToKeepStr, String artifactNumToKeepStr) {
        this (parse(daysToKeepStr), parse(numToKeepStr),
              parse(artifactDaysToKeepStr), parse(artifactNumToKeepStr));
    }

    public static int parse(String p) {
        if (p == null)     return -1;
        try {
            return Integer.parseInt(p);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /**
     * @deprecated since 1.350.
     *      Use {@link #LogRotator(int, int, int, int)}
     */
    @Deprecated
    public LogRotator(int daysToKeep, int numToKeep) {
        this(daysToKeep, numToKeep, -1, -1);
    }

    public LogRotator(int daysToKeep, int numToKeep, int artifactDaysToKeep, int artifactNumToKeep) {
        this.daysToKeep = daysToKeep;
        this.numToKeep = numToKeep;
        this.artifactDaysToKeep = artifactDaysToKeep;
        this.artifactNumToKeep = artifactNumToKeep;

    }

    @DataBoundSetter
    public void setRemoveLastBuild(boolean removeLastBuild) {
        this.removeLastBuild = removeLastBuild;
    }

@Override
@SuppressWarnings("rawtypes")
public void perform(Job<?, ?> job) throws IOException, InterruptedException {
    //Exceptions thrown by the deletion submethods are collated and reported
    Map<Run<?, ?>, Set<IOException>> exceptionMap = new HashMap<>();

    LOGGER.log(FINE, "Running the log rotation for {0} with numToKeep={1} daysToKeep={2} artifactNumToKeep={3} artifactDaysToKeep={4}", new Object[] {job, numToKeep, daysToKeep, artifactNumToKeep, artifactDaysToKeep});

    // if configured keep the last successful and the last stable builds
    Run lsb = removeLastBuild ? null : job.getLastSuccessfulBuild();
    Run lstb = removeLastBuild ? null : job.getLastStableBuild();

    Map<Integer, ? extends Run<?, ?>> runMap = job.getBuildsAsMap();
    LogRotationHelper.rotateBuildRecords(job, runMap, numToKeep, daysToKeep, artifactNumToKeep, artifactDaysToKeep, lsb, lstb, exceptionMap, this);

    if (!exceptionMap.isEmpty()) {
        //Collate all encountered exceptions into a single exception and throw that
        String msg = String.format(
                "Failed to rotate logs for [%s]",
                exceptionMap.keySet().stream().map(Object::toString).collect(Collectors.joining(", "))
        );
        throw new CompositeIOException(msg, exceptionMap.values().stream().flatMap(Collection::stream).collect(Collectors.toList()));
    }
}
    private boolean shouldKeepRun(Run r, Run lsb, Run lstb) {
        if (r.isKeepLog()) {
            LOGGER.log(FINER, "{0} is not to be removed or purged of artifacts because it’s marked as a keeper", r);
            return true;
        }
        if (r == lsb) {
            LOGGER.log(FINER, "{0} is not to be removed or purged of artifacts because it’s the last successful build", r);
            return true;
        }
        if (r == lstb) {
            LOGGER.log(FINER, "{0} is not to be removed or purged of artifacts because it’s the last stable build", r);
            return true;
        }
        if (r.isLogUpdated()) {
            LOGGER.log(FINER, "{0} is not to be removed or purged of artifacts because it’s still building", r);
            return true;
        }
        return false;
    }

    private boolean tooNew(Run r, Calendar cal) {
        if (!r.getTimestamp().before(cal)) {
            LOGGER.log(FINER, "{0} is not to be removed or purged of artifacts because it’s still new", r);
            return true;
        } else {
            return false;
        }
    }

    public int getDaysToKeep() {
        return daysToKeep;
    }

    public int getNumToKeep() {
        return numToKeep;
    }

    public int getArtifactDaysToKeep() {
        return unbox(artifactDaysToKeep);
    }

    public int getArtifactNumToKeep() {
        return unbox(artifactNumToKeep);
    }

    public boolean isRemoveLastBuild() {
        return removeLastBuild;
    }

    public String getDaysToKeepStr() {
        return toString(daysToKeep);
    }

    public String getNumToKeepStr() {
        return toString(numToKeep);
    }

    public String getArtifactDaysToKeepStr() {
        return toString(artifactDaysToKeep);
    }

    public String getArtifactNumToKeepStr() {
        return toString(artifactNumToKeep);
    }

    private int unbox(Integer i) {
        return i == null ? -1 : i;
    }

    private String toString(Integer i) {
        if (i == null || i == -1)   return "";
        return String.valueOf(i);
    }

    @Extension @Symbol("logRotator")
    public static final class LRDescriptor extends BuildDiscarderDescriptor {
        @NonNull
        @Override
        public String getDisplayName() {
            return "Log Rotation";
        }
    }

    private static final Logger LOGGER = Logger.getLogger(LogRotator.class.getName());
}