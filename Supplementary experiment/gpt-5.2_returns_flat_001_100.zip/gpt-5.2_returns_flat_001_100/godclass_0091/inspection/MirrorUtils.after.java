public final class MirrorUtils {

    public static final String SOURCE_CLUSTER_KEY = "cluster";
    public static final String TOPIC_KEY = "topic";
    public static final String PARTITION_KEY = "partition";
    public static final String OFFSET_KEY = "offset";
    private static final Logger log = LoggerFactory.getLogger(MirrorUtils.class);

    // utility class
    private MirrorUtils() {}

    static KafkaProducer<byte[], byte[]> newProducer(Map<String, Object> props) {
        return new KafkaProducer<>(props, new ByteArraySerializer(), new ByteArraySerializer());
    }

    static KafkaConsumer<byte[], byte[]> newConsumer(Map<String, Object> props) {
        return new KafkaConsumer<>(props, new ByteArrayDeserializer(), new ByteArrayDeserializer());
    }

    static String encodeTopicPartition(TopicPartition topicPartition) {
        return topicPartition.toString();
    }

    static Map<String, Object> wrapPartition(TopicPartition topicPartition, String sourceClusterAlias) {
        Map<String, Object> wrapped = new HashMap<>();
        wrapped.put(TOPIC_KEY, topicPartition.topic());
        wrapped.put(PARTITION_KEY, topicPartition.partition());
        wrapped.put(SOURCE_CLUSTER_KEY, sourceClusterAlias);
        return wrapped;
    }

    public static Map<String, Object> wrapOffset(long offset) {
        return Map.of(OFFSET_KEY, offset);
    }

    public static TopicPartition unwrapPartition(Map<String, ?> wrapped) {
        String topic = (String) wrapped.get(TOPIC_KEY);
        int partition = (Integer) wrapped.get(PARTITION_KEY);
        return new TopicPartition(topic, partition);
    }

    static Long unwrapOffset(Map<String, ?> wrapped) {
        if (wrapped == null || wrapped.get(OFFSET_KEY) == null) {
            return -1L;
        }
        return (Long) wrapped.get(OFFSET_KEY);
    }


    /**
     * Validate a specific key in a source partition that may be written to the offsets topic for one of the MM2 connectors.
     * This method ensures that the key is present in the source partition map and that its value is a string.
     *
     * @see org.apache.kafka.connect.source.SourceConnector#alterOffsets(Map, Map)
     * @see SourceRecord#sourcePartition()
     *
     * @param sourcePartition the to-be-validated source partition; may not be null
     * @param key the key to check for in the source partition; may not be null
     *
     * @throws ConnectException if the offset is invalid
     */
    static void validateSourcePartitionString(Map<String, ?> sourcePartition, String key) {
        Objects.requireNonNull(sourcePartition, "Source partition may not be null");
        Objects.requireNonNull(key, "Key may not be null");

        if (!sourcePartition.containsKey(key))
            throw new ConnectException(String.format(
                    "Source partition %s is missing the '%s' key, which is required",
                    sourcePartition,
                    key
            ));

        Object value = sourcePartition.get(key);
        if (!(value instanceof String)) {
            throw new ConnectException(String.format(
                    "Source partition %s has an invalid value %s for the '%s' key, which must be a string",
                    sourcePartition,
                    value,
                    key
            ));
        }
    }

    /**
     * Validate the {@link #PARTITION_KEY partition key} in a source partition that may be written to the offsets topic
     * for one of the MM2 connectors.
     * This method ensures that the key is present in the source partition map and that its value is a non-negative integer.
     * <p/>
     * Note that the partition key most likely refers to a partition in a Kafka topic, whereas the term "source partition" refers
     * to a {@link SourceRecord#sourcePartition() source partition} that is stored in a Kafka Connect worker's internal offsets
     * topic (or, if running in standalone mode, offsets file).
     *
     * @see org.apache.kafka.connect.source.SourceConnector#alterOffsets(Map, Map)
     * @see SourceRecord#sourcePartition()
     *
     * @param sourcePartition the to-be-validated source partition; may not be null
     *
     * @throws ConnectException if the partition is invalid
     */
    static void validateSourcePartitionPartition(Map<String, ?> sourcePartition) {
        Objects.requireNonNull(sourcePartition, "Source partition may not be null");

        if (!sourcePartition.containsKey(PARTITION_KEY))
            throw new ConnectException(String.format(
                    "Source partition %s is missing the '%s' key, which is required",
                    sourcePartition,
                    PARTITION_KEY
            ));

        Object value = sourcePartition.get(PARTITION_KEY);
        // The value may be encoded as a long but as long as it fits inside a 32-bit integer, that's fine
        if (!(value instanceof Integer || value instanceof Long) || ((Number) value).longValue() > Integer.MAX_VALUE) {
            throw new ConnectException(String.format(
                    "Source partition %s has an invalid value %s for the '%s' key, which must be an integer",
                    sourcePartition,
                    value,
                    PARTITION_KEY
            ));
        }

        if (((Number) value).intValue() < 0) {
            throw new ConnectException(String.format(
                    "Source partition %s has an invalid value %s for the '%s' key, which cannot be negative",
                    sourcePartition,
                    value,
                    PARTITION_KEY
            ));
        }
    }

    /**
     * Validate a source offset that may be written to the offsets topic for one of the MM2 connectors.
     *
     * @see org.apache.kafka.connect.source.SourceConnector#alterOffsets(Map, Map)
     * @see SourceRecord#sourceOffset()
     *
     * @param sourcePartition the corresponding {@link SourceRecord#sourcePartition() source partition} for the offset;
     *                        may not be null
     * @param sourceOffset the to-be-validated source offset; may be null (which is considered valid)
     * @param onlyOffsetZero whether the "offset" value in the source offset map must be zero;
     *                       if {@code true}, then only zero is permitted; if {@code false}, then any non-negative
     *                       value is permitted
     *
     * @throws ConnectException if the offset is invalid
     */
    static void validateSourceOffset(Map<String, ?> sourcePartition, Map<String, ?> sourceOffset, boolean onlyOffsetZero) {
        Objects.requireNonNull(sourcePartition, "Source partition may not be null");

        if (sourceOffset == null) {
            return;
        }

        if (!sourceOffset.containsKey(OFFSET_KEY)) {
            throw new ConnectException(String.format(
                    "Source offset %s for source partition %s is missing the '%s' key, which is required",
                    sourceOffset,
                    sourcePartition,
                    OFFSET_KEY
            ));
        }

        Object offset = sourceOffset.get(OFFSET_KEY);
        if (!(offset instanceof Integer || offset instanceof Long)) {
            throw new ConnectException(String.format(
                    "Source offset %s for source partition %s has an invalid value %s for the '%s' key, which must be an integer",
                    sourceOffset,
                    sourcePartition,
                    offset,
                    OFFSET_KEY
            ));
        }

        long offsetValue = ((Number) offset).longValue();
        if (onlyOffsetZero && offsetValue != 0) {
            throw new ConnectException(String.format(
                    "Source offset %s for source partition %s has an invalid value %s for the '%s' key; the only accepted value is 0",
                    sourceOffset,
                    sourcePartition,
                    offset,
                    OFFSET_KEY
            ));
        } else if (!onlyOffsetZero && offsetValue < 0) {
            throw new ConnectException(String.format(
                    "Source offset %s for source partition %s has an invalid value %s for the '%s' key, which cannot be negative",
                    sourceOffset,
                    sourcePartition,
                    offset,
                    OFFSET_KEY
            ));
        }
    }

    static TopicPartition decodeTopicPartition(String topicPartitionString) {
        int sep = topicPartitionString.lastIndexOf('-');
        String topic = topicPartitionString.substring(0, sep);
        String partitionString = topicPartitionString.substring(sep + 1);
        int partition = Integer.parseInt(partitionString);
        return new TopicPartition(topic, partition);
    }

    // returns null if given empty list
    static Pattern compilePatternList(List<String> fields) {
        if (fields.isEmpty()) {
            // The empty pattern matches _everything_, but a blank
            // config property should match _nothing_.
            return null;
        } else {
            String joined = String.join("|", fields);
            return Pattern.compile(joined);
        }
    }

    static Pattern compilePatternList(String fields) {
        return compilePatternList(List.of(fields.split("\\W*,\\W*")));
    }

    static void createCompactedTopic(String topicName, short partitions, short replicationFactor, Admin admin) {
        MirrorAdminTopicCreator.createCompactedTopic(topicName, partitions, replicationFactor, admin, log);
    }
    static void createSinglePartitionCompactedTopic(String topicName, short replicationFactor, Admin admin) {
        createCompactedTopic(topicName, (short) 1, replicationFactor, admin);
    }

    static <T> T adminCall(Callable<T> callable, Supplier<String> errMsg)
            throws ExecutionException, InterruptedException {
        try {
            return callable.call();
        } catch (ExecutionException | InterruptedException e) {
            Throwable cause = e.getCause();
            if (cause instanceof TopicAuthorizationException ||
                    cause instanceof ClusterAuthorizationException ||
                    cause instanceof GroupAuthorizationException) {
                log.error("{} occurred while trying to {}", cause.getClass().getSimpleName(), errMsg.get());
            }
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}