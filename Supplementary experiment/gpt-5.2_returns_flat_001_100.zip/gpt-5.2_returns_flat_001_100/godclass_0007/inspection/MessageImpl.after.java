public class MessageImpl extends StringMapImpl implements Message {
    private static final long serialVersionUID = -3020763696429459865L;
    private static final Class<?> DEFAULT_CONTENTS[];
    private static final int DEFAULT_CONTENTS_LENGTH;
    
    static {
        Class<?> tmps[];
        
        try {
            //if SAAJ is there, give it a slot
            Class<?> cls = Class.forName("javax.xml.soap.SOAPMessage");
            tmps = new Class<?>[] {
                XMLStreamReader.class, XMLStreamWriter.class,
                InputStream.class, OutputStream.class,
                List.class, Exception.class, Node.class, DelegatingInputStream.class,
                cls
            };
        } catch (Throwable e) {
            tmps = new Class<?>[] {
                XMLStreamReader.class, XMLStreamWriter.class,
                InputStream.class, OutputStream.class,
                List.class, Exception.class, Node.class, DelegatingInputStream.class
            };
        }
        DEFAULT_CONTENTS = tmps;
        DEFAULT_CONTENTS_LENGTH = tmps.length;
    }
    
    
    private Exchange exchange;
    private String id;
    private InterceptorChain interceptorChain;
    
    private Object[] defaultContents = new Object[DEFAULT_CONTENTS_LENGTH];
    private Map<Class<?>, Object> contents;
    private Map<String, Object> contextCache;
    
    
    public MessageImpl() {
        //nothing
    }
    public MessageImpl(Message m) {
        super(m);
        if (m instanceof MessageImpl) {
            MessageImpl impl = (MessageImpl)m;
            exchange = impl.getExchange();
            id = impl.id;
            interceptorChain = impl.interceptorChain;
            defaultContents = impl.defaultContents;
            contents = impl.contents;
            contextCache = impl.contextCache;
        } else {
            throw new RuntimeException("Not a MessageImpl! " + m.getClass());
        }
    }
    
    public Collection<Attachment> getAttachments() {
        return CastUtils.cast((Collection<?>)get(ATTACHMENTS));
    }

    public void setAttachments(Collection<Attachment> attachments) {
        put(ATTACHMENTS, attachments);
    }

    public String getAttachmentMimeType() {
        //for sub class overriding
        return null;
    }
    
    public Destination getDestination() {
        return get(Destination.class);
    }

    public Exchange getExchange() {
        return exchange;
    }

    public String getId() {
        return id;
    }

    public InterceptorChain getInterceptorChain() {
        return this.interceptorChain;
    }

    @SuppressWarnings("unchecked")
    public <T> T getContent(Class<T> format) {
        for (int x = 0; x < DEFAULT_CONTENTS_LENGTH; x++) {
            if (DEFAULT_CONTENTS[x] == format) {
                return (T)defaultContents[x];
            }
        }
        return contents == null ? null : (T)contents.get(format);
    }

    public <T> void setContent(Class<T> format, Object content) {
        for (int x = 0; x < DEFAULT_CONTENTS_LENGTH; x++) {
            if (DEFAULT_CONTENTS[x] == format) {
                defaultContents[x] = content;
                return;
            }
        }
        if (contents == null) {
            contents = new IdentityHashMap<Class<?>, Object>(6);
        }
        contents.put(format, content);
    }
    
    public <T> void removeContent(Class<T> format) {
        for (int x = 0; x < DEFAULT_CONTENTS_LENGTH; x++) {
            if (DEFAULT_CONTENTS[x] == format) {
                defaultContents[x] = null;
                return;
            }
        }
        if (contents != null) {
            contents.remove(format);
        }
    }

public Set<Class<?>> getContentFormats() {
    Set<Class<?>> c = initContentFormatsSet();
    addDefaultContentFormats(c);
    return c;
}
    public void setDestination(Destination d) {
        put(Destination.class, d);
    }

    public void setExchange(Exchange e) {
        this.exchange = e;
    }

    public void setId(String i) {
        this.id = i;
    }

    public void setInterceptorChain(InterceptorChain ic) {
        this.interceptorChain = ic;
    }
    public Object put(String key, Object value) {
        if (contextCache != null) {
            contextCache.put(key, value);
        }
        return super.put(key, value);
    }
    public Object getContextualProperty(String key) {
        if (contextCache == null) {
            calcContextCache();
        }
        return contextCache.get(key);
    }
    
private void calcContextCache() {
    Map<String, Object> o = ContextCacheBuilder.build(getExchange(), this);
    contextCache = o;
}    public static void copyContent(Message m1, Message m2) {
        for (Class<?> c : m1.getContentFormats()) {
            m2.setContent(c, m1.getContent(c));
        }
    }

    public void resetContextCache() {
        if (contextCache != null) {
            contextCache = null;
        }
    }

    public void setContextualProperty(String key, Object v) {
        if (contextCache != null && !containsKey(key)) {
            contextCache.put(key, v);
        }
    }
}